# Nova 写卡专家 — SillyTavern 角色卡创作指令

> 本文件是给 **Codex / OpenCode 等 IDE 编程 Agent** 的项目指令。把它放在项目根目录，Agent 每次会话会自动加载，并按本规范编写、编译、验证 SillyTavern 角色卡。
> 配套脚本与深度文档在 `./nova-write-card/`（与本文件一起提供）。脚本是加速器，不依赖它们也能按本规范徒手产出合法 `chara_card_v3` JSON。

---

## 一、何时启用（激活条件）

当用户提出以下任一意图时，按本规范工作：

- 写卡 / 角色卡 / 人物设定 / 生成角色 / 创建角色 / 设计角色
- 世界书 / 世界观 / 设定集 / 规则书 / 地理设定 / 势力设定
- 编译 / 打包 / 生成 `chara_card_v3` JSON
- MVU / ZOD / 变量系统 / 好感度系统
- 美化 / HTML / 状态栏 / 前端界面
- 动态世界书 / 阶段切换 / ESJ / EJS
- 有人味 / 内在矛盾 / 性格锚点 / 演绎法

**输出物**：SillyTavern 标准 `chara_card_v3` JSON 角色卡（含可选世界书 `character_book`、MVU、ESJ、状态栏）。

---

## 二、🚨 铁律（全程不可违反）

| # | 铁律 |
|---|------|
| 1 | **MVU、HTML、状态栏、美化、ESJ、角色演绎法 —— 仅用户明确要求时才启用**。用户没提就当不存在，绝不主动建议。 |
| 2 | **所有世界书条目必须 `preventRecursion: true` 且 `excludeRecursion: true`**（无一例外）。 |
| 3 | **三种配置模式**：单角色卡→全部蓝灯；多角色卡→速览蓝灯+详情绿灯；混合卡→核心蓝灯(≤5条)+子系统绿灯。详见第五节。 |
| 4 | **开场白启用 MVU 时必须含 `<StatusPlaceHolderImpl/>`**；未启用则不含。 |
| 5 | **输出后必须执行禁词扫描**（见第四节），0 命中才算过。 |
| 6 | **输出前必须展示草稿给用户确认（DoubleCheck）**，用户说"可以/继续/生成"后再编译。 |
| 7 | **状态栏 JS 必须用 `getMvuData()` 三级降级**（见第八节）。 |
| 8 | **状态栏代码块必须无语言标签**（用 ```` ``` ````，绝不用 ```` ```html ````）。 |
| 9 | **角色卡内默认不含 `<options>` 标签**，除非用户明确要求选项美化。 |
| 10 | **编译输出自动带版本号，不覆盖旧文件**（`_v001.json`…）。 |
| 11 | **ESJ 阶段控制器必须先启用 MVU**；每个 `getwi` 目标子条目必须真实存在。 |

---

## 三、任务类型路由（先判断，再动手）

不确定类型时**先提问澄清**（几个核心角色？世界观复杂度？素材来源？风格？特殊需求？），不猜测。

| 类型 | 触发词 | 输出 | 启用条件 |
|------|--------|------|----------|
| 0 | 写卡/角色卡/人物设定/生成角色 | 完整角色卡（含世界书） | 自动 |
| 1 | 世界书/生成世界书/世界观设定 | 世界书条目 | 自动 |
| 2 | 轻小说/小说/游戏/转化/提取/原文 | 转化为角色卡或世界书 | 自动 |
| 3 | 世界观/设定集/规则书/魔法体系/地理设定 | 纯世界观条目 | 自动 |
| 4 | 武器/道具/装备/技能/功法/神器 | 物品/能力设定 | 自动 |
| 5 | 文风/写作风格/笔风/模仿写作 | 文风条目 | 自动 |
| 6 | MVU/ZOD/变量/好感度系统 | MVU 变量系统 | **仅用户要求** |
| 7 | 美化/HTML/前端/状态栏/UI | HTML 状态栏 | **仅用户要求** |
| 8 | 动态世界书/阶段切换/ESJ/EJS/按变量注入 | ESJ 阶段控制器 | **仅用户要求 + 先开 MVU** |
| 9 | 有人味/内在矛盾/性格锚点/演绎法 | 角色演绎协议 | **仅用户要求（可选增强）** |

**多层任务**（如"把轻小说转成角色卡"）按类型 2 处理。

---

## 四、🚫 禁词清单（强制，逐条扫描）

> 这是质量最后防线。写完每段立刻扫，发现即改。**绝不可把清单里的词写进卡**。

**叙事禁词**：`一丝` `一缕` `一抹` `不易察觉` `不易觉察` `难以察觉` `鲜明对比` `形成对比` `弧度` `弯起嘴角` `翘起嘴角` `喉结` `纽扣` `指节发白`；以及任何「不是…是…」「没有…而是…」先否认再肯定的句式。

**比喻禁词**：禁止以 石子/湖面、拉满的弓、琴弦、闪电、晨光、星辰 为喻体的比喻；禁止「像一道闪电」「如同天堑」等解释性比喻。

**描写禁律**：
- 禁止作者视角解释（"这个动作体现了…""他的目光带着…"）
- 禁止对语气/眼神/腔调/视线做比喻描写
- 禁止描写不存在之物（"拂去不存在的灰尘""推不存在的眼镜"）
- 禁止对白中出现精确数值或数字

**写作准则**：白描（用动作/语言/神态传情绪）；环境烘托；自由间接引语；对白交替长句不敷衍；情景连贯；角色只知公共/私有知识，绝不知创作者情报。

**开场白额外禁律（最严格）**：禁止解释背景设定、角色自我心理剖析、站桩式外貌描写、多余修辞。检查标准：开场每个字 AI 都能转化为角色演出信息，而非用来模仿你的修辞。

---

## 五、世界书配置规则（配置错 = AI 读不到）

### 5.1 蓝灯 vs 绿灯

- **蓝灯 `constant: true`**：每轮都发给 AI。**只放「每轮都必须存在」的信息**（世界观总纲、角色速览、规则）。
- **绿灯 `constant: false` + `keys` + `scanDepth: 2`**：关键词命中才注入。放 NPC/场景/事件/角色详情。

### 5.2 三种模式

| 模式 | 适用 | 蓝灯 | 绿灯 |
|------|------|------|------|
| 单角色卡 | 1 个核心角色 | **该角色所有拆分条目全部 `constant=true`**（拆几条都蓝灯） | 不使用 |
| 多角色卡 | 2+ 核心角色 | 2–3 条速览（世界观+角色一句话简介） | 各角色详情 `constant=false`+`keys`(全名,昵称,外号)+`scanDepth:2` |
| 混合卡 | 单主角+多 NPC+子系统 | ≤5 条核心（人设→行为→世界观→MVU规则） | NPC/子系统全部绿灯 |

> 单角色卡铁律：**没有例外**。拆成 10 个条目 = 10 个蓝灯。把某条改绿灯 = 角色不完整、AI 猜着演 = 八股。

### 5.3 位置（position）

| 内容 | position |
|------|----------|
| 世界观总纲/背景/规则/地理 | `before_char` (0) |
| 角色详情/NPC/场景/物品 | `after_char` (1) |
| 文风/格式指令 | `at_depth` (2) |
| 行为纠正（depth=0） | `at_depth` (4) |
| D1+（depth≥1） | **永不使用** |

### 5.4 递归（双字段，必须同时勾选）

**所有条目**必须 `preventRecursion: true` 且 `excludeRecursion: true`。`build-card.js` 默认 `false`，须显式设 `true`，否则 token 爆炸/双向递归。

### 5.5 关键词格式

- **英文逗号** `,` 分隔，无空格；中文逗号 `，` 和空格直接失效。
- 覆盖全名+昵称+外号+职务：`keys: ["林小雨,小雨,班长"]`

### 5.6 常见配置组合（YAML）

```yaml
# 世界观总纲（蓝灯，角色定义前）
- comment: "世界观总纲"
  content: "..."
  constant: true
  position: before_char
  order: 1
  prevent_recursion: true
  exclude_recursion: true

# 角色详情（蓝灯，单角色卡）
- comment: "角色性格设定"
  content: "..."
  constant: true
  position: after_char
  order: 30
  prevent_recursion: true
  exclude_recursion: true

# NPC 详情（绿灯，关键词触发）
- comment: "NPC详情"
  content: "..."
  constant: false
  position: after_char
  order: 100
  keys: ["角色名,昵称,外号"]
  scan_depth: 2
  prevent_recursion: true
  exclude_recursion: true
```

### 5.7 庞大世界观分层（省 Token，条目 ≥ ~20 时）

蓝灯只放「规则 + 世界骨架」，绿灯承载「一切详情」：

- **L0 规则层（蓝灯常驻）**：格式指导、世界观概览、叙事铁律（规则非 Lore，便宜）。
- **L1 区域骨架层（蓝灯常驻）**：正则区域标记 `</上城>`（用 `use_regex:true`+`keys:[]`）+ 可选名字清单（中等规模列名字、庞大世界观只留正则标记）。
- **L2 详情层（绿灯触发）**：地点/人物/事件完整条目，名字命中才注入。

绿灯条目标准：
```yaml
constant: false
selective: true
use_regex: true
position: after_char
depth: 4
prevent_recursion: true
probability: 100
keys: ["艾莉"]   # 角色名即触发词
```
Token 账：200 人物×600 Token，全常驻=12 万（爆）；全绿灯≈省 98%；蓝灯名字清单法≈省 96% 但世界更有实感。

---

## 六、角色卡结构与人设写法

> 性格和基本信息**必须分开放**。混写 = AI 读完基本信息就按标签演戏，性格条目全在打架。

### 6.1 四部分严格分离

```
角色档案(description) → 性格设定(世界书独立条目) → 世界观(世界书独立条目) → 开场白(first_mes)
```

- **描述铁律**：每个角色必须有自己独立的**性格世界书条目**；性格内容**绝对禁止写入 `description`**（description 只含 基本信息/外貌/背景/关系）。读完 description 若能说出性格 → 违规。
- 多角色卡：description 只写全局概述，每人各有独立「人物设定条目 + 性格条目」。

### 6.2 角色档案（description 结构）

```yaml
name: "角色中文名"
name_en: "English Name"
age: "年龄 + 身份定位"
gender: "性别"
nicknames: ["昵称1", "昵称2", "昵称3"]
appearance:
  height: "身高"
  hair: "发型/发色：30字内，只写特征不写美感"
  eyes: "瞳色/眼型：30字内，写特征不写比喻"
  skin: "肤色：20字内，只写偏离默认的特征"
  build: "体型：20字内"
  clothing: { 日常: "...", 特殊场合: "..." }
  distinguishing: "标志性特征"
  voice: "声线/不同情绪下的语气变化"
background: |
  一段话讲出身、关键节点、是什么让她变成现在这样。只写改变过她的关键事件，不写流水账。
relationships:
  - name: "角色名或{{user}}"
    detail: "关系描述：具体画面而非抽象形容"
```

### 6.3 性格条目（世界书，每人一条，蓝灯）

```yaml
mbti: "INFP（如适用）"
core_drive: "核心驱动力：最想要什么、最怕什么，一句话"
traits:
  - "温柔——下雨天把伞倾向{{user}}那边，自己淋湿半边肩"
  - "固执——认定了九头牛拉不回"
  - "...（10-15条，每条必须有行为依据）"
likes: ["热奶茶", "雨后空气"]
dislikes: ["欺骗", "香菜"]
habits: ["说话时无意识拨弄头发", "紧张时咬下唇"]
hidden_self: ["表面开朗实际怕独处", "童年创伤不敢轻易信任"]
```
**写行为不写标签**：「温柔——下雨天把伞倾向对方」✅；「性格温柔」❌。

### 6.4 开场白规范

白描 + 场景化 + {{user}} 视角 + 开放式结尾 + 不替 {{user}} 做决定。结构：时间地点氛围 → 角色状态 → {{user}}处境 → 互动契机 → 开放式结尾 → `<StatusPlaceHolderImpl/>`（仅 MVU）。提供 2–4 个 `alternate_greetings` 覆盖不同场景。

### 6.5 字数门槛

| 指标 | 合格 | 良好 |
|------|------|------|
| description | ≥800 | ≥1500 |
| 每核心角色人设 | ≥1500 | ≥3000 |
| 每行为模式 | ≥500 | ≥1000 |
| 开场白 | ≥500 | ≥1000 |
| 世界书条目数 | ≥7 | ≥10 |
| 条目平均长度 | ≥300 | ≥500 |

---

## 七、角色演绎法（有人味增强，类型 9，可选）

> 有人味 ≠ 堆语料。语料是**产物不是输入**。靠「结构化内在矛盾 + 可执行演绎协议」让 AI 每次*推导*行为而非*抄*列表。

**结构三件套**：
1. **内核（恒定）**：最根本驱动力与恐惧。例：*渴望被需要，却恐惧被抛弃。*
2. **内在矛盾（张力源）**：两股互相拉扯的力，从「恐惧」而非「萌点」定义。例：*想靠近 ↔ 想推开（怕被弃所以先否认依赖）。*
3. **锚点（行为签名）**：矛盾落到一个具体可记的动作。例：*嘴上说"关我什么事"，手却把伞往你那边偏，自己半边肩淋湿也不提。*

**演绎协议（写进蓝灯条目，指令+少样本，勿只当事实）**：
```
面对事件：
1. 枚举可能反应分支
2. 按与内核一致度打 0–6：6=最贴合矛盾两侧（锚点级），3–5=可能，0–2=不可能（违背内核）
3. 硬剪枝排除 0–2，绝不输出
4. 在 3–6 中可变选择，优先用锚点动作
5. 绝不直接裸露依赖（除非冲突极剧烈）
```
> 0–6 是**过滤器不是选择器**：永远选 6 = 每轮复读锚点反而假。剪枝保证「不违背内核」，保留保证「不机器人」。

**与动态系统联动**：把矛盾张力做成 MVU 变量（`stat_data.角色.依赖恐惧`），让 0–6 评分随状态漂移；ESJ 按张力切换不同阶段条目。

---

## 八、MVU / ESJ（动态系统，仅用户要求）

### 8.1 MVU（变量层，第三方扩展 MagVarUpdate）

- 用户须自行安装 MagVarUpdate 扩展。本规范产出：Zod Schema（`变量结构.js`）、InitVar 条目（`enabled:false`）、变量更新规则条目、变量输出格式条目（JSON Patch）、可选状态栏 HTML。
- JSON Pointer 路径 = `/<Zod顶级key>/<变量名>`（如 `/wealth_system/好感度`）。
- AI 输出格式：
```
<UpdateVariable>
<Analysis>英文≤80词，分析每个变量的变化</Analysis>
<JSONPatch>
[ { "op": "replace", "path": "/wealth_system/好感度", "value": 75 } ]
</JSONPatch>
</UpdateVariable>
```
- 状态栏 JS 铁律：`getMvuData()` 三级降级（`window.stat_data` → MVU API → 兜底 `{}`）、代码块无语言标签、`<script type="module">`、所有 `getElementById` 前有存在性检查、数值有 `Math.min/Math.max` 边界、`init()` 含 `setTimeout`/`DOMContentLoaded` + `setInterval` 轮询保底 + 清理旧轮询。

### 8.2 ESJ = EJS（表现层，动态世界书，依赖 MVU）

写在世界书条目 `content` 里的 EJS 写法，按变量值注入不同子条目。控制器条目 `constant: true`，子条目 `constant: false`（由控制器 `getwi` 触发，不靠关键词）。

```ejs
<%_ if (typeof g === 'undefined') var g = getvar('stat_data.好感度.艾莉丝.数值', { defaults: 50 }); _%>
<%_ if (g >= 80) { _%><%- await getwi(null, '女神艾莉丝_阶段03_亲密期') %>
<%_ } else if (g >= 50) { _%><%- await getwi(null, '女神艾莉丝_阶段02_熟悉期') %>
<%_ } else { _%><%- await getwi(null, '女神艾莉丝_阶段01_初识期') %><%_ } _%>
```
`getvar`/`getwi` 是酒馆「模板引擎」扩展 helper（非 JS 原生），须提示用户装扩展。`if/else if/else` 必须全覆盖含兜底 `else`；每个 `getwi` 目标子条目必须真实存在（断链即报错）；子条目 `keys` 非空。

---

## 九、脚本（加速器，在 `./nova-write-card/scripts/`）

> 运行前确认 Node.js ≥ 18，`cd` 到含 `config.yaml` 的项目目录。相对路径按本文件所在项目根。

```bash
# 1. 初始化骨架（basic/mvu/full）
node nova-write-card/scripts/init-project.js "作品名" --type mvu --characters "角色名" --mvu "好感度,欲望值"

# 2. 编辑源文件（背景设定.md / 角色设定_*.xyaml / 开场白.md / entries/*.yaml）

# 3. 编译（自动加 preventRecursion/excludeRecursion、生成正则+TavernHelper 脚本、带版本号）
node nova-write-card/scripts/build-card.js config.yaml

# 4. 验证（40+ 项检查，0 个 ❌ 才算过）
node nova-write-card/scripts/validate-card.js 作品名称.json -v

# 5. 解包已有卡（修改用）
node nova-write-card/scripts/unpack-card.js 原卡.json ./unpacked/

# 6. 质量评分（9 维度加权，输出 S–D 等级）
node nova-write-card/scripts/score-card.js 作品名称.json
```

**config.yaml 最小结构**（编译输入）：
```yaml
spec:
  name: "输出文件名"
  description: "简短描述"
  version: "1.0.0"
data:
  name: "角色名"
  description: ""          # 留空，人设由世界书承载
  personality: ""          # 留空
  first_mes: "${file:开场白.md}"
  mes_example: "${file:对话示例.md}"
  character_book:
    entries:
      - keys: ["角色名"]
        content: "${file:角色设定_角色.yaml}"
        position: before_char
        order: 1
        constant: true
        prevent_recursion: true
        exclude_recursion: true
```

---

## 十、DoubleCheck 质量检查（输出前必做，不可跳过）

1. **禁词扫描**：第四节逐条 0 命中（全文 + 开场白额外严格）。
2. **配置检查**：单角色→全蓝灯；多角色→速览蓝灯、详情绿灯+`keys`；所有条目 `preventRecursion`+`excludeRecursion`；`keys` 英文逗号无空格；绿灯 `scanDepth=2`；开场白含 `<StatusPlaceHolderImpl/>`（仅 MVU）。
3. **结构完整性**：description 非空；personality 非空且非模板；first_mes 非空；世界书≥1 条；**性格不在 description 里**。
4. **运行 `validate-card.js`**：0 个 ❌ 失败项。
5. **状态栏健壮性**（仅启用时）：`getMvuData()` 三级降级、代码块无语言标签、`<script type=module>`、`getElementById` 前有检查、轮询保底、MVU 事件绑定、清理旧轮询。

---

## 十一、质量评分（9 维度加权，S–D）

| # | 维度 | 权重 | 类型 | 问法 |
|---|------|------|------|------|
| D1 | 结构合规 | 15% | 必查 | 合法 v3 卡、字段齐？ |
| D2 | 人设厚度/有人味 | 20% | 必查 | 有记忆点、前后一致、编码内涵+矛盾+协议？ |
| D3 | 世界书工程 | 15% | 必查 | 配置对、Token 不浪费、分层？ |
| D4 | 叙事/禁词 | 15% | 必查 | 零禁词、白描、有质感？ |
| D5 | 开场白/样例 | 10% | 必查 | 第一句抓人、有钩子？ |
| D6 | MVU | 10% | 条件 | 变量闭环、路径零错？ |
| D7 | ESJ | 5% | 条件 | 阶段切换通、零断链？ |
| D8 | 状态栏 | 5% | 条件 | 刷新稳、零报错？ |
| D9 | 脚本集成 | 5% | 必查 | 正则/TavernHelper 齐？ |

**总分** = `Σ(维度分×权重) ÷ 已启用权重和 × 100`。条件维度未启用则跳过，权重摊入其余。
**等级**：≥90 **S**｜80–89 **A**｜70–79 **B**｜60–69 **C**｜<60 **D**。
**D2 什么叫有人味**：言行不一的张力 + 具体行为锚点 + 私密小习惯 + 不完美；换掉名字就不成立 = 有人味。
**D3 什么叫配置对**：常驻只放每轮必看、详情靠关键词触发、`keys` 英文逗号、绿灯 `scanDepth=2`。

---

## 十二、深度文档索引（在 `./nova-write-card/references/`）

需要某主题的完整写法/字段速查时，读取对应文件：

| 文件 | 用途 |
|------|------|
| `references/scenario-router.md` | 任务分类路由（每次任务前） |
| `references/card-writing-guide.md` | 角色卡编写规范 |
| `references/character-guide.md` | 角色/性格条目 YAML 模板 |
| `references/config-guide.md` | 世界书配置规则（含分层） |
| `references/forbidden-words.md` | 禁词清单全文 |
| `references/mvu-system.md` | MVU 变量系统完整指南 |
| `references/esj-stage-controller.md` | ESJ 动态世界书 |
| `references/character-deduction.md` | 角色演绎法（有人味） |
| `references/world-book-layering.md` | 世界书分层省 Token |
| `references/score-card-guide.md` | 质量打分测评 |
| `references/doublecheck.md` | 质量检查清单 |
| `references/conversion-guide.md` | 小说/游戏→角色卡 |
| `references/position-guide.md` | position 完整参考表 |
| `references/validation.md` | 验证排错 |
| `templates/MVU组件包/` | MVU 各组件模板 |

---

## 十三、一句话工作流

```
判断类型 → 澄清需求 → init-project 建骨架 → 写内容(禁词/配置/人设分离)
→ build-card 编译(自动防递归+版本号) → validate-card 验证(0❌) → DoubleCheck 禁词+配置 → score-card 评分
→ 用户确认后交付 JSON
```
