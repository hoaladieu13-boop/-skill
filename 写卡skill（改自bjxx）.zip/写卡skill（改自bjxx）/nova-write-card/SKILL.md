---
name: nova-write-card
description: This skill should be used when the user asks to "create a character card", "write a SillyTavern card", "build a roleplay character", "make a character JSON", "compile a character card", "generate a chara card", "design a roleplay character", "create a worldbook entry", "set up MVU variables", or needs to produce a complete SillyTavern chara_card_v3 JSON file for AI roleplay. Provides complete workflow from character concept to packaged JSON card.
version: 2.1.0
---

# Nova 写卡专家 — SillyTavern 角色卡创作技能

## 概述

Create complete SillyTavern `chara_card_v3` JSON files from character concepts. This skill covers the full pipeline: task routing → character design → content files → YAML configuration → compilation → validation → **DoubleCheck**.

**输出文件类型：**
- SillyTavern 标准 `chara_card_v3` JSON 角色卡
- 世界书（`character_book`）条目，支持 `before_char`/`after_char`/`at_depth` 三种位置
- MVU（Magical Variable Update）Zod 动态变量系统
- TavernHelper 脚本与正则替换脚本
- 状态栏 HTML（可选，**仅用户要求时**）

## 环境要求

- **Node.js** ≥ 18（运行编译/解包脚本）
- **npm 包**：`js-yaml`（`npm install js-yaml`）
- **文本编辑器**：用于编写 .yaml/.xyaml/.txt/.md 源文件
- **SillyTavern**：用于导入最终角色卡

---

## 🚨 铁律（必须遵守）

> 以下规则在执行全流程中**不可违反**，否则输出将视为不合格。

| # | 铁律 | 说明 |
|---|------|------|
| 1 | **MVU、HTML、状态栏、美化 — 仅用户明确要求时才启用** | 绝不主动建议，用户不提就当不存在 |
| 2 | **所有世界书条目必须 `preventRecursion=true` 且 `excludeRecursion=true`** | ✅ build-card.js 自动设置，validate-card.js 自动检查 |
| 3 | **三种配置模式：单角色卡→全蓝灯；多角色卡→速览蓝灯+详情绿灯；混合卡→核心蓝灯(≤5条)+子系统绿灯+多NPC绿灯** | 详见下方"三种配置模式"表格 |
| 4 | **开场白启用 MVU 时必须含 `<StatusPlaceHolderImpl/>`** | validate-card.js 检查 |
| 5 | **输出后必须执行禁词扫描** | 见 `references/doublecheck.md` |
| 6 | **输出前必须展示草稿给用户确认（DoubleCheck）** | 见 `references/doublecheck.md` |
| 7 | **状态栏 JS 必须使用 `getMvuData()` 三级降级模式** | 见 `references/mvu-system.md` |
| 8 | **状态栏代码块必须无语言标签** | validate-card.js 检查 |
| 9 | **角色卡内默认不包含 `<options>` 标签** | 除非用户明确要求选项美化功能，否则角色卡内不应包含 |
| 10 | **编译输出自动带版本号，不覆盖旧文件** | build-card.js 自动生成 `_v001.json`、`_v002.json` 等 |
| 11 | **ESJ 阶段控制器（动态世界书）— 仅用户明确要求时才启用，且必须先启用 MVU** | 控制器读取的 `stat_data` 由 MVU 维护；无 MVU 即退化成静态卡。每个 `getwi` 目标子条目必须存在 |

### 铁律#3 补充：三种配置模式

| 模式 | 适用场景 | 蓝灯(常驻)配置 | 绿灯(触发)配置 | 示例 |
|------|----------|---------------|---------------|------|
| **单角色卡** | 1个角色，无分条目、无子系统 | 全部条目 `constant=true` | 不使用绿灯 | 基础聊天卡 |
| **多角色卡** | 多个独立角色，各有详情 | 2-3条速览（世界观+MVU规则）`constant=true` | 各角色详情 `constant=false`+`selective=true`+`keys`+`scanDepth:2` | 攻略恋爱卡 |
| **混合卡** | 单主角+多NPC+子系统模块 | ≤5条核心蓝灯：角色人设+行为模式+MVU规则+背景设定 `constant=true` | NPC详情+子系统模块 `constant=false`+`selective=true`+`keys`+`scanDepth:2` | 林家秘事（主角3条蓝灯+行为模式3条蓝灯） |

**混合卡注意事项：**
- 蓝灯总量控制在 ≤5 条，避免浪费上下文
- 蓝灯顺序：角色人设 → 行为模式 → 世界观 → MVU规则（按重要性降序）
- 子系统（如重口模块）应全部设绿灯，用关键词触发

---

## 第零步：任务判断（场景路由器）

所有任务开始前，必须先判断任务类型。

详见 [`references/scenario-router.md`](references/scenario-router.md)。

### 任务类型速查

| 类型 | 名称 | 适用场景 |
|------|------|----------|
| 0 | **角色卡创建** | 从零创建完整角色卡（含世界书） |
| 1 | **原创世界书** | 已有角色卡，需补世界观 |
| 2 | **转化提取** | 小说/游戏/剧本 → 角色卡/世界书 |
| 3 | **纯世界观** | 仅需世界观/规则设定，无角色 |
| 4 | **物品/能力** | 装备/能力/道具设定 |
| 5 | **文风提取** | 提取/设定文风 |
| 6 | **MVU 变量系统** | **仅用户明确要求时** |
| 7 | **HTML 美化** | **仅用户明确要求时** |
| 8 | **ESJ 阶段控制器** | **仅用户明确要求时（且必须先启用 MVU）** |
| 9 | **角色演绎法（有人味增强）** | **仅用户明确要求时（可选增强）** |

**判断流程：**
1. 用户需求 → 匹配任务类型
2. 按类型加载对应参考文件
3. 如果不确定 → 澄清式问询

---

## 快速开始（5 分钟流程）

```bash
# 1. 初始化项目（一键创建骨架）
node scripts/init-project.js "作品名称" --type basic --characters "角色名"

# 2. 编辑源文件（背景、角色、开场白）
# 3. 编译
node scripts/build-card.js config.yaml
# 输出：作品名称.json → 导入 SillyTavern

# 4. 验证
node scripts/validate-card.js 作品名称.json

# 5. DoubleCheck 禁词扫描（必须）
# 按 references/forbidden-words.md 逐条检查
```

---

## 流水线工作流

| 阶段 | 步骤 | 产出文件 | 字数门槛 | 参考 |
|------|------|----------|---------|------|
| **0** | 任务判断（场景路由器） | 确定任务类型 | — | [`scenario-router.md`](references/scenario-router.md) |
| **1** | 需求分析与项目初始化 | 项目骨架 + `to-do.md` | — | [`workflow.md`](references/workflow.md) |
| **2** | **内容创作（核心）** | 背景、角色设定、开场白、世界书条目 | 见下方 | [`创作规范.md`](references/创作规范.md)、[`card-writing-guide.md`](references/card-writing-guide.md)、[`character-guide.md`](references/character-guide.md) |
| **3** | MVU 系统装配（可选） | 变量结构、更新规则、输出格式、状态栏 | — | [`mvu-system.md`](references/mvu-system.md) |
| **4** | 编译打包 | `[作品名称].json` | — | [`build-card.js`](scripts/build-card.js) |
| **5** | 验证输出 | 验证报告 | — | [`validate-card.js`](scripts/validate-card.js)、[`validation.md`](references/validation.md) |
| **6** | **DoubleCheck 质量检查** | 禁词扫描 + 配置检查 | — | [`forbidden-words.md`](references/forbidden-words.md) |

### 字数门槛速查

| 指标 | 合格 | 良好 |
|------|------|------|
| description | ≥ 800字 | ≥ 1500字 |
| 每个核心角色人设 | ≥ 1500字 | ≥ 3000字 |
| 每个行为模式 | ≥ 500字 | ≥ 1000字 |
| 开场白（叙事型） | ≥ 500字 | ≥ 1000字 |
| 世界书条目总数 | ≥ 7条 | ≥ 10条 |
| 条目平均长度 | ≥ 300字 | ≥ 500字 |
| 条目总内容 | ≥ 5000字 | ≥ 10000字 |

详见完整工作流 [`references/workflow.md`](references/workflow.md)。

---

## 🚫 禁词清单（强制）

所有输出内容（角色档案、开场白、世界书条目）**必须**按以下规则扫描，发现即修改。

> 完整清单详见 [`references/forbidden-words.md`](references/forbidden-words.md)。

### 叙事禁词（全文禁用）

| 禁词 | 替换方案 |
|------|----------|
| `一丝` `一缕` `一抹` | 直接描述 |
| `不易察觉` `不易觉察` `难以察觉` | 删除或改为动作描写 |
| `鲜明对比` `形成对比` | 直接描述事实 |
| `弧度`（形容嘴角/嘴唇） | 直接用「嘴角上扬/微笑」 |
| `弯起嘴角` `翘起嘴角` | 改为「微笑」「嘴角上扬」 |
| `不是...是...` `没有...而是...` | 改为直接陈述 |
| `喉结`（非必要场景） | 删除或替换 |
| `指节发白` | 改为动作本身 |

### 比喻禁词（全文禁用）

禁止使用以下比喻：**石子投入湖面、拉满的弓、琴弦、划破夜空的闪电、初升的晨光、缀满星辰**。

### 描写禁律

- 禁止作者视角解释性修饰（「仿佛」「似乎」「像是」）
- 禁止不存在之物的描写（"新雪般雪白的肌肤" — AI 无法看见，写这个毫无意义）
- 改用白描：只写客观可观察的动作和对话

### 开场白禁律（更严格）

开场白中额外禁止：
- 解释背景设定
- 角色自我心理剖析
- 站桩式外貌描写
- 多余修辞

---

## DoubleCheck 质量检查

> 这是最后的质量防线。**不可跳过。**

编译 + 验证完成后，必须执行 DoubleCheck：

### 1. 禁词扫描

按 [`references/forbidden-words.md`](references/forbidden-words.md) 逐条扫描：
- [ ] 全文扫描叙事禁词
- [ ] 全文扫描比喻禁词
- [ ] 全文扫描描写禁律违规
- [ ] 开场白额外扫描

### 2. 配置检查

- [ ] 单角色卡 → 所有世界书条目 `constant=true`
- [ ] 多角色卡 → 速览 `constant=true`，详情 `constant=false` + `keys`
- [ ] 所有条目 `preventRecursion=true` 且 `excludeRecursion=true`
- [ ] 关键词使用英文逗号，无空格
- [ ] 绿灯条目 `scanDepth=2`
- [ ] 开场白末尾含 `<StatusPlaceHolderImpl/>`（仅启用 MVU 时）

### 3. 结构完整性

- [ ] description 不为空
- [ ] **personality 不为空且非模板** ✅
- [ ] first_mes 不为空
- [ ] 世界书条目至少 1 条

详见 [`references/doublecheck.md`](references/doublecheck.md)（完整 4 阶段检查清单）。

### 4. 状态栏健壮性检查（仅启用状态栏时）

- [ ] `getMvuData()` 函数包含三级降级（`window.stat_data` → MVU API → 兜底默认值）
- [ ] 代码块使用 ` ``` ` 无语言标签（不要 ` ```html `）
- [ ] `script` 标签使用 `type="module"`
- [ ] 所有 `document.getElementById()` 前有存在性检查
- [ ] 数值变量有 `Math.min` / `Math.max` 边界限制
- [ ] `init()` 含延迟机制（`setTimeout`/`DOMContentLoaded`）+ 轮询保底（`setInterval`）
- [ ] MVU 事件绑定：`window.Mvu.on('variableUpdateEnded', ...)`
- [ ] 清理旧轮询：`if (window._sbInterval) clearInterval(window._sbInterval)`

---

## 资源索引

### 参考指南（`references/`）

| 文件 | 用途 | 优先级 |
|------|------|--------|
| [`quick-start.md`](references/quick-start.md) | ✨ **快速参考**：10 步工作流、命令速查、铁律速览 | **首先查看** |
| [`scenario-router.md`](references/scenario-router.md) | 🥇 **场景路由器**：任务分类 + 路由逻辑 | **必读 — 每次任务前** |
| [`card-writing-guide.md`](references/card-writing-guide.md) | 🥇 角色卡编写规范（四部分结构 + 性格铁律） | **角色卡任务必读** |
| [`character-guide.md`](references/character-guide.md) | 🥇 角色条目 YAML 模板（人物设定 + 性格条目） | **角色卡任务必读** |
| [`config-guide.md`](references/config-guide.md) | 🥇 世界书配置规则（蓝灯/绿灯、位置、递归） | **世界书任务必读** |
| [`doublecheck.md`](references/doublecheck.md) | 🥇 **质量检查清单**（禁词、配置、结构、验证） | **编译后必读** |
| [`position-guide.md`](references/position-guide.md) | 🥇 Position 完整参考表 | **配置时必读** |
| [`forbidden-words.md`](references/forbidden-words.md) | 🥇 **禁词清单**（叙事/比喻/描写/开场白） | **DoubleCheck 时必查** |
| [`conversion-guide.md`](references/conversion-guide.md) | 🥈 转化工作流（小说/游戏 → 角色卡） | **类型 2 任务必读** |
| [`workflow.md`](references/workflow.md) | 🥈 完整流水线工作流（11 阶段详解） | 流程参考 |
| [`mvu-system.md`](references/mvu-system.md) | 🥈 MVU 变量系统完整指南 | **仅用户要求时** |
| [`esj-stage-controller.md`](references/esj-stage-controller.md) | 🥈 ESJ 阶段控制器（动态世界书，EJS 写法） | **仅用户要求时** |
| [`character-deduction.md`](references/character-deduction.md) | 🥈 角色演绎法（内在矛盾 + 0–6 行动分级，有人味增强） | **仅用户要求时（可选）** |
| [`world-book-layering.md`](references/world-book-layering.md) | 🥈 世界书分层省 Token（庞大世界观 L0/L1/L2） | **仅庞大世界观时** |
| [`score-card-guide.md`](references/score-card-guide.md) | 🥈 角色卡质量打分测评（9 维度加权 + 自检表） | 评估/迭代时参考 |
| [`validation.md`](references/validation.md) | 验证清单 + 常见问题排查 | 验证/排错时参考 |
| [`templates.md`](references/templates.md) | 角色设定/背景/开场白模板 | 参考 |
| [`world-book.md`](references/world-book.md) | 世界书设计模式 | 参考 |
| [`config-reference.md`](references/config-reference.md) | YAML 配置文件完整字段参考 | 参考 |
| [`card-structure.md`](references/card-structure.md) | chara_card_v3 JSON 结构详解 | 参考 |

### 脚本（`scripts/`）

| 脚本 | 用途 | 调用时机 |
|------|------|----------|
| [`init-project.js`](scripts/init-project.js) | **项目初始化脚手架** | **Stage 1-2**：创建项目时自动调用 |
| [`build-card.js`](scripts/build-card.js) | **编译**：YAML → SillyTavern JSON | **Stage 9**：内容完成后自动编译 |
| [`validate-card.js`](scripts/validate-card.js) | **验证**：检查 JSON 完整性 | **Stage 10**：编译后自动验证 |
| [`unpack-card.js`](scripts/unpack-card.js) | **解包**：JSON → 源文件 | **Stage 8.5**：需要从已有卡导入资产时 |
| [`score-card.js`](scripts/score-card.js) | **评分**：JSON → S–D 质量分（9 维度加权） | 评估/迭代卡质量时 |

### 工具调用规则（Agent 工作流）

以下是 Agent 在各阶段自动调用工具的策略：

| 阶段 | Agent 操作 | 调用脚本 |
|------|-----------|----------|
| **Stage 2** | 创建项目骨架 | `node init-project.js` |
| **Stage 9** | 内容完成后自动编译 | `node build-card.js config.yaml` |
| **Stage 10** | 编译后自动验证 | `node validate-card.js 作品.json` |
| **Stage 11** | DoubleCheck 禁词扫描 | 按 `references/forbidden-words.md` 手动逐条检查 |

### Agent 配置

| 文件 | 用途 |
|------|------|
| [`agents/openai.yaml`](agents/openai.yaml) | AI Agent 默认提示词配置（路由逻辑 + 铁律 + 工具速查） |

### 示例

| 文件 | 用途 |
|------|------|
| [`examples/config.example.yaml`](examples/config.example.yaml) | 完整 YAML 配置示例（含所有字段） |

### 模板

| 路径 | 用途 |
|------|------|
| [`templates/MVU组件包/`](../../templates/MVU组件包/) | MVU 系统各组件模板（变量结构/InitVar/更新规则/状态栏） |
| [`templates/状态栏-风格/`](../../templates/状态栏-风格/) | 不同风格的状态栏 HTML 示例 |

---

## 命令详解

### 初始化项目

```bash
# 基础骨架（仅 config.yaml + 背景 + 角色设定 + 开场白）
node scripts/init-project.js "作品名称" --type basic --characters "角色名"

# 带 MVU 变量系统（basic + 变量结构 + 更新规则 + 输出格式 + 状态栏）
node scripts/init-project.js "作品名称" --type mvu --characters "角色名" --mvu "好感度,欲望值,体力值"

# 完整项目（mvu + 深度提示 + 世界书条目 + 对话示例）
node scripts/init-project.js "作品名称" --type full --characters "瑶姬,小月" --mvu "好感度,欲望值"
```

### 编译

```bash
# 在项目目录下
node ../skills/nova-write-card/scripts/build-card.js config.yaml

# 或直接从 skill 脚本目录
cd skills/nova-write-card/scripts && node build-card.js ../../projects/作品名称/config.yaml
```

编译脚本自动处理：
1. 读取 YAML 配置 → 解析字段、扩展、世界书条目
2. 生成正则脚本（对AI隐藏状态栏 → 去除更新变量 → 状态栏，执行顺序正确）
3. 生成 TavernHelper 脚本（MVU 变量管理 + 变量初始化）
4. 组装完整 `chara_card_v3` JSON → 写入文件
5. **自动版本管理**：输出 `作品名称_v001.json`（不覆盖旧文件），同时生成 `作品名称.json` 作为最新版快捷链接
6. **版本号自增**：`.card_version` 文件记录当前版本号，每次编译自动 +1

### 验证

```bash
# 标准模式
node scripts/validate-card.js 作品名称.json

# 详细模式
node scripts/validate-card.js 作品名称.json -v
```

验证项（40+ 项）：
1. JSON 语法合法性
2. 必填字段完整性（first_mes、description 等）
3. regex_scripts 完整性（状态栏、隐藏状态栏、去除更新变量）
4. tavern_helper 脚本完整性
5. 状态栏 JS 中 eventOn 事件监听 + setInterval 轮询保底
6. 世界书条目配置正确性（position、depth、role、constant、preventRecursion、excludeRecursion）
7. 禁词扫描（description / first_mes / entries content）
8. **关键词冲突分析** — 检查重复 key 和过度通用 key（借鉴 CardForge）
9. **Token 占用统计** — 常驻 vs 触发 token 比例、Top3 占用条目（借鉴 CardForge）
10. **八股化扫描** — 万能美人、性格标签、抽象形容、比喻禁词、作者视角（借鉴 CardForge）

### 解包

```bash
# 解包已有角色卡（用于修改）
node scripts/unpack-card.js my-character.json ./unpacked/
```

---

## Agent 配置参考

AI Agent 使用 [`agents/openai.yaml`](agents/openai.yaml) 配置默认提示词，包含：
- 路由逻辑（场景路由器）
- 工作流程指令
- 铁律执行
- 工具命令速查
- References 索引

如需修改 Agent 行为，编辑 `agents/openai.yaml` 中的 `default_prompt` 字段。

---

## 角色卡类型参考

| 类型 | 特点 | 主要参考 |
|------|------|----------|
| 基础聊天角色卡 | 单角色 + 简单设定 | [`card-writing-guide.md`](references/card-writing-guide.md) |
| 系统流角色卡 | 世界观系统 + 变量追踪 | [`world-book.md`](references/world-book.md) + [`config-guide.md`](references/config-guide.md) |
| 攻略/恋爱角色卡 | 好感度变量 + 选项系统 | [`mvu-system.md`](references/mvu-system.md) |
| 多角色合集卡 | 多角色世界书条目 | [`character-guide.md`](references/character-guide.md) + [`config-guide.md`](references/config-guide.md) |
| 转化提取卡 | 小说/游戏 → 角色卡 | [`conversion-guide.md`](references/conversion-guide.md) |
| 成人内容角色卡 | NSFW 设定 + 欲望变量 | [`card-writing-guide.md`](references/card-writing-guide.md) |

---

## 编写规范

### 变量占位符

```
[好感度]    → 在 YAML 和 .xyaml 中使用方括号引用变量
{{user}}    → 模板变量，编译时替换为玩家名称
{{char}}    → 模板变量，编译时替换为角色名称
```

### 文件格式

| 扩展名 | 用途 |
|--------|------|
| `.yaml` | YAML 配置文件及世界书条目 |
| `.xyaml` | XYAML（含变量占位符的 YAML） |
| `.txt` / `.md` | 纯文本内容（背景、开场白等） |
| `.js` | MVU Zod 变量结构定义 |
| `.html` | 状态栏模板 |

### 变量命名规范

- 使用中文命名（如 `好感度`、`欲望值`）
- 保持幂等——每次更新格式统一
- 数字类型优先使用字符串（如 `"50"`）以兼容 Zod coerce
- 状态类型使用布尔值或枚举字符串

---

## 验证清单

完成角色卡后，按顺序执行：

```bash
# 1. 自动验证
node scripts/validate-card.js 作品名称.json

# 2. DoubleCheck 禁词扫描
# 按 references/forbidden-words.md 逐条检查

# 3. 配置文件检查
# 按 references/validation.md 检查配置
```

也可参考 [`references/validation.md`](references/validation.md) 逐项手动检查。

---

## 项目结构示例

```
projects/作品名称/
├── config.yaml              # 编译配置
├── to-do.md                 # 创作清单
├── 背景设定.md               # 世界观背景
├── 角色设定_[角色名].xyaml   # 角色设定
├── 开场白.md                 # 开场白消息
├── 对话示例_[角色名].md      # 对话示例（可选）
├── 变量结构.js               # MVU Zod Schema（可选）
├── 变量初始化条目.yaml        # 变量初始值（可选）
├── 状态栏.html               # 状态栏 HTML（可选）
├── 深度提示.txt              # 深度提示（可选）
└── entries/                 # 世界书条目目录
    ├── 变量更新规则.yaml
    ├── 变量输出格式.yaml
    └── [其他条目].yaml
```
