import fs from 'fs';
import path from 'path';
import yaml from 'js-yaml';

/**
 * 读取文件内容
 */
function readFile(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    console.error(`读取文件失败: ${filePath}`);
    throw error;
  }
}

/**
 * 规范化路径(自动处理Windows/Mac路径分隔符)
 */
function normalizePath(filePath) {
  return path.normalize(filePath);
}

/**
 * 创建条目的固定结构
 */
function createEntryTemplate() {
  return {
    keys: [],
    secondary_keys: [],
    constant: true,
    selective: true,
    use_regex: true,
    extensions: {
      exclude_recursion: false,
      probability: 100,
      useProbability: true,
      selectiveLogic: 0,
      group: "",
      group_override: false,
      group_weight: 100,
      prevent_recursion: false,
      delay_until_recursion: false,
      scan_depth: null,
      match_whole_words: null,
      use_group_scoring: false,
      case_sensitive: null,
      automation_id: "",
      vectorized: false,
      sticky: 0,
      cooldown: 0,
      delay: 0,
      match_persona_description: false,
      match_character_description: false,
      match_character_personality: false,
      match_character_depth_prompt: false,
      match_scenario: false,
      match_creator_notes: false,
      triggers: [],
      ignore_budget: false
    }
  };
}

/**
 * 转换 position 字符串为数值
 */
function convertPosition(positionStr) {
  const positionMap = {
    'before_char': 0,
    'after_char': 1,
    'before_em': 5,
    'after_em': 6,
    'before_an': 2,
    'after_an': 3,
    'at_depth': 4
  };
  return positionMap[positionStr] ?? 0;
}

/**
 * 构建角色书条目
 */
function buildCharacterBookEntry(config, index) {
  const entry = createEntryTemplate();

  entry.id = index;
  entry.comment = config.comment;
  entry.content = config.content ? readFile(normalizePath(config.content)) : "";
  entry.enabled = config.enabled ?? true;
  // position 必须为数值（SillyTavern v3 规范要求 0-7）
  // 0=before_char, 1=after_char, 2=before_an, 3=after_an, 4=at_depth, 5=before_em, 6=after_em, 7=before_author_note
  entry.position = convertPosition(config.position ?? "after_char");
  // 统一使用 insertion_order，兼容旧的 order 字段
  entry.insertion_order = config.insertion_order ?? config.order ?? 100;

  // 读取世界书条目的关键字段
  entry.keys = config.keys ?? entry.keys;
  entry.secondary_keys = config.secondary_keys ?? entry.secondary_keys;
  entry.selective = config.selective ?? entry.selective;
  entry.constant = config.constant ?? entry.constant;
  entry.use_regex = config.use_regex ?? entry.use_regex;

  // 设置扩展字段（position 已在顶层设为数值，extensions.position 直接用同一数值）
  entry.depth = config.depth ?? 4;              // ★ 顶层 depth（SillyTavern v3 必需）
  entry.extensions.position = entry.position;
  entry.extensions.display_index = index;
  entry.extensions.depth = entry.depth;          // extensions 层 depth（兼容）
  entry.extensions.role = config.role ?? 0;
  entry.extensions.probability = config.probability ?? entry.extensions.probability;

  // 递归设置（铁律#2：所有条目必须同时设置 preventRecursion 和 excludeRecursion）
  // 默认值为 true，除非在 config 中显式设为 false
  // 注意：config 中的字段名是 prevent_recursion / exclude_recursion（下划线格式）
  const preventRec = config.prevent_recursion !== undefined ? config.prevent_recursion : true;
  const excludeRec = config.exclude_recursion !== undefined ? config.exclude_recursion : true;

  // extensions 层（下划线格式，SillyTavern 内部使用）
  entry.extensions.exclude_recursion = excludeRec;
  entry.extensions.prevent_recursion = preventRec;

  // 顶层字段（驼峰格式，SillyTavern 新格式支持，必须同时设置）
  entry.preventRecursion = preventRec;
  entry.excludeRecursion = excludeRec;

  // [initvar]初始化条目的特殊处理 - 强制非持续触发
  if (config.comment?.toLowerCase().includes('[initvar]')) {
    entry.constant = false;
  }

  return entry;
}

/**
 * 创建固定的 regex_scripts
 * 执行顺序（按数组下标）：
 *   1. 对AI隐藏状态栏（promptOnly: true）— 最先执行，AI 视角看不到状态栏占位符
 *   2. 去除更新变量（promptOnly: true）— 对 AI 隐藏 <UpdateVariable> 等标签
 *   3. 状态栏 / 文字版状态栏（promptOnly: false）— 用户视角替换占位符为状态栏内容
 */
function createRegexScripts(statusBarPath, textStatusBarPath) {
  const scripts = [];

  // 1. 对AI隐藏状态栏脚本（最先执行，promptOnly）
  // 作用：在发送给 AI 之前，将 <StatusPlaceHolderImpl/> 替换为空
  // 这样 AI 看不到状态栏 HTML，只看到用户可见的占位符被替换后的内容
  scripts.push({
    id: "9698c545-91a1-42c1-a4d5-486057de5d7a",
    scriptName: "对AI隐藏状态栏",
    disabled: false,
    runOnEdit: true,               // 需要 runOnEdit:true，确保编辑时也能从 prompt 中移除占位符
    findRegex: "/<StatusPlaceHolderImpl\\/>/g",
    replaceString: "",
    trimStrings: [],
    placement: [2],
    substituteRegex: 1,
    minDepth: null,
    maxDepth: null,
    markdownOnly: false,
    promptOnly: true               // 仅对 AI 生效
  });

  // 2. 去除更新变量脚本
  // 作用：在发送给 AI 之前，去除 <UpdateVariable>、<Analysis>、<JSONPatch> 标签
  scripts.push({
    id: "fc3d2d10-c7bc-41b8-8eb5-6d36151134c2",
    scriptName: "去除更新变量",
    disabled: false,
    runOnEdit: true,
    findRegex: "/<(UpdateVariable|Analysis|JSONPatch)>[\\s\\S]*?</\\1>/gm",
    replaceString: "",
    trimStrings: [],
    placement: [2],
    substituteRegex: 1,
    minDepth: null,
    maxDepth: null,
    markdownOnly: true,
    promptOnly: true
  });

  // 3. 状态栏脚本（用户视角）
  // 优先使用文字版状态栏，其次使用 HTML 状态栏
  if (textStatusBarPath) {
    let textStatusBarContent = readFile(normalizePath(textStatusBarPath));
    const openingLineStart = textStatusBarContent.indexOf('# 开场白');
    let statusBarContent = '';
    if (openingLineStart !== -1) {
      statusBarContent = textStatusBarContent.substring(0, openingLineStart).trim();
    } else {
      statusBarContent = textStatusBarContent.trim();
    }
    if (statusBarContent) {
      scripts.push({
        id: "text-status-bar-script",
        scriptName: "文字版状态栏",
        findRegex: "<StatusPlaceHolderImpl/>",
        replaceString: statusBarContent,
        trimStrings: [],
        placement: [2],
        disabled: false,
        markdownOnly: true,
        promptOnly: false,
        runOnEdit: true,
        substituteRegex: 0,
        minDepth: null,
        maxDepth: 0
      });
    }
  } else if (statusBarPath) {
    let statusBarContent = readFile(normalizePath(statusBarPath));
    if (statusBarContent) {
      // 自动用 Markdown 代码块包裹（SillyTavern 要求 replaceString 用 ``` 包裹才能执行 <script>）
      const wrappedContent = '```\n' + statusBarContent + '\n```';
      scripts.push({
        id: "0a826eea-6150-4ef8-b31b-0f10f6f12053",
        scriptName: "状态栏",
        findRegex: "/<StatusPlaceHolderImpl\\/>/g",
        replaceString: wrappedContent,
        trimStrings: [],
        placement: [2],
        disabled: false,
        markdownOnly: true,
        promptOnly: false,
        runOnEdit: true,
        substituteRegex: 1,
        minDepth: null,
        maxDepth: null        // null = 不限制深度，确保所有对话轮次都显示状态栏
      });
    }
  }

  return scripts;
}

/**
 * 创建 TavernHelper 脚本条目（扁平格式）
 * SillyTavern 要求 tavern_helper.scripts 中每个条目的属性在顶层，不能使用 value 包装
 */
function createScriptEntry({ id, name, content, info = "", buttons = [], data = {}, enabled = true }) {
  return {
    type: "script",
    enabled: enabled,
    name: name,
    id: id,
    content: content,
    info: info,
    button: {
      enabled: true,
      buttons: buttons
    },
    data: data,
    export_with: {
      data: true,
      button: true
    }
  };
}

/**
 * 创建 TavernHelper 脚本列表
 */
function createTavernHelperScripts(userScripts = [], variableInitPath = null) {
  const scripts = [
    createScriptEntry({
      id: "1f84fa2d-cd60-4015-be1b-cc801a8092be",
      name: "MVU Zod 脚本",
      content: "import 'https://testingcf.jsdelivr.net/gh/MagicalAstrogy/MagVarUpdate/artifact/bundle.js'",
      buttons: [
        { name: "重新处理变量", visible: false },
        { name: "重新读取初始变量", visible: false },
        { name: "清除旧楼层变量", visible: false }
      ],
      data: {
        "是否显示变量更新错误": "是",
        "构建信息": new Date().toISOString() + " (generated)"
      }
    })
  ];

  // 添加变量初始化脚本（从 [initvar] 条目自动生成）
  if (variableInitPath) {
    try {
      let content = readFile(normalizePath(variableInitPath));
      // 只处理第一个YAML文档（变量定义部分），忽略 --- 后面的变量处理指令集
      content = content.split('---')[0].trim();
      const data = yaml.load(content);

      const variables = {};

      function extractVariables(obj) {
        if (obj === null || typeof obj !== 'object') return;

        if (Array.isArray(obj)) {
          obj.forEach(item => {
            if (typeof item === 'string') {
              const parts = item.split(' - ');
              if (parts.length < 2) return;

              const nameValuePart = parts[0].split('：');
              if (nameValuePart.length !== 2) return;

              const variableName = nameValuePart[0].trim();
              const initialValue = nameValuePart[1].trim();

              const variableInfo = {
                initialValue: initialValue,
                type: '',
                description: '',
                visibility: '',
                displayName: variableName,
                unit: ''
              };

              for (let i = 1; i < parts.length; i++) {
                const attrParts = parts[i].split('：');
                if (attrParts.length === 2) {
                  const attrName = attrParts[0].trim();
                  const attrValue = attrParts[1].trim();
                  switch (attrName) {
                    case '类型': variableInfo.type = attrValue; break;
                    case '描述': variableInfo.description = attrValue; break;
                    case '初始值': variableInfo.initialValue = attrValue; break;
                    case '可见性': variableInfo.visibility = attrValue; break;
                    case '显示名称': variableInfo.displayName = attrValue; break;
                    case '单位': variableInfo.unit = attrValue; break;
                  }
                }
              }

              if (variableInfo.type) {
                let typedInitialValue = variableInfo.initialValue;
                if (variableInfo.type === '数字') {
                  typedInitialValue = Number(typedInitialValue);
                } else if (variableInfo.type === '布尔值') {
                  typedInitialValue = typedInitialValue === 'true' || typedInitialValue === 'True';
                } else if (variableInfo.type === '数组') {
                  const arrayStr = typedInitialValue.replace(/^[\[\]]/g, '').trim();
                  if (arrayStr) {
                    typedInitialValue = arrayStr.split(',').map(s => s.trim().replace(/^"|"$/g, ''));
                  } else {
                    typedInitialValue = [];
                  }
                } else if (variableInfo.type === '字符串') {
                  if ((typedInitialValue.startsWith('"') && typedInitialValue.endsWith('"')) ||
                      (typedInitialValue.startsWith("'") && typedInitialValue.endsWith("'"))) {
                    typedInitialValue = typedInitialValue.slice(1, -1);
                  }
                }

                variables[variableName] = {
                  type: variableInfo.type,
                  initialValue: typedInitialValue,
                  description: variableInfo.description,
                  visibility: variableInfo.visibility,
                  displayName: variableInfo.displayName,
                  unit: variableInfo.unit
                };
              }
            }
          });
        } else {
          for (const [key, value] of Object.entries(obj)) {
            let type = typeof value;
            if (Array.isArray(value)) {
              type = '数组';
            } else if (type === 'number') {
              type = '数字';
            } else if (type === 'boolean') {
              type = '布尔值';
            } else if (type === 'object' && value !== null) {
              type = 'object';
            } else {
              type = '字符串';
            }

            variables[key] = {
              type: type,
              initialValue: value,
              description: '',
              visibility: '',
              displayName: key,
              unit: ''
            };
          }
        }
      }

      extractVariables(data);

      if (Object.keys(variables).length > 0) {
        scripts.push(
          createScriptEntry({
            id: 'variable-init-script',
            name: '变量初始化',
            content: `
// 变量初始化
const initialVariables = ${JSON.stringify(variables, null, 2)};

function initializeVariables() {
  if (window.TavernHelper && window.TavernHelper.MVU) {
    window.TavernHelper.MVU.setInitialVariables(initialVariables);

    // 初始化后同步读取变量状态，确保 stat_data 已注册
    try {
      const allVars = window.TavernHelper.MVU.getAllVariables();
      if (allVars && typeof allVars === 'object') {
        // MVU Zod v2+ 返回 {name, variables: {initialValue: {...}}}，优先取 initialValue
        const initial = allVars.variables?.initialValue;
        if (initial && typeof initial === 'object' && Object.keys(initial).length > 0) {
          window.stat_data = initial;
        } else {
          // 降级到其他路径：stat_data → variables → allVars
          window.stat_data = allVars.stat_data || allVars.variables || allVars;
        }
      }
    } catch(e) { /* ignore */ }
  } else {
    setTimeout(initializeVariables, 100);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeVariables);
} else {
  initializeVariables();
}
`,
            info: '自动生成的变量初始化脚本',
            data: {}
          })
        );
      }
    } catch (error) {
      console.error('解析变量初始化文件失败:', error.message);
    }
  }

  // 添加用户自定义脚本（如变量结构设计 Zod Schema 脚本）
  if (userScripts && userScripts.length > 0) {
    userScripts.forEach((scriptConfig, index) => {
      const scriptPath = scriptConfig.content || scriptConfig.entry_point;
      if (scriptPath) {
        const scriptContent = readFile(normalizePath(scriptPath));
        scripts.push(
          createScriptEntry({
            id: `user-script-${index}`,
            name: scriptConfig.name || `用户脚本 ${index + 1}`,
            content: scriptContent,
            enabled: scriptConfig.enabled ?? true
          })
        );
      }
    });
  }

  return scripts;
}

/**
 * 构建完整的角色卡 JSON
 */
function buildCharacterCard(configPath) {
  // 读取配置文件
  const configContent = readFile(configPath);
  const config = yaml.load(configContent);

  // 读取字段内容：如果值是文件路径则读文件，否则作为内联文本直接使用
  const fields = {};
  const fileExtensions = ['.md', '.txt', '.yaml', '.xyaml', '.json'];
  for (const [key, value] of Object.entries(config.fields || {})) {
    if (!value) {
      fields[key] = "";
      continue;
    }
    // 判断是否为文件路径：包含目录分隔符，或有已知文件扩展名
    const isFilePath = /[/\\]/.test(value) || fileExtensions.some(ext => value.endsWith(ext));
    if (isFilePath) {
      fields[key] = readFile(normalizePath(value));
    } else {
      fields[key] = value; // 内联文本直接使用
    }
  }

  // 构建角色书条目
  const entries = [];
  if (config.character_book?.entries) {
    config.character_book.entries.forEach((entryConfig, index) => {
      entries.push(buildCharacterBookEntry(entryConfig, index));
    });
  }

  // 获取当前日期时间
  const now = new Date();
  const createDate = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()} @${now.getHours()}h ${now.getMinutes()}m ${now.getSeconds()}s ${now.getMilliseconds()}ms`;

  // 提取变量初始化文件路径
  let variableInitPath = null;
  if (config.character_book?.entries) {
    const initVarEntry = config.character_book.entries.find(entry =>
      entry.comment?.toLowerCase().includes('[initvar]')
    );
    if (initVarEntry && initVarEntry.content) {
      variableInitPath = initVarEntry.content;
    }
  }

  // 备选开场白获取：优先从 config.alternate_greetings 读取独立文件
  // 若无配置，回退到 ===== SEPARATOR ===== 分割 first_mes
  let alternateGreetings = [];
  if (config.alternate_greetings && config.alternate_greetings.length > 0) {
    const configDir = path.dirname(path.resolve(configPath));
    alternateGreetings = config.alternate_greetings
      .map(greeting => {
        if (typeof greeting === 'string') {
          const filePath = path.join(configDir, greeting);
          try { return readFile(filePath); } catch { return null; }
        } else if (typeof greeting === 'object' && greeting.path) {
          const filePath = path.join(configDir, greeting.path);
          try { return readFile(filePath); } catch { return null; }
        }
        return null;
      })
      .filter(Boolean);
  } else {
    // 按 ===== SEPARATOR ===== 分隔符拆分开场白
    const firstMesRaw = fields.first_mes || "";
    const firstMesParts = firstMesRaw.split(/\n\s*={5,}\s*SEPARATOR\s*={5,}\s*\n/).filter(p => p.trim());
    if (firstMesParts.length > 1) {
      fields.first_mes = firstMesParts[0].trim() + "\n";
      alternateGreetings = firstMesParts.slice(1).map(p => p.trim() + "\n");
    }
  }

  // 构建完整的角色卡结构
  // 注意：name 和 character_book.name 不带版本号，这里保持原样
  // 版本号后缀在主函数中统一追加（避免 SillyTavern 导入时覆盖旧版本）
  const card = {
    name: config.name,
    description: fields.description || "",
    personality: fields.personality || "",
    scenario: fields.scenario || "",
    first_mes: fields.first_mes || "",
    mes_example: fields.mes_example || "",
    creatorcomment: "",
    avatar: "none",
    talkativeness: config.extensions?.talkativeness || "0.5",
    fav: config.extensions?.fav || false,
    tags: config.tags || [],
    spec: "chara_card_v3",
    spec_version: "3.0",
    data: {
      name: config.name,
      description: fields.description || "",
      personality: fields.personality || "",
      scenario: fields.scenario || "",
      first_mes: fields.first_mes || "",
      mes_example: fields.mes_example || "",
      creator_notes: fields.creator_notes || "",
      system_prompt: fields.system_prompt || "",
      post_history_instructions: fields.post_history_instructions || "",
      tags: config.tags || [],
      creator: config.creator || "",
      character_version: config.character_version || "",
      alternate_greetings: alternateGreetings,
      extensions: {
        talkativeness: config.extensions?.talkativeness || "0.5",
        fav: config.extensions?.fav || false,
        world: config.extensions?.world || config.name,
        depth_prompt: {
          prompt: config.extensions?.depth_prompt?.prompt ? readFile(normalizePath(config.extensions.depth_prompt.prompt)) : "",
          depth: config.extensions?.depth_prompt?.depth ?? 4,
          role: config.extensions?.depth_prompt?.role ?? "system"
        },
        regex_scripts: [
          ...createRegexScripts(config.extensions?.status_bar, config.extensions?.text_status_bar),
          ...(config.extensions?.regex_scripts || [])
        ],
        tavern_helper: {
          scripts: createTavernHelperScripts(config.scripts, variableInitPath)
        }
      },
      group_only_greetings: [],
      character_book: {
        entries: entries,
        name: config.character_book?.name || config.name
      }
    },
    create_date: createDate
  };

  return card;
}

/**
 * 给角色卡名称追加版本号（用于 SillyTavern 中区分不同版本）
 * 修改以下字段：
 *   - card.name
 *   - card.data.name
 *   - card.data.character_book.name
 *   - card.data.extensions.world（如果等于原名）
 *
 * @param {object} card - 角色卡对象
 * @param {string} versionStr - 版本号字符串（如 "008"）
 * @returns {object} 修改后的角色卡
 */
function appendVersionToNames(card, version) {
  const suffix = `_v${version}`;

  card.name += suffix;
  card.data.name += suffix;

  if (card.data.character_book?.name) {
    card.data.character_book.name += suffix;
  }

  // 如果 extensions.world 等于原名，也加版本号
  if (card.data.extensions?.world) {
    card.data.extensions.world += suffix;
  }

  return card;
}

/**
 * 读取或初始化版本号文件
 * 版本号文件存放在 config.yaml 同级目录下的 .card_version
 */
function getVersion(configDir) {
  const versionFile = path.join(configDir, '.card_version');
  try {
    const ver = parseInt(fs.readFileSync(versionFile, 'utf-8').trim(), 10);
    return isNaN(ver) ? 1 : ver;
  } catch {
    return 1; // 文件不存在，初始版本号 1
  }
}

/**
 * 写入版本号
 */
function setVersion(configDir, version) {
  const versionFile = path.join(configDir, '.card_version');
  fs.writeFileSync(versionFile, String(version), 'utf-8');
}

/**
 * 主函数
 * 生成带版本号的角色卡，不覆盖原文件，便于回溯
 */
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.error('用法: node build-card.js <配置文件路径>');
    console.error('示例: node build-card.js config.yaml');
    process.exit(1);
  }

  const configPath = args[0];

  try {
    console.log(`正在读取配置文件: ${configPath}`);
    const card = buildCharacterCard(configPath);

    // 获取配置所在目录，用于存放版本号文件和输出
    const configDir = path.dirname(path.resolve(configPath));
    const baseName = card.name;

    // 读取当前版本号并自增
    const version = getVersion(configDir);
    const versionStr = String(version);

    // ★ 在写入 JSON 前给 card name 追加版本号（避免 SillyTavern 导入时覆盖旧版本）★
    appendVersionToNames(card, versionStr);

    // 输出文件名：名称_v版本号.json（如 林家秘事_v2_v1.json）
    const outputFile = `${baseName}_v${versionStr}.json`;
    const outputPath = path.join(configDir, outputFile);

    // 写入角色卡
    fs.writeFileSync(outputPath, JSON.stringify(card, null, 4), 'utf-8');

    // 更新版本号
    setVersion(configDir, version + 1);

    // 同时生成一个不带版本号的快捷链接（方便导入工具直接引用）
    const linkPath = path.join(configDir, `${baseName}.json`);
    fs.writeFileSync(linkPath, JSON.stringify(card, null, 4), 'utf-8');

    console.log(`✓ 角色卡已成功生成: ${outputFile} (v${versionStr})`);
    console.log(`  快捷链接: ${baseName}.json`);
    console.log(`  下次版本: v${version + 1}`);
  } catch (error) {
    console.error('构建失败:', error.message);
    process.exit(1);
  }
}

main();
