#!/usr/bin/env node

/**
 * validate-card.js — 角色卡编译后验证脚本
 *
 * 流水线 Stage 5 工具：验证编译后的 JSON 角色卡完整性。
 *
 * 用法:
 *   node validate-card.js <card.json> [选项]
 *
 * 选项:
 *   -v, --verbose   显示详细信息
 *   -h, --help      显示帮助信息
 *
 * 验证项:
 *   1. JSON 语法合法性
 *   2. chara_card_v3 标识
 *   3. 必填字段完整性（name、first_mes、description 等）
 *   4. regex_scripts 完整性（状态栏、隐藏状态栏、去除更新变量）
 *   5. tavern_helper / TavernHelper_scripts 完整性
 *   6. 状态栏 JS 中 eventOn 事件监听
 *   7. 世界书条目配置正确性
 *   8. 开场白中 <StatusPlaceHolderImpl/> 占位符
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ── 颜色 ──────────────────────────────────────────────────────────

const COLOR = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

function green(t) { return `${COLOR.green}${t}${COLOR.reset}`; }
function red(t) { return `${COLOR.red}${t}${COLOR.reset}`; }
function yellow(t) { return `${COLOR.yellow}${t}${COLOR.reset}`; }
function cyan(t) { return `${COLOR.cyan}${t}${COLOR.reset}`; }
function dim(t) { return `${COLOR.gray}${t}${COLOR.reset}`; }

// ── 验证报告 ──────────────────────────────────────────────────────

class Report {
  constructor() {
    this.passed = 0;
    this.failed = 0;
    this.warnings = 0;
    this.details = [];
    this.verbose = false;
  }

  pass(category, msg) {
    this.passed++;
    if (this.verbose) {
      console.log(`  ${green('✓')} ${dim(category)} ${msg}`);
    }
    this.details.push({ status: 'pass', category, msg });
  }

  warn(category, msg) {
    this.warnings++;
    console.log(`  ${yellow('⚠')} ${dim(category)} ${yellow(msg)}`);
    this.details.push({ status: 'warn', category, msg });
  }

  fail(category, msg) {
    this.failed++;
    console.log(`  ${red('✘')} ${dim(category)} ${red(msg)}`);
    this.details.push({ status: 'fail', category, msg });
  }

  summary() {
    const total = this.passed + this.failed + this.warnings;
    const passRate = total > 0 ? Math.round((this.passed / total) * 100) : 0;
    console.log('\n' + '='.repeat(50));
    console.log(`${cyan('📋 验证报告摘要')}`);
    console.log('='.repeat(50));
    console.log(`  ${green('通过')}: ${this.passed}`);
    console.log(`  ${yellow('警告')}: ${this.warnings}`);
    console.log(`  ${red('失败')}: ${this.failed}`);
    console.log(`  ${dim('通过率')}: ${passRate}%`);
    console.log('='.repeat(50));
    return { passed: this.passed, failed: this.failed, warnings: this.warnings, passRate };
  }

  toMarkdown(filename) {
    const lines = [];
    lines.push(`# 验证报告：${filename}`);
    lines.push('');
    lines.push(`| 结果 | 数量 |`);
    lines.push(`|------|------|`);
    lines.push(`| ✅ 通过 | ${this.passed} |`);
    lines.push(`| ⚠️ 警告 | ${this.warnings} |`);
    lines.push(`| ❌ 失败 | ${this.failed} |`);
    lines.push(`| 📊 通过率 | ${this.passed + this.warnings + this.failed > 0 ? Math.round((this.passed / (this.passed + this.warnings + this.failed)) * 100) : 100}% |`);
    lines.push('');
    lines.push('## 详细结果');
    lines.push('');
    this.details.forEach((d, i) => {
      const icon = d.status === 'pass' ? '✅' : d.status === 'warn' ? '⚠️' : '❌';
      lines.push(`### ${icon} ${d.category}`);
      lines.push(`**${d.status === 'pass' ? '通过' : d.status === 'warn' ? '警告' : '失败'}**: ${d.msg}`);
      lines.push('');
    });
    return lines.join('\n');
  }
}

// ── 验证函数 ──────────────────────────────────────────────────────

function validateJson(card, report) {
  // 1. chara_card_v3 标识
  if (card.spec === 'chara_card_v3') {
    report.pass('角色卡格式', `spec: ${card.spec}`);
  } else {
    report.fail('角色卡格式', `缺少 spec 字段或不是 chara_card_v3（当前: ${card.spec || 'undefined'}）`);
  }

  // 2. 必填顶层字段
  const requiredTopFields = ['name', 'description', 'personality', 'first_mes', 'mes_example'];
  requiredTopFields.forEach(field => {
    if (card[field] && card[field].toString().trim()) {
      const content = card[field].toString().trim();
      if (field === 'personality' && (content.includes('[在此填写') || content.includes('placeholder'))) {
        report.fail(`顶层字段: ${field}`, '内容为模板占位符，需要实际填写');
      } else {
        report.pass(`顶层字段: ${field}`, `已填写（${content.length} 字符）`);
      }
    } else {
      report.fail(`顶层字段: ${field}`, '为空或缺失');
    }
  });

  // 3. data 嵌套结构
  if (card.data) {
    report.pass('data 结构', '存在 data 字段');

    const requiredDataFields = ['name', 'description', 'personality', 'first_mes', 'mes_example'];
    requiredDataFields.forEach(field => {
      if (card.data[field] && card.data[field].toString().trim()) {
        report.pass(`data.${field}`, `已填写（${card.data[field].toString().length} 字符）`);
      } else {
        report.fail(`data.${field}`, '为空或缺失');
      }
    });
  } else {
    report.fail('data 结构', '缺少 data 字段');
  }
}

function validateExtensions(card, report) {
  const ext = card.data?.extensions || card.extensions;
  if (!ext) {
    report.warn('extensions', '缺少 extensions 字段');
    return;
  }

  if (ext.talkativeness !== undefined) {
    report.pass('extensions.talkativeness', String(ext.talkativeness));
  } else {
    report.warn('extensions.talkativeness', '未设置，建议设为 0.5');
  }

  if (ext.depth_prompt) {
    report.pass('extensions.depth_prompt', `存在 depth_prompt，深度: ${ext.depth_prompt.depth || '未设置'}`);
  } else {
    report.warn('extensions.depth_prompt', '未设置深度提示');
  }
}

function validateRegexScripts(card, report) {
  const extensions = card.data?.extensions || card.extensions;
  const scripts = extensions?.regex_scripts || [];

  if (scripts.length === 0) {
    report.fail('regex_scripts', '未找到任何正则脚本');
    return;
  }

  report.pass('regex_scripts', `共 ${scripts.length} 个正则脚本`);

  // 按 scriptName 查找
  const scriptMap = {};
  let missingHideScript = true;
  let missingRemoveScript = true;
  let missingStatusBarScript = true;

  scripts.forEach(s => {
    const name = s.scriptName || s.scriptName || '未命名';
    scriptMap[name] = s;

    if (name.includes('隐藏') || name.includes('hide')) {
      missingHideScript = false;
      // 验证 promptOnly
      if (s.promptOnly !== true) {
        report.warn(`正则脚本: ${name}`, 'promptOnly 应为 true（对AI隐藏）');
      } else {
        report.pass(`正则脚本: ${name}`, `promptOnly: ${s.promptOnly}`);
      }
      // promptOnly 的隐藏脚本需要 runOnEdit:true，确保编辑消息时也能从 prompt 中移除占位符
      if (s.runOnEdit === true) {
        report.pass(`正则脚本: ${name}`, `runOnEdit: ${s.runOnEdit}（promptOnly 脚本需要编辑时触发）`);
      } else {
        report.warn(`正则脚本: ${name}`, `runOnEdit: ${s.runOnEdit}，建议设为 true（确保编辑时也从 prompt 移除）`);
      }
    } else if (name.includes('去除') || name.includes('删除') || name.includes('remove')) {
      missingRemoveScript = false;
      if (s.markdownOnly !== true) {
        report.warn(`正则脚本: ${name}`, 'markdownOnly 应为 true（正则含特殊字符需要转义）');
      } else {
        report.pass(`正则脚本: ${name}`, `markdownOnly: ${s.markdownOnly}`);
      }
      if (s.promptOnly !== true) {
        report.warn(`正则脚本: ${name}`, 'promptOnly 应为 true（更新标签应对AI隐藏）');
      } else {
        report.pass(`正则脚本: ${name}`, `promptOnly: ${s.promptOnly}`);
      }
    } else if (name.includes('状态栏') || name.includes('status')) {
      missingStatusBarScript = false;
      if (s.markdownOnly !== true) {
        report.warn(`正则脚本: ${name}`, 'markdownOnly 应为 true（HTML 需要 Markdown 代码块包裹）');
      } else {
        report.pass(`正则脚本: ${name}`, `markdownOnly: ${s.markdownOnly}`);
      }
      if (s.promptOnly === true) {
        report.fail(`正则脚本: ${name}`, 'promptOnly 应为 false（状态栏应对用户可见）');
      } else {
        report.pass(`正则脚本: ${name}`, `promptOnly: ${s.promptOnly || false}`);
      }

      // 检查 replaceString 中是否包含 eventOn
      const replaceStr = s.replaceString || '';
      if (replaceStr.includes('eventOn')) {
        report.pass('状态栏: eventOn', 'replaceString 中包含 eventOn 事件监听');
      } else {
        report.warn('状态栏: eventOn', 'replaceString 中未找到 eventOn，状态栏可能不会自动刷新');
      }

      // 检查 replaceString 中是否包含 setInterval 轮询
      if (replaceStr.includes('setInterval')) {
        report.pass('状态栏: 轮询', 'replaceString 中包含 setInterval 轮询保底');
      } else {
        report.warn('状态栏: 轮询', '未找到 setInterval 轮询保底，建议添加');
      }

      // 检查 replaceString 是否用 Markdown 代码块包裹
      if (replaceStr.startsWith('```') || replaceStr.startsWith('~~~')) {
        report.pass('状态栏: 代码块包裹', 'replaceString 已用 Markdown 代码块包裹');
      } else {
        report.fail('状态栏: 代码块包裹', 'replaceString 未用 Markdown 代码块包裹（```），<script> 标签无法执行');
      }

      // ---- 新增：状态栏健壮性检查（6 项） ----

      // 1. 检查 getMvuData() 三级降级模式
      if (replaceStr.includes('getMvuData')) {
        report.pass('状态栏: getMvuData', 'replaceString 中包含 getMvuData() 三级降级函数');
      } else {
        report.fail('状态栏: getMvuData', 'replaceString 中未找到 getMvuData()，状态栏缺少三级降级保护');
      }

      // 2. 检查代码块无语言标签（不要 ```html，只要 ```）
      const codeBlockMatch = replaceStr.match(/^```(\w+)?\n/);
      if (codeBlockMatch && codeBlockMatch[1]) {
        const lang = codeBlockMatch[1];
        if (lang === 'html' || lang === 'javascript' || lang === 'js' || lang === 'css') {
          report.fail('状态栏: 无语言标签', `代码块使用了语言标签 \`\`\`${lang}，SillyTavern 不渲染带语言标签的 HTML，必须用 \`\`\` 无标签`);
        } else {
          report.warn('状态栏: 无语言标签', `代码块使用了非标准语言标签 \`\`\`${lang}`);
        }
      } else {
        report.pass('状态栏: 无语言标签', '代码块使用 ``` 无语言标签');
      }

      // 3. 检查 script type="module"
      if (replaceStr.includes('<script') && !replaceStr.includes('type="module"')) {
        report.fail('状态栏: script type', '<script> 标签缺少 type="module"，模块作用域可避免全局变量污染');
      } else if (replaceStr.includes('type="module"')) {
        report.pass('状态栏: script type', '<script> 标签使用 type="module"');
      }

      // 4. 检查 document.getElementById 前有存在性检查
      const getElementCalls = replaceStr.match(/document\.getElementById\(/g);
      if (getElementCalls && getElementCalls.length > 0) {
        // 简单检查：在 getElementById 附近是否有 if 或 guard
        const hasGuard = replaceStr.includes('if (') && (
          replaceStr.includes('getElementById') || replaceStr.includes('?.')
        );
        if (hasGuard) {
          report.pass('状态栏: 存在性检查', 'getElementById 调用附近有条件检查');
        } else {
          report.warn('状态栏: 存在性检查', 'getElementById 调用可能缺少 null 检查，建议使用 if (el) 保护');
        }
      }

      // 5. 检查数值变量有 Math.min/Math.max 边界限制
      if (replaceStr.includes('Math.min') || replaceStr.includes('Math.max')) {
        report.pass('状态栏: 边界限制', 'replaceString 中包含 Math.min/Math.max 数值边界限制');
      } else {
        report.warn('状态栏: 边界限制', '未找到 Math.min/Math.max，建议对进度条/数值变量添加边界限制');
      }

      // 6. 检查 init() 含延迟机制 + 轮询保底 + 清理旧轮询
      const hasDelay = replaceStr.includes('setTimeout') || replaceStr.includes('DOMContentLoaded');
      const hasPolling = replaceStr.includes('setInterval');
      const hasCleanup = replaceStr.includes('clearInterval') && (
        replaceStr.includes('_sbInterval') || replaceStr.includes('_pollTimer')
      );

      if (hasDelay) {
        report.pass('状态栏: 延迟机制', 'init() 包含 setTimeout/DOMContentLoaded 延迟初始化');
      } else {
        report.warn('状态栏: 延迟机制', 'init() 未找到延迟机制（setTimeout/DOMContentLoaded），建议添加');
      }

      if (hasPolling) {
        report.pass('状态栏: 轮询保底', '包含 setInterval 轮询保底');
      } else {
        report.warn('状态栏: 轮询保底', '未找到 setInterval 轮询保底，建议添加');
      }

      if (hasCleanup) {
        report.pass('状态栏: 清理旧轮询', '包含 clearInterval 清理旧轮询逻辑');
      } else {
        report.warn('状态栏: 清理旧轮询', '未找到 clearInterval 清理旧轮询，多次 init() 可能产生多个轮询');
      }
    }
  });

  if (missingHideScript) {
    report.fail('正则脚本', '缺少"对AI隐藏状态栏"脚本（用空字符串替换 <StatusPlaceHolderImpl/>，promptOnly: true）');
  }
  if (missingRemoveScript) {
    report.fail('正则脚本', '缺少"去除更新变量"脚本（移除 <UpdateVariable>/<Analysis>/<JSONPatch> 标签）');
  }
  if (missingStatusBarScript) {
    report.fail('正则脚本', '缺少"状态栏"脚本（替换 <StatusPlaceHolderImpl/> 为实际 HTML）');
  }
}

function validateTavernHelperScripts(card, report) {
  const extensions = card.data?.extensions || card.extensions;
  // 支持新旧命名空间
  let tavernScripts = extensions?.tavern_helper || extensions?.TavernHelper_scripts;

  // tavern_helper 可能是对象{scripts: [...]}或直接是数组
  if (tavernScripts && !Array.isArray(tavernScripts)) {
    tavernScripts = tavernScripts.scripts || Object.values(tavernScripts);
  }
  if (!Array.isArray(tavernScripts)) {
    tavernScripts = [];
  }

  if (tavernScripts.length === 0) {
    report.warn('tavern_helper 脚本', '未找到 tavern_helper 或 TavernHelper_scripts。如果没有使用 MVU Beta 则正常，如果使用了 MVU Zod 需要 tavern_helper 注入变量结构');
    return;
  }

  report.pass('tavern_helper 脚本', `共 ${tavernScripts.length} 个脚本`);

  // 检查是否包含变量初始化脚本
  let hasInitScript = false;
  tavernScripts.forEach(s => {
    const name = s.scriptName || s.name || '未命名';
    if (name.includes('初始化') || name.includes('init') || name.includes('variable')) {
      hasInitScript = true;
      report.pass(`tavern_helper: ${name}`, '存在变量初始化脚本');

      // 检查脚本内容
      const content = s.content || '';
      if (content.includes('z.object') || content.includes('VariableSchema')) {
        report.pass(`tavern_helper: ${name} Zod`, '脚本包含 Zod Schema 定义');
      } else if (content.includes('getAllVariables') || content.includes('stat_data')) {
        report.pass(`tavern_helper: ${name} 变量`, '脚本包含变量操作');
      } else {
        report.warn(`tavern_helper: ${name}`, '脚本内容较短，确认是否正确');
      }
    }
  });

  if (!hasInitScript) {
    report.warn('tavern_helper 脚本', '未找到包含"初始化"或"variable"的脚本。如果使用了 MVU Zod，请确认变量结构已正确注入');
  }
}

// ── 关键词冲突分析（借鉴 CardForge diagnostic-checks.js） ──────────

function validateKeywordConflicts(card, report) {
  const entries = card.data?.character_book?.entries || [];
  const enabledTriggered = entries.filter(e => e.enabled && !e.constant);

  if (enabledTriggered.length === 0) return;

  // 收集所有 keys + 来源条目
  const keyMap = {};
  for (const e of enabledTriggered) {
    for (const k of (e.keys || [])) {
      const trimmed = String(k).trim();
      if (!trimmed) continue;
      if (!keyMap[trimmed]) keyMap[trimmed] = [];
      keyMap[trimmed].push({ id: e.id, comment: e.comment || '(未命名)' });
    }
  }

  // 同一关键词触发多个条目
  for (const [k, list] of Object.entries(keyMap)) {
    if (list.length > 1) {
      report.warn('关键词冲突', `关键词「${k}」会同时触发 ${list.length} 个条目（${list.map(l => `#${l.id} ${l.comment}`).join(' / ')}），建议改用更精确的关键词`);
    }
  }

  // 过度通用关键词检测
  const tooCommon = ['的', '了', '是', '在', '有', '修炼', '等级', '系统', '世界', '人物', '角色', '她', '他', '我', '你'];
  for (const k of Object.keys(keyMap)) {
    if (tooCommon.includes(k)) {
      report.fail('关键词冲突', `关键词「${k}」过度通用，会乱触发（条目: ${keyMap[k].map(l => `#${l.id} ${l.comment}`).join(' / ')}）`);
    }
  }
}

// ── Token 占用统计（借鉴 CardForge diagnostic-checks.js） ──────────

function validateTokenUsage(card, report) {
  const entries = card.data?.character_book?.entries || [];
  if (entries.length === 0) return;

  // 每条目 token 估算
  const ranked = entries
    .filter(e => e.enabled)
    .map(e => ({
      id: e.id,
      comment: e.comment || '(未命名)',
      constant: e.constant,
      chars: (e.content || '').length,
      tokens: Math.round((e.content || '').length * 1.3)
    }))
    .sort((a, b) => b.tokens - a.tokens);

  const constantTokens = ranked.filter(e => e.constant).reduce((s, e) => s + e.tokens, 0);
  const triggeredTokens = ranked.filter(e => !e.constant).reduce((s, e) => s + e.tokens, 0);
  const totalTokens = constantTokens + triggeredTokens;

  // 常驻条目超过 8000 token 警告
  if (constantTokens > 8000) {
    report.warn('Token 占用', `常驻条目总 token 偏多（~${constantTokens}），建议把不必要的改成绿灯触发`);
  }

  // 总 token 超过 15000 警告
  if (totalTokens > 15000) {
    report.warn('Token 占用', `世界书总 token 偏多（~${totalTokens}），可能挤占对话上下文空间`);
  }

  // Top 3 占用条目
  const top3 = ranked.slice(0, 3);
  if (top3.length > 0) {
    const top3Str = top3.map(t => `#${t.id} ${t.comment}（~${t.tokens} token${t.constant ? ' 蓝灯' : ''}）`).join('；');
    report.pass('Token 占用', `常驻 ~${constantTokens} / 触发 ~${triggeredTokens} / 总 ~${totalTokens} token。Top3: ${top3Str}`);
  }
}

// ── 八股化扫描（借鉴 CardForge npc-checker.js） ────────────────────

const BAGUA_PATTERNS = [
  // 万能美人描写
  { pattern: /精致的脸蛋/g, type: '万能美人', suggest: '改为具体特征描述' },
  { pattern: /白皙的皮肤/g, type: '万能美人', suggest: '改为具体肤色描述' },
  { pattern: /桃花眼/g, type: '万能美人', suggest: '改为具体眼型描述' },
  { pattern: /柳叶眉/g, type: '万能美人', suggest: '改为具体眉形描述' },
  { pattern: /樱桃小口/g, type: '万能美人', suggest: '改为具体嘴型描述' },
  { pattern: /吹弹可破/g, type: '万能美人', suggest: '改为具体肤质描述' },
  { pattern: /倾国倾城/g, type: '万能美人', suggest: '改为具体外貌特征' },
  { pattern: /沉鱼落雁/g, type: '万能美人', suggest: '改为具体外貌特征' },
  // 性格标签化
  { pattern: /性格温柔/g, type: '性格标签', suggest: '改为具体行为描述' },
  { pattern: /性格善良/g, type: '性格标签', suggest: '改为具体行为描述' },
  { pattern: /性格开朗/g, type: '性格标签', suggest: '改为具体行为描述' },
  { pattern: /性格内向/g, type: '性格标签', suggest: '改为具体行为描述' },
  { pattern: /性格活泼/g, type: '性格标签', suggest: '改为具体行为描述' },
  // 抽象形容
  { pattern: /一丝[^不]/g, type: '抽象形容', suggest: '改为具体描写' },
  { pattern: /一缕/g, type: '抽象形容', suggest: '改为具体描写' },
  { pattern: /一抹/g, type: '抽象形容', suggest: '改为具体描写' },
  { pattern: /不易察觉/g, type: '抽象形容', suggest: '删除或改为动作描写' },
  { pattern: /不易觉察/g, type: '抽象形容', suggest: '删除或改为动作描写' },
  { pattern: /难以察觉/g, type: '抽象形容', suggest: '删除或改为动作描写' },
  { pattern: /鲜明对比/g, type: '抽象形容', suggest: '直接描述事实' },
  { pattern: /形成对比/g, type: '抽象形容', suggest: '直接描述事实' },
  // 比喻禁词
  { pattern: /石子投入湖面/g, type: '比喻禁词', suggest: '直接描写' },
  { pattern: /拉满的弓/g, type: '比喻禁词', suggest: '直接描写' },
  { pattern: /琴弦[^.]*颤动/g, type: '比喻禁词', suggest: '直接描写' },
  { pattern: /划破夜空/g, type: '比喻禁词', suggest: '直接描写' },
  // 作者视角
  { pattern: /仿佛[^。]*般/g, type: '作者视角', suggest: '改为白描' },
  { pattern: /似乎[^。]*般/g, type: '作者视角', suggest: '改为白描' },
  { pattern: /像是[^。]*般/g, type: '作者视角', suggest: '改为白描' },
];

function scanBagua(text) {
  const issues = [];
  for (const p of BAGUA_PATTERNS) {
    const matches = text.match(p.pattern);
    if (matches) {
      issues.push({ type: p.type, count: matches.length, suggest: p.suggest, words: [...new Set(matches)] });
    }
  }
  return issues;
}

function validateWritingQuality(card, report) {
  const fields = [
    { key: 'description', label: 'description' },
    { key: 'personality', label: 'personality' },
    { key: 'scenario', label: 'scenario' },
    { key: 'first_mes', label: 'first_mes' },
    { key: 'mes_example', label: 'mes_example' }
  ];

  let totalBagua = 0;
  const data = card.data || card;

  for (const f of fields) {
    const text = data[f.key] || '';
    if (!text) continue;
    const issues = scanBagua(text);
    totalBagua += issues.reduce((s, i) => s + i.count, 0);

    for (const issue of issues) {
      report.warn(`写作质量: ${f.label}`, `含 ${issue.type}（${issue.count} 处）— ${issue.suggest}。命中词: ${issue.words.slice(0, 3).join('、')}`);
    }
  }

  // 世界书条目八股扫描
  const entries = card.data?.character_book?.entries || [];
  for (const e of entries) {
    if (!e.enabled || !e.content) continue;
    const issues = scanBagua(e.content);
    if (issues.length > 0) {
      const summary = issues.map(i => `${i.type}×${i.count}`).join('、');
      report.warn(`写作质量: 条目「${e.comment || '(未命名)'}」`, `含八股化（${summary}）`);
      totalBagua += issues.reduce((s, i) => s + i.count, 0);
    }
  }

  if (totalBagua === 0) {
    report.pass('写作质量', '未发现八股化表达');
  }
}

// ── 修改后的 validateCharacterBook ──────────────────────────────────

function validateCharacterBook(card, report) {
  const charBook = card.data?.character_book;
  if (!charBook) {
    report.warn('character_book', '不存在 character_book（世界书）');
    return;
  }

  const entries = charBook.entries || [];
  if (entries.length === 0) {
    report.warn('character_book', '世界书条目为空');
    return;
  }

  report.pass('character_book', `共 ${entries.length} 个世界书条目`);

  // 检查关键条目
  let hasInitVarEntry = false;
  let hasUpdateRuleEntry = false;
  let hasOutputFormatEntry = false;

  entries.forEach((entry, i) => {
    const comment = entry.comment || entry.entryName || `条目 #${i + 1}`;
    const pos = entry.position;
    const depth = entry.depth;

    // 检查 position
    const validPositions = ['before_char', 'after_char', 'at_depth'];
    if (pos && !validPositions.includes(pos)) {
      report.warn(`世界书: ${comment}`, `position 值"${pos}"非标准值（标准: ${validPositions.join(', ')}）`);
    }

    // 检查 depth 合理性
    if (depth !== undefined && depth !== null) {
      if (depth < 1) {
        report.warn(`世界书: ${comment}`, `depth 为 ${depth}，建议至少 1`);
      }
    }

    // 检查角色值
    const role = entry.role;
    if (role !== undefined && ![0, 1, 2, 4].includes(role)) {
      report.warn(`世界书: ${comment}`, `role 值为 ${role}，标准值: 0=系统 1=用户 2=助手 4=角色`);
    }

    // 🔥 检查递归防止字段（铁律#2）
    const prevRec = entry.preventRecursion ?? entry.extensions?.prevent_recursion;
    const exclRec = entry.excludeRecursion ?? entry.extensions?.exclude_recursion;

    if (prevRec === true) {
      report.pass(`世界书: ${comment}`, 'preventRecursion: true（不触发其他条目）');
    } else if (prevRec === undefined) {
      report.fail(`世界书: ${comment}`, 'preventRecursion 缺失（顶层和 extensions 均无此字段，会导致连锁递归）');
    } else {
      report.fail(`世界书: ${comment}`, `preventRecursion 为 ${prevRec}，应为 true（缺少此字段会导致连锁递归）`);
    }

    if (exclRec === true) {
      report.pass(`世界书: ${comment}`, 'excludeRecursion: true（不被其他条目触发）');
    } else if (exclRec === undefined) {
      report.fail(`世界书: ${comment}`, 'excludeRecursion 缺失（顶层和 extensions 均无此字段，会导致双向递归）');
    } else {
      report.fail(`世界书: ${comment}`, `excludeRecursion 为 ${exclRec}，应为 true（缺少此字段会导致双向递归）`);
    }

    // 🔥 检查绿灯条目的 keys 格式（英文逗号）
    if (entry.constant === false && entry.keys && entry.keys.length > 0) {
      entry.keys.forEach(keyItem => {
        if (typeof keyItem === 'string' && keyItem.includes('，')) {
          report.fail(`世界书: ${comment}`, `keys 使用了中文逗号"，"，应改为英文逗号","（关键词: "${keyItem}"）`);
        } else if (typeof keyItem === 'string' && keyItem.includes(', ')) {
          report.warn(`世界书: ${comment}`, `keys 逗号后有空格"，"，建议改为无空格","（关键词: "${keyItem}"）`);
        }
      });
    }

    // 识别关键条目
    if (comment.toLowerCase().includes('initvar') || comment.toLowerCase().includes('初始化')) {
      hasInitVarEntry = true;
      if (entry.enabled === false) {
        report.pass(`世界书: ${comment}`, 'enabled: false（InitVar 条目正确禁用）');
      } else {
        report.warn(`世界书: ${comment}`, 'enabled 应为 false（InitVar 条目应禁用，仅在启动时使用）');
      }
    }
    if (comment.toLowerCase().includes('mvu_update') || comment.toLowerCase().includes('更新规则')) {
      hasUpdateRuleEntry = true;
    }
    if (comment.toLowerCase().includes('输出格式')) {
      hasOutputFormatEntry = true;
      const content = entry.content || '';
      if (content.includes('<JSONPatch>')) {
        report.pass(`世界书: ${comment}`, '内容包含 <JSONPatch> 标签（MVU Zod 标准格式）');
      } else if (content.includes('<UpdateVariable>')) {
        report.warn(`世界书: ${comment}`, '包含 <UpdateVariable> 但缺少 <JSONPatch> 子标签，确认格式正确');
      }
    }
  });

  if (!hasInitVarEntry) {
    report.warn('世界书', '未找到 [initvar] 变量初始化条目（如果使用 MVU 动态变量则必须）');
  }
  if (!hasUpdateRuleEntry) {
    report.warn('世界书', '未找到 MVU 变量更新规则条目（告诉AI何时以及如何更新变量）');
  }
  if (!hasOutputFormatEntry) {
    report.warn('世界书', '未找到变量输出格式条目（告诉AI变量输出的具体格式）');
  }
}

function validateFirstMes(card, report) {
  const firstMes = card.first_mes || card.data?.first_mes || '';
  const altGreetings = card.data?.alternate_greetings || [];

  if (firstMes.includes('<StatusPlaceHolderImpl/>')) {
    report.pass('开场白占位符', '包含 <StatusPlaceHolderImpl/> 占位符');
  } else {
    report.warn('开场白占位符', '未找到 <StatusPlaceHolderImpl/> 占位符，状态栏将无法显示');
  }

  // 🔥 备选开场白完整性检查（Bug 2 修复）
  if (altGreetings.length > 0) {
    report.pass('备选开场白', `共 ${altGreetings.length} 条备选（使用 ===== SEPARATOR ===== 分隔）`);
    // 如果备选超过 5 条，提示可能有误分割
    if (altGreetings.length > 10) {
      report.fail('备选开场白', `备选数量异常多（${altGreetings.length} 条），可能是分隔符匹配错误导致过度分割`);
    }
  } else {
    // 没有备选但开场白很短 → 可能是应该用分隔符但没用
    if (firstMes.length > 0 && firstMes.length < 800) {
      report.warn('备选开场白', '无备选开场白，且 first_mes 较短（<' + firstMes.length + ' 字符）。如果预期有多幕开场白，请在源文件中用 ===== SEPARATOR ===== 分隔');
    }
  }

  // 🔥 检查 first_mes 源文件中是否包含 --- 行（兼容旧版混淆）
  const totalContent = firstMes + altGreetings.join('\n');
  const dashLineCount = (totalContent.match(/\n\s*-{3,}\s*\n/g) || []).length;
  if (dashLineCount > 0) {
    report.warn('开场白: --- 违规', `first_mes 中包含 ${dashLineCount} 个 Markdown 分隔线"---"。旧版编译脚本曾用 "---" 作为备选开场分割符，新版已改为 "===== SEPARATOR ====="。如果这不是有意分隔的场景过渡，请将 "---" 改为其他形式（如 "∗∗∗"）。`);
  }
}

function validateFileSize(card, report, fileSize) {
  const sizeKB = (fileSize / 1024).toFixed(1);
  if (fileSize > 1024 * 1024) {
    report.warn('文件大小', `${sizeKB} KB — 文件过大，可能影响 SillyTavern 加载性能`);
  } else if (fileSize < 1024) {
    report.warn('文件大小', `${sizeKB} KB — 文件过小，可能缺少内容`);
  } else {
    report.pass('文件大小', `${sizeKB} KB`);
  }
}

// ── 主函数 ────────────────────────────────────────────────────────

function showHelp() {
  const help = `
  角色卡验证脚本 — validate-card.js
  ===================================

  用法:
    node validate-card.js <card.json> [选项]

  选项:
    -v, --verbose   显示详细信息
    -h, --help      显示帮助信息

  示例:
    node validate-card.js 神豪系统.json
    node validate-card.js 神豪系统.json -v
    node validate-card.js projects/神豪系统/神豪系统.json
  `;
  console.log(help);
  process.exit(0);
}

function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args.includes('-h') || args.includes('--help')) {
    showHelp();
  }

  const verbose = args.includes('-v') || args.includes('--verbose');
  const jsonPath = args.filter(a => !a.startsWith('-'))[0];

  if (!jsonPath) {
    console.error('❌ 请指定 JSON 文件路径');
    showHelp();
  }

  const fullPath = path.resolve(process.cwd(), jsonPath);

  if (!fs.existsSync(fullPath)) {
    console.error(`❌ 文件不存在: ${fullPath}`);
    process.exit(1);
  }

  console.log(`\n${cyan('🔍 验证角色卡:')} ${fullPath}\n`);

  const report = new Report();
  report.verbose = verbose;

  // Step 1: 读取并解析 JSON
  try {
    const raw = fs.readFileSync(fullPath, 'utf-8');
    const fileSize = Buffer.byteLength(raw, 'utf-8');
    const card = JSON.parse(raw);
    report.pass('JSON 语法', '有效 JSON');

    // 验证各项
    validateFileSize(card, report, fileSize);
    validateJson(card, report);
    validateExtensions(card, report);
    validateRegexScripts(card, report);
    validateTavernHelperScripts(card, report);
    validateCharacterBook(card, report);
    validateKeywordConflicts(card, report);   // 🔥 新增：关键词冲突分析
    validateTokenUsage(card, report);         // 🔥 新增：Token 占用统计
    validateWritingQuality(card, report);     // 🔥 新增：八股化扫描
    validateFirstMes(card, report);

  } catch (e) {
    if (e instanceof SyntaxError) {
      report.fail('JSON 语法', `解析失败: ${e.message}`);
    } else {
      report.fail('读取文件', e.message);
    }
  }

  // 输出摘要
  const result = report.summary();

  // 保存验证报告
  const reportDir = path.dirname(fullPath);
  const baseName = path.basename(fullPath, '.json');
  const reportPath = path.join(reportDir, `${baseName}-验证报告.md`);
  fs.writeFileSync(reportPath, report.toMarkdown(path.basename(fullPath)), 'utf-8');
  console.log(`\n📄 验证报告已保存: ${dim(reportPath)}`);
  console.log('');

  // 退出码
  if (result.failed > 0) {
    process.exit(1);
  }
}

main();
