#!/usr/bin/env node

/**
 * init-project.js — 角色卡项目初始化脚手架
 *
 * 流水线 Stage 1 工具：一键创建新角色卡项目骨架。
 *
 * 用法:
 *   node init-project.js "作品名称" [选项]
 *
 * 选项:
 *   --type <basic|mvu|full>      项目类型（默认: basic）
 *   --characters "角色A,角色B"   角色名称列表
 *   --mvu "好感度,欲望值,剧情阶段" MVU 变量名列表
 *   -h, --help                   显示帮助信息
 *
 * 项目类型说明:
 *   basic - 最小骨架（config.yaml + 背景 + 角色设定 + 开场白）
 *   mvu   - 带 MVU 变量系统（basic + 变量结构 + 初始化 + 更新规则 + 输出格式 + 状态栏）
 *   full  - 完整项目（mvu + 深度提示 + 世界书条目模板 + 对话示例）
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ── 路径 ──────────────────────────────────────────────────────────

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECTS_DIR = path.resolve(__dirname, '../../projects');
const TEMPLATES_DIR = path.resolve(__dirname, '../../templates');

// ── 帮助信息 ───────────────────────────────────────────────────────

function showHelp() {
  const help = `
  角色卡项目初始化脚手架 — init-project.js
  =========================================

  用法:
    node init-project.js "作品名称" [选项]

  选项:
    --type <basic|mvu|full>      项目类型（默认: basic）
    --characters "角色A,角色B"   角色名称列表（默认: "主角"）
    --mvu "好感度,欲望值,剧情阶段" MVU 变量名列表

  项目类型:
    basic  基础骨架 — config.yaml、背景设定、角色设定、开场白
    mvu    带 MVU 系统 — basic + 变量结构、初始化、更新规则、输出格式、状态栏
    full   完整项目 — mvu + 深度提示、世界书条目模板、对话示例

  示例:
    node init-project.js "我的新作品"
    node init-project.js "我的新作品" --type mvu --characters "瑶姬"
    node init-project.js "我的新作品" --type full --characters "瑶姬,小月" --mvu "好感度,欲望值,体力值"
  `;
  console.log(help);
  process.exit(0);
}

// ── 参数解析 ───────────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args.includes('-h') || args.includes('--help')) {
    showHelp();
  }

  const projectName = args[0];
  const options = {
    type: 'basic',
    characters: ['主角'],
    mvu: [],
  };

  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--type':
        if (i + 1 < args.length) {
          const type = args[++i].toLowerCase();
          if (['basic', 'mvu', 'full'].includes(type)) {
            options.type = type;
          } else {
            console.error(`❌ 无效的项目类型: "${type}"。可用值: basic, mvu, full`);
            process.exit(1);
          }
        }
        break;
      case '--characters':
        if (i + 1 < args.length) {
          options.characters = args[++i].split(',').map(s => s.trim()).filter(Boolean);
        }
        break;
      case '--mvu':
        if (i + 1 < args.length) {
          options.mvu = args[++i].split(',').map(s => s.trim()).filter(Boolean);
        }
        break;
      default:
        break;
    }
  }

  return { projectName, options };
}

// ── 文件写入辅助 ───────────────────────────────────────────────────

function writeFile(filePath, content) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(filePath, content.trimStart() + '\n', 'utf-8');
  console.log(`  ✓ ${path.relative(PROJECTS_DIR, filePath)}`);
}

// ── 模板内容 ───────────────────────────────────────────────────────

function createConfigYaml(projectName, options) {
  const { characters, type } = options;
  const mainChar = characters[0];
  const isMvu = type === 'mvu' || type === 'full';

  let config = `# ${projectName} — build-card.js 编译配置
name: "${projectName}"
tags: ["${projectName}", "角色扮演"]

fields:
  description: "背景设定.md"
  personality: "角色设定_${mainChar}.xyaml"
  scenario: ""
  first_mes: "开场白.md"
  mes_example: ""
  creator_notes: ""
  system_prompt: ""
  post_history_instructions: ""

extensions:
  talkativeness: "0.5"
  fav: false
  world: "${projectName}"
`;

  if (type === 'full') {
    config += `  depth_prompt:
    prompt: "深度提示.txt"
    depth: 4
    role: "system"
`;
  }

  if (isMvu) {
    config += `  status_bar: "状态栏.html"
`;
  }

  config += `
scripts:`;

  if (isMvu) {
    config += `
  # 变量结构设计脚本（Zod Schema）
  - name: "变量结构设计"
    content: "变量结构.js"
    enabled: true
`;
  }

  config += `
character_book:
  name: "${projectName}"
  entries:`;

  if (isMvu) {
    config += `
    # === MVU 核心条目（必须，否则 stat_data 不会初始化）===

    # 变量初始化（禁用，仅作为数据参考）
    - keys: []
      content: "变量初始化条目.yaml"
      position: before_char
      depth: 4
      insertion_order: 101
      role: 0
      enabled: false
      constant: false
      prevent_recursion: true
      exclude_recursion: true
      comment: "[initvar]变量初始化"

    # MVU 变量更新规则（必须！at_depth位置，告诉AI如何输出UpdateVariable）
    - keys: []
      content: "entries/变量更新规则.yaml"
      position: at_depth
      depth: 1
      insertion_order: 1
      role: 0
      enabled: true
      constant: true
      prevent_recursion: true
      exclude_recursion: true
      comment: "[mvu_update]变量更新规则"

    # MVU 变量输出格式（必须！注入当前变量状态）
    - keys: []
      content: "entries/变量输出格式.yaml"
      position: at_depth
      depth: 1
      insertion_order: 2
      role: 0
      enabled: true
      constant: true
      prevent_recursion: true
      exclude_recursion: true
      comment: "[mvu_update]变量输出格式"

    # === 内容条目 ===
`;
  }

  // Character book entries for each character
  characters.forEach((char, index) => {
    const order = isMvu ? 3 + index : 1 + index;
    config += `
    # ${char} — 角色设定
    - keys: ["${char}"]
      content: "entries/角色设定_${char}.yaml"
      position: before_char
      depth: 4
      insertion_order: ${order}
      role: 0
      enabled: true
      constant: true
      prevent_recursion: true
      exclude_recursion: true
      comment: "${char}"
`;
  });

  // Background entry
  const bgOrder = characters.length + (isMvu ? 3 : 1);
  config += `
    # 背景设定
    - keys: ["世界观", "背景", "设定"]
      content: "entries/背景设定.yaml"
      position: before_char
      depth: 4
      insertion_order: ${bgOrder}
      role: 0
      enabled: true
      constant: true
      prevent_recursion: true
      exclude_recursion: true
      comment: "背景设定"
`;

  return config;
}

function createTodoMd(projectName, options) {
  const { type, characters, mvu } = options;
  const isMvu = type === 'mvu' || type === 'full';
  const charList = characters.join('、');

  let todo = `# ${projectName} — 创作清单

## Stage 1：需求分析 ✅ 已完成

- [x] 初始化项目骨架 — \`init-project.js\`

## Stage 2：内容创作

### 2.1 背景设定
- [ ] 填写 \`背景设定.md\` — 世界观、时代背景、核心设定

### 2.2 角色设定
`;

  characters.forEach(char => {
    todo += `- [ ] 填写 \`角色设定_${char}.xyaml\` — 外貌、性格、背景、台词示例\n`;
    todo += `- [ ] 填写 \`对话示例_${char}.md\` （可选）\n`;
  });

  todo += `
### 2.3 开场白
- [ ] 填写 \`开场白.md\` — 确保包含 \`<StatusPlaceHolderImpl/>\` 占位符

### 2.4 世界书条目
`;

  if (type === 'full') {
    todo += `- [ ] 填写 \`entries/背景设定.yaml\`
`;
    characters.forEach(char => {
      todo += `- [ ] 填写 \`entries/角色设定_${char}.yaml\`
`;
    });
  }

  todo += `- [ ] 创建其他世界书条目（如需要）

`;

  if (isMvu) {
    todo += `## Stage 3：MVU 系统装配

### 3.1 变量结构设计
- [ ] 编辑 \`变量结构.js\` — 定义 Zod Schema

### 3.2 变量初始化
`;

    if (mvu.length > 0) {
      todo += `- [ ] 编辑 \`变量初始化条目.yaml\` — 为变量设置初始值\n`;
      todo += `  - 变量列表：${mvu.join('、')}\n`;
    } else {
      todo += `- [ ] 编辑 \`变量初始化条目.yaml\` — 为变量设置初始值\n`;
    }

    todo += `
### 3.3 变量更新规则
- [ ] 编辑 \`entries/变量更新规则.yaml\` — 告诉 AI 何时增减变量

### 3.4 变量输出格式
- [ ] 编辑 \`entries/变量输出格式.yaml\` — 告诉 AI 如何输出 \`<UpdateVariable>\`

### 3.5 状态栏
- [ ] 编辑 \`状态栏.html\` — 可视化显示变量值

`;

  }

  todo += `## Stage 4：编译打包

- [ ] 运行 \`node ../skills/nova-write-card/scripts/build-card.js config.yaml\`
- [ ] 检查生成的 \`${projectName}.json\`

## Stage 5：验证输出

- [ ] 运行 \`node ../skills/nova-write-card/scripts/validate-card.js ${projectName}.json\`
- [ ] 将 JSON 导入 SillyTavern 测试
`;

  return todo;
}

function createBackgroundMd(projectName) {
  return `# ${projectName} — 背景设定

## 世界观

[在此描述世界观、时代背景]

## 核心设定

- [在此描述核心设定]

## 主要势力/阵营

- [在此描述主要势力]

## 特殊规则

- [在此描述特殊规则]
`;
}

function createCharacterXyaml(charName) {
  return `name: "${charName}"
description: ""
# 外貌
appearance:
  age: ""
  height: ""
  hair: ""
  eyes: ""
  outfit: ""
  features: ""

# 性格
personality:
  traits: ""
  strengths: ""
  weaknesses: ""
  likes: [""]
  dislikes: [""]

# 背景
background: |
  [在此填写角色背景故事]

# 说话风格
speaking_style: |
  [在此描述说话风格、常用语气词等]

# 例子对话
example_dialogs:
  - user: ""
    char: ""

  - user: ""
    char: ""
`;
}

function createFirstMes() {
  return `<StatusPlaceHolderImpl/>

[在此填写开场白内容]`;
}

function createDialogueExample(charName) {
  return `# 对话示例 — ${charName}

> 用于帮助 AI 理解对话风格。

## 示例 1

**{{user}}**：...
**${charName}**：...

## 示例 2

**{{user}}**：...
**${charName}**：...
`;
}

function createVariableStructureJs(mvuVars) {
  let schema = `// 变量结构设计 — Zod Schema
// 使用 Zod 4.x 语法定义变量类型、默认值和描述

import { z } from 'zod';

export const VariableSchema = z.object({
`;

  if (mvuVars.length > 0) {
    mvuVars.forEach((v, i) => {
      const comma = i < mvuVars.length - 1 ? ',' : '';
      schema += `  ${v}: z.coerce.number().prefault(0).describe("${v}的初始值")${comma}\n`;
    });
  } else {
    schema += `  好感度: z.coerce.number().prefault(0).describe("角色对玩家的好感度"),
  欲望值: z.coerce.number().prefault(0).describe("角色的欲望值"),
  剧情阶段: z.coerce.number().prefault(0).describe("当前剧情阶段"),\n`;
  }

  schema += `});

export type VariableType = z.infer<typeof VariableSchema>;
`;
  return schema;
}

function createVariableInitYaml(mvuVars) {
  let yaml = `# 变量初始化条目（InitVar）
# enabled: false — 仅在对话开始时初始化 stat_data，不在 AI 上下文中显示

stat_data:`;

  if (mvuVars.length > 0) {
    mvuVars.forEach(v => {
      yaml += `
  ${v}: 0`;
    });
  } else {
    yaml += `
  好感度: 0
  欲望值: 0
  剧情阶段: 0`;
  }

  yaml += `
`;
  return yaml;
}

function createVariableUpdateRuleYaml() {
  return `# 变量更新规则
# 告诉 AI 在什么情况下增加或减少变量值
#
# 输出格式:
# <UpdateVariable>
# <Analysis>
# [简要分析当前对话，判断变量增减]
# </Analysis>
# <JSONPatch>
# [
#   { "op": "inc", "path": "/stat_data/好感度", "value": 5 }
# ]
# </JSONPatch>
# </UpdateVariable>

## 规则说明

1. **触发时机**：当对话内容涉及变量相关情境时
2. **输出方式**：AI 应在回复中包含 <UpdateVariable> 标签
3. **增减原则**：根据对话内容合理调整变量值
4. **边界控制**：Zod Schema 自动处理最小/最大值

## 变量规则

- **好感度**：
  - 增加：玩家体贴、关心、帮助角色时
  - 减少：玩家冷漠、伤害、背叛角色时
  - 范围：0-100

- **欲望值**：
  - 增加：暧昧、亲密场景时
  - 减少：冷静、理性对话时
  - 范围：0-100

- **剧情阶段**：
  - 增加：完成关键剧情节点时
  - 减少：通常不减少
  - 范围：0-10
`;
}

function createVariableOutputFormatYaml(mvuVars) {
  let yaml = `# 变量输出格式
# 注入当前变量状态，告诉 AI 当前的变量值
# 重要：这个条目必须 constant: true，确保始终在上下文内

当前变量状态：
`;

  if (mvuVars.length > 0) {
    mvuVars.forEach(v => {
      yaml += `- {{变量: stat_data.${v}}}: ${v}\n`;
    });
  } else {
    yaml += `- {{变量: stat_data.好感度}}: 好感度
- {{变量: stat_data.欲望值}}: 欲望值
- {{变量: stat_data.剧情阶段}}: 剧情阶段\n`;
  }

  yaml += `
更新指令格式：
<UpdateVariable>
<Analysis>
[分析当前对话，判断变量增减的合理性]
</Analysis>
<JSONPatch>
[
  { "op": "inc", "path": "/stat_data/好感度", "value": 5 }
]
</JSONPatch>
</UpdateVariable>

注意：
- inc 操作会自动增加/减少数值
- 所有数值由 Zod Schema 自动验证边界
- Analysis 标签内的分析不会显示在用户视角
`;
  return yaml;
}

function createStatusBarHtml(projectName, mvuVars) {
  let varItems = '';
  let populateCode = '';

  if (mvuVars.length > 0) {
    mvuVars.forEach(v => {
      const id = v.replace(/[^a-zA-Z0-9\u4e00-\u9fff]/g, '');
      varItems += `            <div class="stat-item">
                <span>${v}：</span>
                <span id="${id}-value">--</span>
            </div>
`;
      populateCode += `        const ${id} = _.get(characterData, '${v}', 0);
        $('#${id}-value').text(${id});
`;
    });
  } else {
    varItems = `            <div class="stat-item">
                <span>好感度：</span>
                <span id="affection-value">--</span>
            </div>
            <div class="stat-item">
                <span>欲望值：</span>
                <span id="desire-value">--</span>
            </div>
            <div class="stat-item">
                <span>剧情阶段：</span>
                <span id="stage-value">--</span>
            </div>
`;
    populateCode = `        const affection = _.get(characterData, '好感度', 0);
        $('#affection-value').text(affection);

        const desire = _.get(characterData, '欲望值', 0);
        $('#desire-value').text(desire);

        const stage = _.get(characterData, '剧情阶段', 0);
        $('#stage-value').text(stage);
`;
  }

  return `<head>
    <style>
    /* ${projectName} — 状态栏样式 */
    .status-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 8px;
        padding: 15px;
        margin: 10px 0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .stat-item {
        margin: 8px 0;
        display: flex;
        justify-content: space-between;
        font-size: 14px;
    }
    .stat-item span:first-child {
        color: #666;
    }
    .stat-item span:last-child {
        font-weight: bold;
        color: #333;
    }
    .card-body h3 {
        margin: 0 0 12px 0;
        font-size: 16px;
        color: #444;
        border-bottom: 1px solid #eee;
        padding-bottom: 8px;
    }
    </style>
    <script type="module">
    /* 填充角色数据 */
    function populateCharacterData() {
        const all_variables = getAllVariables();
        const characterData = all_variables.stat_data;

        if (!characterData) return;

${populateCode.replace(/^/gm, '        ')}
    }

    /* 初始化函数 */
    async function init() {
        /* 等待 MVU 系统初始化完成 */
        await waitGlobalInitialized('Mvu');

        /* 填充数据 */
        populateCharacterData();

        /* 绑定变量更新事件，自动刷新状态栏 */
        eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, populateCharacterData);

        /* 轮询保底：1500ms 轮询，确保任何情况下都能更新 */
        if (window._statusBarInterval) clearInterval(window._statusBarInterval);
        window._statusBarInterval = setInterval(populateCharacterData, 1500);
    }

    /* 使用 errorCatched 包装并在 jQuery ready 时执行 */
    $(errorCatched(init));
    </script>
</head>
<body>
    <div class="status-card">
        <div class="card-body">
            <h3>${projectName}</h3>
${varItems}
        </div>
    </div>
</body>
`;
}

function createDepthPromptTxt() {
  return `[系统指令：在回复中嵌入 <UpdateVariable> 标签以更新状态变量]

当对话涉及变量变化时，请在回复末尾添加：
<UpdateVariable>
<Analysis>
[简要分析当前对话]
</Analysis>
<JSONPatch>
[
  { "op": "inc", "path": "/stat_data/好感度", "value": 5 }
]
</JSONPatch>
</UpdateVariable>
`;
}

function createWorldBookEntryYaml(entryName, keys, content) {
  return `# ${entryName}
keys: [${keys.map(k => `"${k}"`).join(', ')}]
content: |
  ${content.replace(/\n/g, '\n  ')}
`;
}

function createBackgroundEntryYaml(projectName) {
  return createWorldBookEntryYaml(
    '背景设定',
    ['世界观', '背景', '设定'],
    `[在此填写背景设定内容]

## 世界概况

[描述世界的基本概况]

## 重要设定

- [设定1]
- [设定2]
`
  );
}

function createCharEntryYaml(charName) {
  return createWorldBookEntryYaml(
    `${charName}角色设定`,
    [charName],
    `${charName}是[描述角色基本信息]。

## 外貌
[描述外貌]

## 性格
[描述性格]

## 设定补充
- [补充设定1]
- [补充设定2]
`
  );
}

// ── 主函数 ────────────────────────────────────────────────────────

function main() {
  const { projectName, options } = parseArgs();
  const { type, characters, mvu } = options;
  const isMvu = type === 'mvu' || type === 'full';

  const projectDir = path.resolve(PROJECTS_DIR, projectName);
  const entriesDir = path.join(projectDir, 'entries');

  if (fs.existsSync(projectDir)) {
    console.error(`❌ 项目目录已存在: projects/${projectName}`);
    console.error(`   如需重新初始化，请先删除该目录。`);
    process.exit(1);
  }

  console.log(`\n🚀 初始化项目: ${projectName}`);
  console.log(`   类型: ${type}`);
  console.log(`   角色: ${characters.join(', ')}`);
  if (isMvu) console.log(`   MVU 变量: ${mvu.length > 0 ? mvu.join(', ') : '(使用默认变量)'}`);
  console.log('');

  // ── 创建项目目录 ──
  fs.mkdirSync(projectDir, { recursive: true });

  // ── 必须文件 ──
  writeFile(path.join(projectDir, 'config.yaml'), createConfigYaml(projectName, options));
  writeFile(path.join(projectDir, '背景设定.md'), createBackgroundMd(projectName));
  characters.forEach(char => {
    writeFile(path.join(projectDir, `角色设定_${char}.xyaml`), createCharacterXyaml(char));
  });
  writeFile(path.join(projectDir, '开场白.md'), createFirstMes());
  writeFile(path.join(projectDir, 'to-do.md'), createTodoMd(projectName, options));

  // ── MVU 文件 ──
  if (isMvu) {
    writeFile(path.join(projectDir, '变量结构.js'), createVariableStructureJs(mvu));
    writeFile(path.join(projectDir, '变量初始化条目.yaml'), createVariableInitYaml(mvu));
    writeFile(path.join(projectDir, '状态栏.html'), createStatusBarHtml(projectName, mvu));

    fs.mkdirSync(entriesDir, { recursive: true });
    writeFile(path.join(entriesDir, '变量更新规则.yaml'), createVariableUpdateRuleYaml());
    writeFile(path.join(entriesDir, '变量输出格式.yaml'), createVariableOutputFormatYaml(mvu));
  }

  // ── Full 类型额外文件 ──
  if (type === 'full') {
    writeFile(path.join(projectDir, '深度提示.txt'), createDepthPromptTxt());
    characters.forEach(char => {
      writeFile(path.join(projectDir, `对话示例_${char}.md`), createDialogueExample(char));
    });

    // World book entry templates
    fs.mkdirSync(entriesDir, { recursive: true });
    writeFile(path.join(entriesDir, '背景设定.yaml'), createBackgroundEntryYaml(projectName));
    characters.forEach(char => {
      writeFile(path.join(entriesDir, `角色设定_${char}.yaml`), createCharEntryYaml(char));
    });
  }

  // ── 完成 ──
  console.log(`\n✅ 项目创建完成: projects/${projectName}/`);
  console.log(`\n下一步：`);
  console.log(`  1. cd projects/${projectName}`);
  console.log(`  2. 编辑各源文件填充内容`);
  if (isMvu) {
    console.log(`  3. 编辑 变量结构.js 定义 Zod Schema`);
    console.log(`  4. 编辑 entries/变量更新规则.yaml 和 entries/变量输出格式.yaml`);
    console.log(`  5. 编辑 状态栏.html 自定义样式`);
  }
  console.log(`  6. 运行编译: node ../skills/nova-write-card/scripts/build-card.js config.yaml`);
  console.log('');
}

main();
