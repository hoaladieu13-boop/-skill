#!/usr/bin/env node
'use strict';
/**
 * score-card.js — 角色卡质量自动评分
 *
 * 读取一张 chara_card_v3 JSON，按 score-card-guide.md 的 9 维度加权模型输出 S–D 等级。
 * 自动计算：D1 结构 / D3 配置 / D4 禁词 / D6 MVU / D7 ESJ / D8 状态栏 / D9 脚本集成
 * 半自动：  D2 人设厚度 / D5 开场白（给信息完整度分，标 ⚠需人工复核人味/钩子）
 *
 * 兼容两种结构：
 *   A. 顶层即卡体（description/personality 在顶层）
 *   B. 「冗余副本 + data 满内容」型：顶层 name 等可能为占位，真实内容在 data / character_book
 * 兼容「世界书承载型卡」：顶层 description/personality 为空，人设完全由 character_book 条目承载。
 *
 * 用法：
 *   node score-card.js 作品.json
 *   node score-card.js 作品.json --json
 */

import fs from 'fs';
import path from 'path';

function fail(msg) {
  console.error('✗ ' + msg);
  process.exit(1);
}

// ---------- 参数 ----------
const args = process.argv.slice(2);
const jsonFlag = args.includes('--json');
const file = args.find(a => !a.startsWith('--'));
if (!file) fail('用法: node score-card.js 作品.json [--json]');

if (!fs.existsSync(file)) fail('文件不存在: ' + file);
let raw;
try { raw = fs.readFileSync(file, 'utf-8'); } catch (e) { fail('读取失败: ' + e.message); }
let json;
try { json = JSON.parse(raw); } catch (e) { fail('JSON 解析失败: ' + e.message); }

// ---------- 提取卡体（兼容 data 嵌套 / 世界书承载型）----------
const top = json || {};
const card = (top.data && typeof top.data === 'object') ? top.data : top;
const ext = card.extensions || top.extensions || {};
const book = card.character_book || {};
const entries = Array.isArray(book.entries) ? book.entries : [];
const regexScripts = Array.isArray(ext.regex_scripts) ? ext.regex_scripts : [];
const th = ext.tavern_helper || ext.TavernHelper_scripts || {};
const thScripts = Array.isArray(th.scripts) ? th.scripts : [];

// 字段取值：data 优先，回退顶层（兼容冗余副本）
const F = (k) => {
  const v = (card[k] != null && String(card[k]).trim() !== '') ? card[k] : (top[k] != null ? top[k] : '');
  return String(v || '');
};
const desc = F('description');
const pers = F('personality');
const fm = F('first_mes');

const bookText = entries.map(e => e.content || '').join('\n');
const bookChars = bookText.length;

// ---------- 禁词清单（核心，来源 forbidden-words.md）----------
const FORBIDDEN = [
  '一丝', '一缕', '一抹', '不易察觉', '不易觉察', '难以察觉', '鲜明对比', '形成对比',
  '弧度', '弯起嘴角', '翘起嘴角', '喉结', '纽扣', '指节发白',
  '石子', '湖面', '拉满的弓', '琴弦', '闪电', '晨光', '星辰', '像一道闪电', '如同天堑',
];
function scanForbidden(text) {
  if (!text || typeof text !== 'string') return [];
  const hits = [];
  for (const w of FORBIDDEN) if (text.includes(w)) hits.push(w);
  return hits;
}

// ---------- 维度检测 ----------
const dims = {};
function setDim(id, name, weight, type, score, note, manual) {
  dims[id] = { name, weight, type, score: Math.max(0, Math.min(5, score)), note, manual: !!manual };
}

// D1 结构合规 (15%)
(function () {
  let s = 5; const notes = [];
  const sv = (card.spec_version != null ? card.spec_version : top.spec_version);
  if (!(sv != null && String(sv).startsWith('3'))) { s -= 2; notes.push('spec_version 非 v3'); }
  // 必填字段：兼容「世界书承载型」——若 description 空但世界书充实，不致命
  if (desc.trim() === '' && bookChars < 3000) { s -= 1; notes.push('description 空且世界书单薄'); }
  else if (desc.trim() === '') { notes.push('description 空(世界书承载)'); }
  if (pers.trim() === '') { s -= 0.5; notes.push('personality 空'); }
  if (fm.trim() === '') { s -= 0.5; notes.push('first_mes 空'); }
  if (entries.length < 1) { s -= 1; notes.push('世界书条目<1'); }
  const patternEmpty = /^\s*[{[}\]]\s*$/.test(pers);
  if (pers.trim() !== '' && patternEmpty) { s -= 0.5; notes.push('personality 疑似空壳'); }
  setDim('D1', '结构合规与完整性', 15, 'req', s, notes.join('；') || '字段齐全合法');
})();

// D3 世界书工程 (15%)
(function () {
  let s = 5; const notes = [];
  if (entries.length < 10) { s -= 1; notes.push('条目数=' + entries.length + ' (建议≥10)'); }
  const avg = entries.reduce((a, e) => a + (e.content ? String(e.content).length : 0), 0) / Math.max(1, entries.length);
  if (avg < 500) { s -= 1; notes.push('条目平均' + Math.round(avg) + '字 (建议≥500)'); }
  const recOf = e => e.prevent_recursion ?? (e.extensions && e.extensions.prevent_recursion);
  const excOf = e => e.exclude_recursion ?? (e.extensions && e.extensions.exclude_recursion);
  const noRec = entries.filter(e => !recOf(e) || !excOf(e)).length;
  if (noRec > 0) { s -= 2; notes.push(noRec + ' 条缺防递归'); }
  const greenNoKey = entries.filter(e => e.constant === false && e.enabled !== false && (!e.keys || e.keys.length === 0)).length;
  if (greenNoKey > 0) { s -= 1; notes.push(greenNoKey + ' 条绿灯 keys 空'); }
  const sdOf = e => e.scan_depth ?? (e.extensions && e.extensions.scan_depth);
  const scanBad = entries.filter(e => e.constant === false && e.enabled !== false && sdOf(e) !== 2 && sdOf(e) !== '2').length;
  if (scanBad > 0) { s -= 0.5; notes.push(scanBad + ' 条绿灯 scanDepth≠2'); }
  const constCount = entries.filter(e => e.constant === true).length;
  if (entries.length > 5 && constCount === entries.length) { s -= 1; notes.push('疑似全常驻(未分层)'); }
  setDim('D3', '世界书工程质量', 15, 'req', s, notes.join('；') || '配置规范、Token 精算');
})();

// D4 叙事/禁词 (15%)
(function () {
  let s = 5; const notes = [];
  const texts = [desc, fm, ...entries.map(e => e.content)];
  const allHits = [];
  for (const t of texts) allHits.push(...scanForbidden(t));
  const uniq = [...new Set(allHits)];
  if (uniq.length > 0) {
    s -= Math.min(4, 1 + uniq.length * 0.5);
    notes.push('禁词命中: ' + uniq.slice(0, 8).join('/'));
  }
  setDim('D4', '叙事质量与禁词合规', 15, 'req', s, notes.join('；') || '零禁词');
})();

// D6 MVU (10%, 条件)
let hasMvu = thScripts.some(s => /MagVarUpdate|registerMvuSchema|MVU/.test(JSON.stringify(s)));
(function () {
  if (!hasMvu) { setDim('D6', '变量系统 MVU', 10, 'cond', null, '未启用（跳过）', false); return; }
  let s = 5; const notes = [];
  const hasInit = entries.some(e => /initvar/i.test(e.comment || '') || /\[InitVar\]/i.test(e.content || ''));
  if (!hasInit) { s -= 1; notes.push('未见 InitVar 初始化'); }
  const hasPatch = entries.some(e => /<JSONPatch>|<Analysis>/.test(e.content || ''));
  if (!hasPatch) { s -= 1.5; notes.push('未见 JSONPatch 更新格式'); }
  setDim('D6', '变量系统 MVU', 10, 'cond', s, notes.join('；') || '变量闭环');
})();

// D7 ESJ (5%, 条件)
let hasEsj = entries.some(e => /<%_|<%-/.test(e.content || ''));
(function () {
  if (!hasEsj) { setDim('D7', '动态世界书 ESJ', 5, 'cond', null, '未启用（跳过）', false); return; }
  let s = 5; const notes = [];
  const names = new Set(entries.map(e => (e.comment || e.name || '').trim()).filter(Boolean));
  const allContent = entries.map(e => e.content || '').join('\n');
  const getwiRe = /getwi\(\s*null\s*,\s*['"]([^'"]+)['"]\s*\)/g;
  let m, broken = [];
  while ((m = getwiRe.exec(allContent))) { if (!names.has(m[1].trim())) broken.push(m[1]); }
  if (broken.length > 0) { s -= 2; notes.push('getwi 断链: ' + [...new Set(broken)].slice(0, 5).join('/')); }
  const ctrlConst = entries.filter(e => /<%_|<%-/.test(e.content || '') && e.constant !== true).length;
  if (ctrlConst > 0) { s -= 1; notes.push(ctrlConst + ' 条控制器非常驻'); }
  setDim('D7', '动态世界书 ESJ', 5, 'cond', s, notes.join('；') || '切换无缝、零断链');
})();

// D8 状态栏 (5%, 条件)
let hasStatus = regexScripts.some(s => /状态栏|statusbar|StatusPlaceHolder/i.test(JSON.stringify(s)));
(function () {
  if (!hasStatus) { setDim('D8', '状态栏/前端 HTML', 5, 'cond', null, '未启用（跳过）', false); return; }
  let s = 5; const notes = [];
  const rsText = regexScripts.map(x => (x.findRegex || '') + (x.replaceString || '')).join('\n');
  if (!/getMvuData/.test(rsText)) { s -= 1.5; notes.push('未见 getMvuData 三级降级'); }
  if (!/type\s*=\s*["']module["']/.test(rsText)) { s -= 1; notes.push('未见 type=module'); }
  if (!/setInterval/.test(rsText)) { s -= 1; notes.push('缺轮询保底 setInterval'); }
  setDim('D8', '状态栏/前端 HTML', 5, 'cond', s, notes.join('；') || '刷新稳');
})();

// D9 脚本集成 (5%)
(function () {
  let s = 5; const notes = [];
  const joined = JSON.stringify(regexScripts);
  if (!/StatusPlaceHolder|隐藏状态栏/.test(joined) && !regexScripts.some(s => s.promptOnly)) { s -= 1; notes.push('缺隐藏状态栏脚本'); }
  if (!/状态栏|statusbar/i.test(joined) && !regexScripts.some(s => s.markdownOnly)) { s -= 1; notes.push('缺状态栏注入脚本'); }
  if (!/JSONPatch|去除更新变量|UpdateVariable/.test(joined)) { s -= 1; notes.push('缺去除更新变量脚本'); }
  if (thScripts.length === 0) { s -= 1.5; notes.push('缺 tavern_helper 脚本'); }
  setDim('D9', '脚本集成与健壮性', 5, 'req', s, notes.join('；') || '三件套齐全');
})();

// D2 人设厚度 (20%, 半自动) — 兼容世界书承载型
(function () {
  let s = 2; const notes = [];
  const narrativeChars = desc.length + pers.length;
  if (narrativeChars >= 1500) s += 2;
  else if (narrativeChars >= 800) s += 1;
  else if (bookChars >= 5000) s += 2;        // 世界书承载型
  else if (bookChars >= 2000) s += 1;
  else s -= 0.5;
  if (narrativeChars > 0 && /温柔|善良|坚强|傲娇|美丽/.test(desc) && !/[\u4e00-\u9fa5]{40,}/.test(desc.replace(/温柔|善良|坚强|傲娇|美丽/g, ''))) {
    notes.push('疑似标签堆砌');
  }
  notes.push('⚠需人工复核人味(内核/矛盾/锚点)');
  setDim('D2', '人设厚度与一致性', 20, 'req', s, notes.join('；'), true);
})();

// D5 开场白 (10%, 半自动)
(function () {
  let s = 3; const notes = [];
  if (fm.length >= 1000) s += 1; else if (fm.length < 300) s -= 1;
  if (fm.length > 0 && /背景|设定|世界观/.test(fm.slice(0, 80))) { s -= 1; notes.push('开场即解释背景'); }
  notes.push('⚠需人工复核钩子/情境');
  setDim('D5', '开场白与对话示例', 10, 'req', s, notes.join('；'), true);
})();

// ---------- 计算总分 ----------
let totalW = 0, earned = 0;
for (const id of Object.keys(dims)) {
  const d = dims[id];
  if (d.type === 'cond' && d.score === null) continue;
  totalW += d.weight;
  earned += (d.score / 5) * d.weight;
}
const total = totalW > 0 ? (earned / totalW) * 100 : 0;
const grade = total >= 90 ? 'S' : total >= 80 ? 'A' : total >= 70 ? 'B' : total >= 60 ? 'C' : 'D';

const ranked = Object.values(dims)
  .filter(d => d.score !== null)
  .map(d => ({ id: d.name, loss: (5 - d.score) * d.weight }))
  .sort((a, b) => b.loss - a.loss)
  .slice(0, 3);

// ---------- 输出 ----------
if (jsonFlag) {
  console.log(JSON.stringify({ file: path.basename(file), total: Math.round(total), grade, dimensions: dims, topDefects: ranked }, null, 2));
} else {
  console.log('\n══════════════════════════════════════════════');
  console.log('  角色卡质量评分：' + path.basename(file));
  console.log('══════════════════════════════════════════════');
  console.log('  ' + '维度'.padEnd(20) + '权重   分    说明');
  console.log('  ' + '─'.repeat(46));
  for (const id of ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9']) {
    const d = dims[id]; if (!d) continue;
    const sc = d.score === null ? '跳过' : d.score.toFixed(1);
    console.log('  ' + d.name.slice(0, 16).padEnd(16) + ' ' + String(d.weight + '%').padEnd(5) + ' ' + String(sc).padEnd(5) + ' ' + (d.note || ''));
  }
  console.log('  ' + '─'.repeat(46));
  console.log('  总分：' + total.toFixed(1) + ' / 100   等级：' + grade + (grade === 'S' ? ' (神卡)' : grade === 'A' ? ' (优质)' : grade === 'B' ? ' (合格)' : grade === 'C' ? ' (勉强能玩)' : ' (需大改)'));
  console.log('');
  console.log('  Top3 扣分项：');
  ranked.forEach((r, i) => console.log('   ' + (i + 1) + '. ' + r.id + ' (损失 ' + r.loss.toFixed(1) + ' 分)'));
  console.log('══════════════════════════════════════════════\n');
}
