# 世界书配置规则

内容写得好没用，配置错 = AI 读不到。本章是必读。

---

## 一、触发策略：蓝灯 vs 绿灯

### 蓝灯（constant）——始终激活

只要世界书开着，该条目每轮都发给AI。**必须始终存在的信息才蓝灯。**

应该蓝灯的内容：世界观总纲、背景设定、角色速览

### 绿灯（关键词触发）——按需激活

只在最近消息中出现关键词时才发给AI。**扫描深度建议设为2。**

应该绿灯的内容：NPC详情、具体场景、事件、多角色卡的各个角色详细信息

### 单角色卡铁律

**单角色卡的所有条目全部蓝灯。** 无论拆成多少个条目。

条目拆开≠不同角色。同一个角色的基础信息、外貌、性格、背景拆成5个条目，描述的都是同一个人。AI必须同时知道全部信息才能正确扮演。不要把其中一些改成绿灯省token——缺了任何一条，角色就不完整。

### 多角色卡配置

- 角色速览：蓝灯。所有角色的一句话简介放一起
- 各角色详细信息：绿灯。关键词=角色名、昵称、外号

---

## 二、位置（position）

| 内容类型 | 位置 | position 值 |
|----------|------|-------------|
| 世界观总纲/背景/规则/地理 | ↑Char | `before_char` (0) |
| 角色详细信息/NPC/场景/物品 | ↓Char | `after_char` (1) |
| 文风规则/格式指令 | ↑AT | `at_depth` (2) |
| 行为纠正/二次解释 | @D, depth=0 | `at_depth` (4) |
| D1+ (@D depth≥1) | **永不使用** | 破坏聊天记录完整性 |

详细位置参考见 `references/position-guide.md`。

---

## 三、顺序（order）

数值越大越靠后。同一位置内的推荐分配：

| 内容 | order |
|------|-------|
| 世界观总纲 | 1 |
| 区域速览/背景设定 | 2-3 |
| 角色速览 | 4 |
| 场景/事件详情 | 50-98 |
| 核心角色详细信息 | 99 |
| NPC | 100 |

单角色卡拆分条目的内部顺序：基础信息10 → 外貌20 → 性格30 → 背景40

---

## 四、递归设置（双字段，必须同时勾选）

**所有条目必须同时勾选两个递归选项。** 无一例外。

| 字段 | SillyTavern 术语 | 含义 |
|------|-----------------|------|
| `preventRecursion: true` | 不可进一步递归 | 本条目**不会触发**其他条目 |
| `excludeRecursion: true` | 无法被其他条目激活 | 本条目**不被**其他条目触发 |

**`build-card.js` 默认两个字段均为 `false`。创建配置时必须显式设为 `true`。**

不勾 `preventRecursion` 的后果：条目A内容出现条目B的关键词→B被触发→B的内容触发C→连锁反应→token爆炸。

不勾 `excludeRecursion` 的后果：条目B的关键词出现在条目C的内容中→双向递归。

在 `config.yaml` 中的配置：

```yaml
entries:
  - comment: "世界观总纲"
    content: "..."
    constant: true
    position: "before_char"
    order: 1
    prevent_recursion: true
    exclude_recursion: true
```

---

## 五、关键词（keys）格式

- **英文逗号** `,` 分隔——中文逗号 `，` 和空格直接失效
- 覆盖所有称呼：全名、昵称、外号、职务

```yaml
keys: ["林小雨,小雨,班长"]    # ✅ 正确
keys: ["林小雨，小雨，班长"]  # ❌ 错误——中文逗号无效
```

| 条目类型 | 关键词建议 |
|----------|-----------|
| 角色条目 | 全名 + 昵称 + 外号 |
| NPC条目 | 全名 + 昵称 + 外号 + 职务 |
| 场景条目 | 场景名 + 所在区域 + 别称 + 相关动作 |
| 势力条目 | 全名 + 简称 + 所在地名 |

---

## 六、扫描深度

绿灯条目推荐 `scanDepth: 2`（只看最后一条用户消息和最后一条AI消息）。

```yaml
entries:
  - comment: "NPC详情"
    content: "..."
    constant: false
    keys: ["NPC名,昵称"]
    scan_depth: 2
```

---

## 七、常用配置组合

### 世界观总纲（蓝灯，角色定义前）

```yaml
- comment: "世界观总纲"
  content: "..."
  constant: true
  position: "before_char"
  order: 1
  prevent_recursion: true
  exclude_recursion: true
```

### 角色详细信息（蓝灯，角色定义后，单角色卡）

```yaml
- comment: "角色性格设定"
  content: "..."
  constant: true
  position: "after_char"
  order: 30
  prevent_recursion: true
  exclude_recursion: true
```

### NPC条目（绿灯，关键词触发）

```yaml
- comment: "NPC详情"
  content: "..."
  constant: false
  position: "after_char"
  order: 100
  keys: ["角色名,昵称,外号"]
  scan_depth: 2
  prevent_recursion: true
  exclude_recursion: true
```

### 行为纠正（绿灯，D0）

```yaml
- comment: "行为纠正"
  content: "..."
  constant: true
  position: "at_depth"
  depth: 0
  role: 0
  scan_depth: 2
  prevent_recursion: true
  exclude_recursion: true
```

---

## 八、创建后必须自查

### 单角色卡（1个核心角色）

| 条目类型 | 蓝灯/绿灯 | 如果写错了 |
|---------|----------|-----------|
| 该角色的所有拆分条目 | **全部蓝灯** | 绿灯→角色不完整，AI猜着演→八股 |
| 世界观/背景 | 蓝灯 | — |
| NPC | 绿灯 | 蓝灯→无关NPC常驻吃token |

**铁律：单角色卡没有例外。** 拆成5个条目=5个蓝灯。拆成10个=10个蓝灯。

### 多角色卡（2+个核心角色）

| 条目类型 | 蓝灯/绿灯 | 如果写错了 |
|---------|----------|-----------|
| 角色速览 | **蓝灯** | 绿灯→AI不知道世界里有谁 |
| 各角色详细信息 | **绿灯** | 蓝灯→所有角色常驻，token爆炸 |
| 世界观/背景 | 蓝灯 | — |
| NPC/场景 | 绿灯 | 蓝灯→常驻吃token |

### 配置检查清单

- [ ] 先数清楚几个核心角色（1个=单角色卡，2+个=多角色卡）
- [ ] 单角色卡？→ 所有该角色的条目 `constant=true`
- [ ] 多角色卡？→ 速览 `constant=true`，角色详情 `constant=false` + `keys`
- [ ] 世界观条目全部 `constant=true`
- [ ] NPC/场景条目全部 `constant=false` + `keys`
- [ ] **⚠️ 所有条目 `preventRecursion=true` 且 `excludeRecursion=true`**（脚本默认false，不加就不会设！）
- [ ] 关键词用英文逗号分隔，无空格
- [ ] 绿灯条目 `scanDepth=2`

---

## 九、世界书分层模式（庞大世界观）

当世界观涉及**大量地点/人物/事件（条目数 ≥ 约 20）**时，上述三种模式不够——把所有详情常驻会爆上下文。此时走**分层省 Token** 方案：

- **L0 规则层（蓝灯常驻）**：格式指导、世界观概览、叙事铁律（规则非 Lore，便宜）
- **L1 区域骨架层（蓝灯常驻）**：正则区域标记 `</上城>` + **可选名字清单**（中等规模列名字、庞大世界观只留正则标记）
- **L2 详情层（绿灯触发）**：地点/人物/怪物/事件完整条目，名字命中才注入

完整字段速查、Token 账与实卡范本见 [`references/world-book-layering.md`](references/world-book-layering.md)。

> 单角色卡 / 中小世界观**不要**分层——直接按本节一~八的三种模式走即可。
