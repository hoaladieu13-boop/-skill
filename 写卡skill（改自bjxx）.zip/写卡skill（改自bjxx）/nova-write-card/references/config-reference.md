# YAML 配置文件完整参考

## 文件结构

`config.yaml` 是编译脚本的核心配置文件，定义角色卡的所有字段。

## 顶级字段

```yaml
# 基本信息（必需）
spec:
  name: "角色卡名称"          # 输出 JSON 文件名
  description: "简短描述"      # 角色卡描述
  version: "1.0.0"           # 版本号

# SillyTavern 核心字段
data:
  name: "角色名"              # 角色显示名称
  description: ""             # 留空（角色设定由 world book 承载）
  personality: ""             # 留空
  scenario: ""                # 留空
  first_mes: "${file:开场白.md}"  # 开场白（从文件读取）
  mes_example: "${file:对话示例.md}"  # 对话示例（从文件读取）
  avatar: "角色头像昵称"        # 角色头像表情/昵称
  system_prompt: ""           # 自定义系统提示（可选）
  post_history_instructions: ""  # 历史后指令（可选）
  tags:                      # 标签列表
    - "角色扮演"
    - "现代"
  creator: ""                # 作者
  character_version: ""      # 角色版本

  # 扩展字段（用于 SillyTavern 扩展功能）
  extensions:
    depth_prompt:
      depth: 4               # 深度提示深度值
      prompt: "${file:深度提示.md}"  # 深度提示内容（从文件读取）
      role: "system"         # 深度提示角色

  # 世界书（可选）
  character_book:
    entries: []              # 世界书条目列表
```

## 世界书条目配置

```yaml
character_book:
  entries:
    - keys: ["触发词1", "触发词2"]
      content: "${file:entries/条目内容.md}"  # 从文件读取内容
      # 或直接写内容：
      # content: |
      #   条目内容文字
      position: before_char    # before_char / after_char / at_depth
      depth: 10               # 位置相关深度值
      order: 1                # 排序权重
      role: 0                 # 0=系统 1=用户 2=助手 4=角色
      enabled: true           # 是否默认启用
      selective: false        # 是否选择性触发
      secondary_keys: []      # 次要关键词
      constant: false         # 是否始终触发
      probability: 100        # 触发概率（0-100）
```

## 脚本配置

### 正则脚本（regex_scripts）

编译时自动生成，通常无需手动配置：

```yaml
scripts:
  regex_scripts:
    remove_update_tags: true     # 移除 <UpdateVariable> 标签
    inject_status_bar: true      # 注入状态栏
    hide_update_from_ai: true    # 从 AI 视角隐藏更新标签
```

### 用户脚本（user_scripts）

在 SillyTavern 中通过 TavernScripts 或 TavernHelper 执行的脚本：

```yaml
scripts:
  user_scripts:
    - name: "变量管理"
      script_type: "tavern_helper_beta"  # 脚本类型
      entry_point: "变量结构.js"           # 入口文件
      variables:                          # 变量定义
        好感度:
          type: "number"
          min: 0
          max: 100
          initial: 0
```

### 变量初始化脚本

```yaml
scripts:
  variable_init_script:
    path: "变量结构.js"      # 变量结构文件路径
```

## 完整配置示例

```yaml
spec:
  name: "my-character"
  description: "我的角色卡"
  version: "1.0.0"

data:
  name: "小雅"
  description: ""
  personality: ""
  scenario: ""
  first_mes: "${file:开场白.md}"
  mes_example: "${file:对话示例_小雅.md}"
  avatar: "小雅"
  tags:
    - "角色扮演"
    - "现代"
    - "恋爱"
  creator: "创作者"
  character_version: "1.0.0"

  extensions:
    depth_prompt:
      depth: 4
      prompt: "${file:深度提示.md}"
      role: "system"

  character_book:
    entries:
      - keys: ["小雅"]
        content: "${file:角色设定_小雅.xyaml}"
        position: before_char
        depth: 10
        order: 1
        role: 0
        enabled: true
        constant: true

scripts:
  regex_scripts:
    remove_update_tags: true
    inject_status_bar: true
    hide_update_from_ai: true
  user_scripts:
    - name: "变量管理"
      script_type: "tavern_helper_beta"
      entry_point: "变量结构.js"
      variables:
        好感度:
          type: "number"
          min: 0
          max: 100
          initial: 0
  variable_init_script:
    path: "变量结构.js"
```
