# 验证清单与常见问题排查

## 自动验证（推荐）

编译后可使用 [`validate-card.js`](../scripts/validate-card.js) 自动检查 JSON 完整性：

```bash
# 在项目目录下
node ../skills/nova-write-card/scripts/validate-card.js 作品名称.json

# 详细模式（查看更多细节）
node ../skills/nova-write-card/scripts/validate-card.js 作品名称.json -v
```

验证项包括：
1. JSON 语法合法性
2. chara_card_v3 标识
3. 必填字段完整性（name、first_mes、description 等）
4. regex_scripts 完整性（状态栏、隐藏状态栏、去除更新变量）
5. tavern_helper / TavernHelper_scripts 完整性
6. 状态栏 JS 中 eventOn 事件监听 + setInterval 轮询保底
7. 世界书条目配置正确性（position、depth、role）
8. 开场白中 `<StatusPlaceHolderImpl/>` 占位符
9. **preventRecursion 检查（所有世界书条目必须为 true）** ⬅️ 新增
10. **excludeRecursion 检查（所有世界书条目必须为 true）** ⬅️ 新增
11. **禁词扫描（description/first_mes/entries content）** ⬅️ 新增
12. **单角色卡铁律检查（所有条目 constant=true）** ⬅️ 新增

### 禁词扫描范围

扫描以下内容中的禁词（禁词清单详见 `references/forbidden-words.md`）：
- `data.description`
- `data.first_mes`
- `data.alternate_greetings[]`
- `character_book.entries[].content`

### 输出前 DoubleCheck

无论是否使用自动验证，输出前必须手动执行：

**禁词检查：**
- [ ] 全文无 `一丝` `一缕` `一抹`
- [ ] 全文无 `不易察觉` `不易觉察` `难以察觉`
- [ ] 全文无 `鲜明对比` `形成对比`
- [ ] 全文无 `弧度` `弯起嘴角` `翘起嘴角`
- [ ] 全文无 `不是...是...` `没有...而是...` 先否认再肯定句式
- [ ] 全文无石子/湖面/弓/琴弦/闪电/晨光/星辰类比喻
- [ ] 全文无作者视角的解释性修饰
- [ ] 全文无不存在之物的描写

**配置检查：**
- [ ] 单角色卡 → 所有世界书条目 `constant=true`
- [ ] 多角色卡 → 速览 `constant=true`，详情 `constant=false` + `keys`
- [ ] 所有条目 `preventRecursion=true` 且 `excludeRecursion=true`
- [ ] 关键词使用英文逗号，无空格
- [ ] 绿灯条目 `scanDepth=2`

> 以下为手动检查清单，供逐项排查时参考。

## 文件完整性检查

| 检查项 | 说明 |
|--------|------|
| `config.yaml` 存在且格式正确 | YAML 语法无误，无缩进错误 |
| 所有引用的 `${file:}` 文件存在 | 配置中引用的文件路径正确 |
| `package.json` 存在 | 已初始化 Node.js 项目 |
| `node_modules/js-yaml` 已安装 | 运行 `npm install` 确认 |
| 所有世界书条目文件存在 | `entries/` 目录下的文件正确 |

## 内容质量检查

| 检查项 | 说明 |
|--------|------|
| 开场白自然引入 | 不使用"我是 XXX"句式，通过场景自然展现角色 |
| 角色设定详细完整 | 包含外貌、性格、背景、关系等 |
| 对话示例风格一致 | 示例对话符合角色设定 |
| 背景设定与角色一致 | 世界观与角色设定无矛盾 |
| 变量名在全部文件中一致 | 变量结构、更新规则、状态栏、YAML 中统一 |

## 配置检查

| 检查项 | 说明 |
|--------|------|
| `spec.name` 不为空 | 决定输出文件名 |
| `data.name` 不为空 | 角色显示名称 |
| `data.first_mes` 有内容 | 通过 `${file:}` 引用或直接写入 |
| `position` 值正确 | `before_char`/`after_char`/`at_depth` 之一 |
| `depth` 和 `order` 设置合理 | 同一位置的条目排序正确 |
| `role` 值正确 | 0=系统 1=用户 2=助手 4=角色 |

## JSON 质量检查

```bash
# 验证 JSON 格式
cat my-character.json | python3 -m json.tool > /dev/null && echo "Valid JSON"

# 检查文件大小
ls -lh my-character.json

# 验证 chara_card_v3 标识
python3 -c "import json; c=json.load(open('my-character.json')); print(c.get('chara_card_v3','NOT FOUND'))"
```

## 常见问题排查

### 1. 编译脚本报错 "Cannot find module 'js-yaml'"

**原因**：未安装依赖
**解决**：`npm install js-yaml`

### 2. 编译脚本报错 "ENOENT: no such file or directory"

**原因**：配置文件中 `${file:路径}` 引用的文件不存在
**解决**：检查所有 `content: "${file:...}"` 的路径是否正确

### 3. 角色卡导入 SillyTavern 后设定为空

**原因**：世界书条目未正确生成
**解决**：
- 检查 `config.yaml` 中 `character_book.entries` 配置
- 确认条目的 `position`、`depth`、`order` 设置正确
- 确认条目 `enabled: true`

### 4. MVU 变量不更新 — 详细排查指南

**核心诊断方法**：

打开浏览器控制台（F12），发送一条消息后执行：
```javascript
getAllVariables().stat_data
```

如果值 **没有变化** → AI 输出的更新格式有问题（往下查 4a）
如果值 **已经变了** 但状态栏没更新 → 状态栏刷新机制有问题（往下查 4b）

---

#### 4a. AI 输出了更新但 MVU 引擎未解析（stat_data 没变）

按概率从高到低排查：

##### 🔴 最常见（占 90% 以上）：Entry ID 2「变量输出格式」内容错误

检查角色卡的世界书条目中 `[mvu_update]变量输出格式` 的内容。

**错误格式 1 — 纯 JSON 代替 JSON Patch：**
```yaml
format: |-
  <UpdateVariable>
  {
    "系统资金": ${system_fund},
    "已消费系统资金": ${consumed_fund}
  }
  </UpdateVariable>
```
❌ 缺少 `<Analysis>` 和 `<JSONPatch>` 子标签，MVU 引擎无法解析
❌ 使用 `${}` 占位符而非具体的值

**错误格式 2 — 旧版键值对（MVU Beta 兼容）：**
```yaml
format: |-
  <UpdateVariable>
  系统资金: "100"
  好感度: "75"
  </UpdateVariable>
```
❌ 仅 MVU Beta 支持，MVU Zod 不识别

**正确格式应为：**
```yaml
format: |-
  <UpdateVariable>
  <Analysis>...analysis...</Analysis>
  <JSONPatch>
  [
    { "op": "replace", "path": "/wealth_system/系统资金", "value": "${new_value}" },
    { "op": "replace", "path": "/wealth_system/好感度", "value": "${new_value}" }
  ]
  </JSONPatch>
  </UpdateVariable>
```

##### 🟡 次常见：JSON Pointer 路径缺少顶级 key

**错误：**
```json
{ "op": "replace", "path": "/系统资金", "value": 100 }
```

Schema 中定义的顶层结构是：
```javascript
z.object({ wealth_system: z.object({ 系统资金: ... }) })
//                ^^ 顶层 key
```

所以正确路径应为：
```json
{ "op": "replace", "path": "/wealth_system/系统资金", "value": 100 }
```

> 判断方法：在控制台执行 `getAllVariables().stat_data` 看顶层 key 是什么

##### 🟡 偶发：AI 没有按格式输出

检查 AI 实际回复中是否包含正确的 `<JSONPatch>` 块。如果 AI 不按要求输出，说明：
- `depth_prompt` 中的指令不够明确（需要明确提到 JSON Patch 和路径）
- `变量输出格式` 条目的 `depth` 设置太低，AI 在长对话中丢失了该指令

**修复**：
1. 在 `depth_prompt` 中明确写入格式要求
2. 将 `变量输出格式` 条目的 `depth` 设为 1（最优先）
3. 确保 `position` 为 `after_char`（系统位置）

---

#### 4b. stat_data 已更新但状态栏不刷新

##### 检查 1：事件绑定是否生效

```javascript
// 手动触发刷新
populateCharacterData();
```

如果手动调用能刷新 → 事件绑定问题。检查 `init()` 中是否有：
```javascript
eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, populateCharacterData);
```

##### 检查 2：事件名是否匹配 MVU 版本

MVU `@master`（Zod 版）和 `@beta` 的事件名可能不同。添加保底轮询：
```javascript
setInterval(populateCharacterData, 1500);
```

##### 检查 3：JS 错误导致状态栏卡死

检查控制台是否有红色报错。常见原因：
- `getAllVariables` 未定义 → MVU bundle 未加载
- `waitGlobalInitialized` 未定义 → 同上
- `_.get(statData, 'path')` 路径写错 → 返回 `undefined`

##### 检查 4：`markdownOnly` 配置错误

状态栏正则脚本必须满足：
- `markdownOnly: true`
- `promptOnly: false`
- `replaceString` 用 Markdown 代码块包裹（`` ``` ``）
- 否则 `<script>` 标签不会执行

---

### 5. 状态栏不显示

**原因**：正则脚本未正确替换占位符
**解决**：
- 确认 `状态栏.html` HTML 结构正确，占位符与 JS 中的 id 选择器匹配
- 确认编译时 `inject_status_bar` 设置为 `true`
- 检查生成的 JSON 中 `replaceString` 是否包含完整的 HTML+JS 代码
- 确认 `<script type="module">` 标签正确包裹 JS 逻辑
- 检查浏览器控制台是否有 JS 错误（如 `waitGlobalInitialized` 未定义）

### 5a. 状态栏数据不更新（显示后不变）

**原因**：未绑定 `VARIABLE_UPDATE_ENDED` 事件，状态栏只在页面加载时填充一次
**解决**：
- 确认 `init()` 函数中包含 `eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, populateCharacterData);`
- 确认 `eventOn` 位于 `populateCharacterData()` 调用之后
- 检查 `populateCharacterData` 函数是否使用 `getAllVariables()` + `_.get()` 获取数据
- 在 SillyTavern 浏览器控制台执行 `Mvu.events.VARIABLE_UPDATE_ENDED` 确认事件名正确
- 添加 `setInterval(populateCharacterData, 1500)` 轮询保底，确保事件不可靠时也能更新

### 5b. 状态栏 JS 不执行（显示加载中/--）

**原因**：`markdownOnly: false` 导致 `<script>` 标签通过 `innerHTML` 注入，浏览器禁止执行
**解决**：
- 确认编译脚本中状态栏脚本的 `markdownOnly` 设为 `true`
- 确认 `replaceString` 内容用 Markdown 代码块包裹（`` ```\n...\n``` ``）
- 确认 `<script>` 标签加了 `type="module"`
- 确认数据访问路径正确：`getAllVariables().stat_data.xxx`（不是 `all_variables.xxx`）

### 6. 角色卡文件过大

**原因**：世界书条目过多或内容过长
**解决**：
- 控制每条世界书内容在 200-500 字
- 适当合并相关条目
- 使用 `enabled: false` 默认关闭非核心条目

### 7. 角色说话风格不符合设定

**原因**：对话示例不足或预设选择不当
**解决**：
- 增加更多对话示例，覆盖不同场景
- 考虑使用 Nova3 预设的文风设置

### 5c. TavernHelper 脚本未加载（状态栏不显示/显示加载中）

**原因**：`tavern_helper.scripts` 结构错误，SillyTavern 无法识别脚本条目

**症状**：
- 状态栏显示 `加载中...` 且值一直为 `--`
- 在 SillyTavern `扩展 -> 脚本` 中看不到 MVU Bundle / Schema 脚本

**检查编译后的 JSON**：
```bash
node -e "
import fs from 'fs';
const card = JSON.parse(fs.readFileSync('path/to/card.json', 'utf8'));
const scripts = card.data.extensions.tavern_helper?.scripts || [];
scripts.forEach((s, i) => {
  console.log('['+i+'] has value wrapper:', !!s.value, '(should be false)');
  console.log('    has export_with:', !!s.export_with, '(should be true)');
  console.log('    has button:', !!s.button, '(should be true)');
  console.log('    enabled:', s.enabled, '(should be true)');
});
"
```

**解决**：
1. 确认 JSON 路径为 `data.extensions.tavern_helper.scripts`（非 `tavern_helper_scripts` 平铺键）
2. 确认脚本条目使用**扁平格式**（无 `value` 包装器）：
   ```json
   {
     "type": "script",
     "enabled": true,
     "name": "MVU Zod 脚本",
     "id": "...",
     "content": "...",
     "button": { "enabled": true, "buttons": [...] },
     "data": { ... },
     "export_with": { "data": true, "button": true }
   }
   ```
3. 确认 `build-card.js` 中的 `createTavernHelperScripts()` 使用 `createScriptEntry()` 辅助函数生成扁平条目

### 8. InitVar 条目误设为 enabled: true

**症状**：变量初始化值在 AI 回复中被当作上下文重复出现

**原因**：`[initvar]` 条目被设为 `enabled: true`，导致它作为普通世界书条目注入了 AI 上下文

**正确做法**：InitVar 条目必须 `enabled: false`（关闭状态），MVU 引擎直接读取其内容作为数据。

### 9. 部分变量更新但部分不更新

**原因**：AI 输出的 JSON Patch 数组中不包含某些变量

**检查方法**：在控制台查看 AI 实际回复中的 `<JSONPatch>` 块内容

**解决**：
- 在 `变量输出格式` 条目中列出所有需要更新变量
- 在 `depth_prompt` 中明确要求"更新所有变量"

## 导入 SillyTavern 后的验证

1. **检查角色卡片信息**：名称、描述、标签是否正确
2. **检查开场白**：第一条消息是否按预期显示
3. **检查世界书**：`角色设定` 页面中世界书条目是否正确
4. **检查正则脚本**：`扩展 -> 正则` 中是否存在生成的脚本（状态栏脚本 + 对AI隐藏状态栏脚本）
5. **检查 TavernHelper 脚本**（如适用）：`扩展 -> 脚本` 中是否正确显示 MVU Bundle + Schema 脚本
6. **发送测试消息**：触发关键词检查世界书是否正常注入
7. **检查变量更新**：AI 回复中是否包含 `<UpdateVariable>` 标签
8. **检查状态栏显示**：状态栏应显示实际数值，非 `--` 或 `加载中...`
9. **终极验证**：控制台执行 `getAllVariables().stat_data` 确认值随对话变化
