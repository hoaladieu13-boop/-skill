# Position 参考

SillyTavern 世界书条目插入位置参考表。

| Value | Label | 说明 |
|-------|-------|------|
| 0 | ↑Char | 角色定义之前 — Before character definitions |
| 1 | ↓Char | 角色定义之后 — After character definitions |
| 2 | ↑AT | Author's Note 之前 — Before Author's Note |
| 3 | ↓AT | Author's Note 之后 — After Author's Note |
| 4 | @D | 指定深度处 — At specific depth in chat |
| 5 | ↑EM | 示例消息之前 — Before Example Messages |
| 6 | ↓EM | 示例消息之后 — After Example Messages |
| 7 | Outlet | 输出到指定 Outlet |

---

## 推荐使用

| 条目类型 | Position | 理由 |
|----------|----------|------|
| 世界观总纲、背景设定、社会规则 | 0 (↑Char) | AI 在读取角色信息前先了解世界框架 |
| 角色速览（多角色卡） | 0 (↑Char) | 宏观层面：告知 AI 世界中存在哪些角色 |
| 角色详细信息 | 1 (↓Char) | 补充角色描述，放在角色定义之后 |
| NPC 详情 | 1 (↓Char) | 支撑角色信息，关键词触发 |
| 场景/事件/物品 | 1 (↓Char) | 具体细节，关键词触发 |
| 写作规范/指导 | 2 (↑AT) | 注入系统提示词区域 |
| 文风指令 | 2 (↑AT) | 风格引导，蓝灯常驻 |
| 二次解释（行为纠正） | 4 (@D, depth=0) | AI 最后读到的内容→影响力最大。role=system |
| 格式要求 | 5 (↑EM) 或 6 (↓EM) | 包裹示例消息 |

---

## 禁止事项

- **永不使用 D1/D2/D3+**（@D with depth >= 1）：在聊天消息之间插入内容会破坏对话流，混淆 AI
- **D0 仅用于行为指导，不用于设定**：D0 用于直接指令如"当 X 发生时，做 Y"，不是放世界观 lore 的地方
- **永不跳过递归防护**：每个条目都必须设置 `preventRecursion=true` 和 `excludeRecursion=true`

---

## 在 config.yaml 中的配置

```yaml
entries:
  - comment: "世界观总纲"
    content: "..."
    position: "before_char"     # ↑Char (0)
    order: 1
    constant: true
    
  - comment: "角色性格设定"
    content: "..."
    position: "after_char"      # ↓Char (1)
    order: 99
    constant: true
    
  - comment: "行为纠正"
    content: "..."
    position: "at_depth"        # @D (4)
    depth: 0
    role: 0                     # system
    constant: true
```

> `position` 在 YAML 配置中使用字符串值：`before_char`、`after_char`、`at_depth`。build-card.js 会自动转换为对应的数字值。
