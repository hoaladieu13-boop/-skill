# MVU 变量系统指南

## 概述

MVU（Magical Variable Update）是一套角色/世界动态变量的文件化工作流系统。通过在角色卡中嵌入变量定义和更新规则，让 AI 能在对话中自动追踪角色状态变化。

MVU Zod 是 MVU 的升级版本，基于 **Zod Schema** 做类型安全约束，使用 **JSON Patch (RFC 6902)** 作为标准化更新格式。

### 核心文件清单

| 文件 | 必选 | 说明 |
|------|------|------|
| `变量结构.js` | 是 | Zod Schema 定义变量结构，注册到 MVU 引擎 |
| `变量更新规则.md` | 是 | 世界书条目，指导 AI 何时、如何更新变量 |
| `变量输出格式.md` | 是 | 世界书条目，指导 AI 使用 JSON Patch 格式输出更新指令 |
| `变量初始化条目.md` | 推荐 | 世界书条目，提供变量初始值（`enabled: false`） |
| `状态栏.html` | 可选 | HTML 状态栏模板，显示变量当前值 |

### 核心工作流

```
① 编写 Zod Schema (变量结构.js)
    ↓
② 注册到 MVU 引擎 → registerMvuSchema(Schema)
    ↓
③ 创建 InitVar 条目 → 提供初始值 (enabled: false)
    ↓
④ 创建「变量更新规则」条目 → 告诉 AI 更新逻辑
    ↓
⑤ 创建「变量输出格式」条目 → 告诉 AI 用 JSON Patch 格式输出
    ↓
⑥ AI 回复 → 输出 <UpdateVariable> + <JSONPatch>
    ↓
⑦ MVU 引擎解析 JSON Patch → 更新 stat_data
    ↓
⑧ 状态栏 (eventOn) → 读取 stat_data → 刷新显示
```

---

## 1. 变量结构设计 → 变量结构.js

使用 Zod 定义变量 Schema，注册到 MVU 系统。

### 基本规则

1. **注册到 MVU**：使用 `registerMvuSchema(Schema)` 注册
2. **数字优先使用 `z.coerce.number()`**：确保能从字符串自动转换
3. **使用 `prefault()` 而非 `default()`**：保证幂等性，重复解析不累积
4. **对象优先于数组**：使用 `z.object()` / `z.record()` 替代数组
5. **约束做容错修正**：超范围时 `transform` 修正到边界值，而非报错
6. **保持幂等**：多次应用相同更新得到相同结果

### 标准模板

```javascript
import { z } from 'zod';
import { registerMvuSchema } from 'https://testingcf.jsdelivr.net/gh/StageDog/tavern_resource/dist/util/mvu_zod.js';

export const Schema = z.object({
    wealth_system: z.object({
        系统资金: z.coerce.number()
            .min(0, "不能为负")
            .max(300000000000, "上限 3000 亿")
            .prefault(100000000000),

        好感度: z.coerce.number()
            .min(0, "不能为负")
            .max(100, "上限 100")
            .prefault(50),
    })
});

$(() => {
    registerMvuSchema(Schema);
});
```

> ⚠️ **关键**：Zod Schema 的顶层 key（如 `wealth_system`）决定了 JSON Pointer 路径的前缀。在 InitVar、JSON Patch 和状态栏中，路径必须统一以这个 key 开头。

### 变量命名规范

- 使用中文命名（如 `系统资金`、`好感度`）
- 清晰表达变量含义
- 保持所有文件中命名一致

---

## 2. 三个必需的世界书条目

MVU Zod 系统正常运行需要三个世界书条目配合：

| 顺序 | 条目名 | `enabled` | `constant` | `position` | 作用 |
|------|--------|-----------|------------|------------|------|
| 0 | `[initvar]变量初始化` | `false` | `false` | `before_char` | 提供初始值，MVU 引擎直接读取（关闭状态） |
| 1 | `[mvu_update]变量更新规则` | `true` | `true` | `after_char` | 告诉 AI 更新逻辑 |
| 2 | `[mvu_update]变量输出格式` | `true` | `true` | `after_char` | 告诉 AI JSON Patch 输出格式 |

### 2.1 变量初始化条目（InitVar）

**必须设为 `enabled: false`**（关闭状态）。MVU 引擎直接读取该条目的内容作为初始数据，不需要注入到 AI 上下文中。

内容格式为 YAML，顶级 key 必须与 Zod Schema 的顶级 key 一致：

```yaml
wealth_system:
  系统资金: 100000000000
  好感度: 50
  已消费系统资金: 0
```

### 2.2 变量更新规则条目

使用 `constant: true` 确保始终注入 AI 上下文。只写 `check` 规则（类型约束已在 Schema 中）：

```yaml
---
变量更新规则:
  wealth_system:
    系统资金:
      check:
        - 每次审核通过消费后：系统资金 = 系统资金 - 消费金额
        - 不得为负，最低为 0
        - 系统等级提升时获得额外注入

    好感度:
      check:
        - 玩家友好互动：+5 至 +15
        - 玩家冷漠/伤害：-10 至 -30
        - 达到 70 解锁"亲密"阶段
```

### 2.3 变量输出格式条目（关键！）

**这是最常出错的部分。** 必须使用 JSON Patch (RFC 6902) 格式，包含 `<Analysis>` 和 `<JSONPatch>` 子标签：

```yaml
---
变量输出格式:
  rule:
    - you should output the update analysis and the actual update commands in the end of the next reply
    - the update commands must strictly follow the **JSON Patch (RFC 6902)** standard, but can only use the following operations: `replace` (replace the value of existing paths), `add` (only used to insert new items into an object or array), `remove`; that is, the output must be a valid JSON array containing operation objects
  format: |-
    <UpdateVariable>
    <Analysis>$(IN ENGLISH, no more than 80 words)
    - ${calculate time passed: ...}
    - ${decide whether dramatic updates are allowed as it's in a special case or the time passed is more than usual: yes/no}
    - ${analyze every variable based on its corresponding `check`, according only to current reply instead of previous plots: ...}
    </Analysis>
    <JSONPatch>
    [
      { "op": "replace", "path": "/wealth_system/系统资金", "value": "${new_value}" },
      { "op": "replace", "path": "/wealth_system/好感度", "value": "${new_value}" },
      ...
    ]
    </JSONPatch>
    </UpdateVariable>
```

> ⚠️ **JSON Pointer 路径规则**：路径格式为 `/顶级SchemaKey/变量名`。例如 Schema 定义为 `z.object({wealth_system: z.object({...})})`，则路径为 `/wealth_system/系统资金`。

---

## 3. AI 输出格式详解

### 正确格式（MVU Zod）

```html
<UpdateVariable>
<Analysis>Based on the conversation, the host spent 100,000 on treating friends. System fund decreased by 100,000, consumed fund increased by 100,000. Rebate rate is 10%, so rebate = 10,000.</Analysis>
<JSONPatch>
[
  { "op": "replace", "path": "/wealth_system/系统资金", "value": 999900000000 },
  { "op": "replace", "path": "/wealth_system/已消费系统资金", "value": 100000 },
  { "op": "replace", "path": "/wealth_system/返利金额", "value": 10000 },
  { "op": "replace", "path": "/wealth_system/个人可支配资金", "value": 10000 }
]
</JSONPatch>
</UpdateVariable>
```

### 常见错误格式（会导致变量不更新）

**错误 1：用纯 JSON 对象代替 JSON Patch 数组**
```html
<UpdateVariable>
{ "系统资金": 999900000000, "已消费系统资金": 100000 }
</UpdateVariable>
```
❌ 缺少 `<Analysis>` 和 `<JSONPatch>` 子标签，MVU 引擎无法解析

**错误 2：使用 `${}` 模板占位符**
```html
<UpdateVariable>
{ "系统资金": ${system_fund} }
</UpdateVariable>
```
❌ `${system_fund}` 不是有效值，AI 也不理解这些占位符含义

**错误 3：路径缺少顶级 key**
```json
{ "op": "replace", "path": "/系统资金", "value": 100 }
```
❌ 应为 `/wealth_system/系统资金`（顶级 key 来自 Schema）

**错误 4：旧版键值对格式（MVU Beta 兼容）**
```html
<UpdateVariable>
  好感度: "75"
  欲望值: "30"
</UpdateVariable>
```
❌ MVU Zod 引擎不识别这种格式

---

## 4. InitVar 注意事项

### `enabled: false` 是正确的

InitVar 条目必须保持关闭状态（`enabled: false`）。MVU 引擎会直接读取该条目的内容作为初始化数据，不需要它出现在 AI 上下文中。

**不要犯以下错误：**
- ❌ 把 InitVar 设为 `enabled: true`（会污染 AI 上下文）
- ❌ 删除 InitVar 条目（没有初始值，变量从 null 开始）
- ❌ 认为 `enabled: false` 是"有问题"的（这是 MVU 的设计要求）

### InitVar 的 YAML 格式必须匹配 Schema

Schema:
```javascript
z.object({
    wealth_system: z.object({ 系统资金: z.coerce.number().prefault(100000000000) })
})
```

InitVar:
```yaml
wealth_system:
  系统资金: 100000000000
```

顶级 key `wealth_system` 必须匹配 Schema 的顶级 key。

---

## 5. 状态栏 → 状态栏.html

可选的状态栏模板，用于在对话中直观显示变量值。

### 核心铁律

| # | 铁律 | 说明 |
|---|------|------|
| 1 | **JS 必须使用 `getMvuData()` 三级降级模式** | `window.stat_data` → MVU API → 兜底默认值，缺一不可 |
| 2 | **代码块必须无语言标签** | 使用 ` ``` ` 而非 ` ```html `，否则 SillyTavern 不渲染 |
| 3 | **`script` 标签使用 `type="module"`** | 模块作用域避免全局变量污染 |
| 4 | **所有 `document.getElementById()` 前有存在性检查** | 避免 DOM 未加载时报错 |
| 5 | **数值变量有 `Math.min`/`Math.max` 边界限制** | 进度条等不能超出 0-100 范围 |
| 6 | **`init()` 含延迟机制 + 轮询保底 + 清理旧轮询** | 应对 MVU 引擎未就绪、事件丢失、重复初始化 |

### HTML 结构

使用 `<style>` 标签定义样式，`<body>` 中放置 HTML 骨架（注意代码块无语言标签）：

```
<div class="status-card">
    <span>系统资金: <span id="system-funds">--</span></span>
    <span>好感度: <span id="affection-value">--</span></span>
</div>
```

### JavaScript 初始化（MVU Zod 稳健模式 — 必须使用）

```javascript
// ===== 三级降级：getMvuData() =====
function getMvuData() {
  // 第一级：直接从 window.stat_data 读取（最快路径）
  if (window.stat_data && typeof window.stat_data === 'object' && Object.keys(window.stat_data).length > 0) {
    return window.stat_data;
  }
  // 第二级：通过 MVU API 获取
  try {
    if (window.TavernHelper?.MVU?.getAllVariables) {
      const allVars = window.TavernHelper.MVU.getAllVariables();
      if (allVars) {
        // MVU Zod v2+: {name, variables}，兼容旧版 {stat_data}
        const data = allVars.variables?.initialValue || allVars.stat_data || allVars.variables || allVars;
        if (data && typeof data === 'object' && Object.keys(data).length > 0) {
          window.stat_data = data; // 回写缓存
          return data;
        }
      }
    }
  } catch(e) { /* 降级到第三级 */ }
  // 第三级：兜底默认值
  return {};
}

// ===== 初始化 =====
function init() {
  // 清理旧轮询（防止多次 init() 产生多个轮询）
  if (window._sbInterval) clearInterval(window._sbInterval);

  const data = getMvuData();
  populateData(data);

  // 事件驱动刷新（MVU Zod 标准事件）
  if (window.Mvu && typeof window.Mvu.on === 'function') {
    window.Mvu.on('variableUpdateEnded', function() {
      populateData(getMvuData());
    });
  }

  // 轮询保底（应对事件丢失）
  window._sbInterval = setInterval(function() {
    populateData(getMvuData());
  }, 2000);
}

// ===== 数据填充 =====
function populateData(data) {
  if (!data || Object.keys(data).length === 0) return;

  // 使用可选链 + 存在性检查
  const el = document.getElementById('system-funds');
  if (el) el.textContent = data.系统资金 ?? '--';

  const el2 = document.getElementById('affection-value');
  if (el2) el2.textContent = data.好感度 ?? '--';
}

// ===== 启动 =====
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
```

### 正则脚本配置

状态栏通过正则脚本将 `<StatusPlaceHolderImpl/>` 替换为 HTML 源码。

**关键配置项：**

| 脚本名 | `findRegex` | `replaceString` | `promptOnly` | `markdownOnly` |
|--------|-------------|-----------------|-------------|----------------|
| 对AI隐藏状态栏 | `<StatusPlaceHolderImpl/>` | (空) | `true` | `false` |
| 状态栏 | `<StatusPlaceHolderImpl/>` | `` ```\n...HTML...\n``` `` | `false` | `true` |
| 去除更新变量 | `/<(UpdateVariable\|Analysis\|JSONPatch)>[\\s\\S]*?<\\/\\1>/gm` | (空) | `true` | `true` |

**注意事项：**
- `markdownOnly: true` 必须配合 **无语言标签的代码块**（`` ``` ``）而非 ```` ```html ````，否则 `<script>` 标签无法执行
- 状态栏脚本的 `promptOnly` 必须为 `false`（对用户可见）
- 隐藏脚本的 `promptOnly` 必须为 `true`（对AI隐藏）+ `runOnEdit: true`（编辑时也触发）

---

## 6. 运行机制详解

### 数据流

```
AI 回复
  │
  ├─→ ① MVU 引擎拦截，提取 <UpdateVariable>
  │      │
  │      ├─→ 查找 <Analysis> 标签（AI 的分析推理）
  │      ├─→ 查找 <JSONPatch> 标签（JSON Patch 操作数组）
  │      │
  │      └─→ 解析 JSON Patch → 更新 stat_data
  │             │
  │             └─→ Zod Schema 验证 + 类型转换 + 边界修正
  │                    │
  │                    └─→ 触发 VARIABLE_UPDATE_ENDED 事件
  │
  ├─→ ② 正则「去除更新变量」从 prompt 中移除更新块
  │
  └─→ ③ 状态栏通过 eventOn 监听事件 → 重新读取 stat_data → 刷新显示
```

### 事件绑定

```javascript
// 标准方式
eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, callback);

// 回退方式
Mvu.on("variableUpdateEnded", callback);
```

---

## 7. 常见问题排查

| 症状 | 最可能的原因 | 检查方法 |
|------|-------------|---------|
| 变量完全不更新 | Entry ID 2 输出格式不是 JSON Patch | 检查 `<JSONPatch>` 标签是否存在 |
| 部分变量不更新 | JSON Pointer 路径写错 | 确认路径以 `/<顶级key>/` 开头 |
| 变量值异常（如变 NaN） | AI 输出的值类型不匹配 Schema | 检查 `z.coerce.number()` 是否有 `catch()` |
| 状态栏一直显示初始值 | MVU 引擎未成功解析更新 | 检查浏览器控制台是否有 MVU 错误日志 |
| 状态栏显示 `--` | 状态栏 JS 中数据路径错误 | 确认 `stat_data.xxx` 路径与 Schema 匹配 |

### 快速诊断步骤

1. 打开浏览器控制台（F12）
2. 在控制台执行 `getAllVariables().stat_data` 查看当前变量值
3. 发送一条消息后，再次执行 `getAllVariables().stat_data` 看值是否变化
4. 如果值没变 → Entry ID 2 格式问题（最可能）
5. 如果值变了但状态栏没更新 → 状态栏事件绑定问题
6. 在控制台查看是否有 MVU 相关的错误信息
