# 工作流快速参考

## 🚀 完整工作流（10 步）

### 第 0 步：任务判断

使用场景路由器 → 确定任务类型（角色卡创建/世界书/转化等）

📄 参考：`references/scenario-router.md`

---

### 第 1 步：需求分析 + 项目初始化

```bash
# 初始化项目骨架
node scripts/init-project.js "作品名称" --type mvu --characters "角色名"
```

输出：项目目录 + `to-do.md` + 基础文件

📄 参考：`references/workflow.md` 阶段 1-2

---

### 第 2 步：内容创作

编辑以下源文件：
- `背景设定.md`：世界观
- `角色设定_*.xyaml`：角色设定
- `开场白.md`：首条消息（必须包含 `<StatusPlaceHolderImpl/>`）
- `entries/角色设定_*.yaml`：世界书条目

📄 参考：`references/card-writing-guide.md`、`references/character-guide.md`

---

### 第 3 步：MVU 系统（可选）

如果启用 MVU 动态变量系统，编辑：
- `变量结构.js`：Zod Schema
- `变量初始化条目.yaml`：初始值
- `entries/变量更新规则.yaml`：更新逻辑
- `entries/变量输出格式.yaml`：输出格式
- `状态栏.html`：可视化显示

📄 参考：`references/mvu-system.md`

---

### 第 4 步：编译打包

```bash
node scripts/build-card.js config.yaml
```

输出：`作品名称.json` 角色卡

**自动处理：**
- ✅ 强制添加 `preventRecursion: true`、`excludeRecursion: true`
- ✅ 生成正则脚本（隐藏状态栏 → 去除更新变量 → 显示状态栏）
- ✅ 生成 TavernHelper 脚本（MVU 变量管理）

---

### 第 5 步：自动化验证

```bash
node scripts/validate-card.js 作品名称.json -v
```

**检查项 41+：**
- ✅ JSON 语法
- ✅ 必填字段
- ✅ regex_scripts 完整性
- ✅ **preventRecursion/excludeRecursion 字段**（新增）
- ✅ **personality 非模板**（新增）
- ✅ **keys 格式正确**（新增）
- ✅ 状态栏 JS 健壮性

---

### 第 6 步：DoubleCheck 质量检查（必做！）

📄 参考：`references/doublecheck.md`

执行清单：
1. **禁词扫描**（10 min）
   - 叙事禁词、比喻禁词、描写禁律
   - 开场白特殊检查

2. **配置检查**（5 min）
   - 单/多角色卡配置
   - 蓝灯/绿灯设置
   - `preventRecursion`/`excludeRecursion` 检查
   - `keys` 格式校验

3. **结构完整性**（3 min）
   - 必填字段非空
   - 世界书条目完整

4. **自动化验证**（1 min）
   - 运行 validate-card.js
   - 检查无 ❌ 失败项

5. **导入测试**（5 min，推荐）
   - SillyTavern 导入测试
   - 功能检验

---

## 📋 命令速查

| 任务 | 命令 |
|------|------|
| 初始化项目 | `node scripts/init-project.js "作品名" --type mvu --characters "角色"` |
| 编译卡片 | `node scripts/build-card.js config.yaml` |
| 验证卡片 | `node scripts/validate-card.js 作品.json -v` |
| 解包卡片 | `node scripts/unpack-card.js 作品.json ./output/` |

---

## 🔑 核心铁律（必须遵守）

| # | 铁律 | 检查 |
|---|------|------|
| 1 | **MVU、HTML、状态栏 — 仅用户明确要求时启用** | 用户未提及就当不存在 |
| 2 | **所有世界书条目必须 `preventRecursion: true` 且 `excludeRecursion: true`** | validate-card.js 自动检查 ✅ |
| 3 | **单角色卡：所有条目蓝灯；多角色卡：速览蓝灯，详情绿灯+关键词** | DoubleCheck 第 2 阶段检查 |
| 4 | **开场白启用 MVU 时必须含 `<StatusPlaceHolderImpl/>`** | validate-card.js 检查 ✅ |
| 5 | **输出后必须执行禁词扫描** | DoubleCheck 第 1 阶段 |
| 6 | **输出前必须展示草稿给用户确认（DoubleCheck）** | DoubleCheck 流程 |

---

## 🎯 质量指标

| 指标 | 标准 |
|------|------|
| validate-card.js 通过率 | 100%（0 个 ❌ 失败项） |
| DoubleCheck 完成度 | 100%（所有检查项完成） |
| 禁词违规数 | 0 |
| preventRecursion 字段覆盖 | 100%（所有条目） |
| excludeRecursion 字段覆盖 | 100%（所有条目） |

---

## 📚 完整参考

| 文档 | 用途 | 优先级 |
|------|------|--------|
| `scenario-router.md` | 🥇 **任务分类路由** | **必读** |
| `workflow.md` | 工作流 11 阶段详解 | 必读 |
| `card-writing-guide.md` | 🥇 **角色卡编写规范** | **必读** |
| `character-guide.md` | 🥇 **角色条目模板** | **必读** |
| `config-guide.md` | 🥇 **世界书配置规则** | **必读** |
| `doublecheck.md` | 🥇 **质量检查清单** | **必读** |
| `forbidden-words.md` | 禁词清单 | 必读 |
| `mvu-system.md` | MVU 变量系统完整指南 | 如需启用 |
| `validation.md` | 验证脚本详解 | 参考 |
| `world-book.md` | 世界书设计模式 | 参考 |

---

## 💡 常见场景

### 场景 A：创建简单单角色卡

```bash
node init-project.js "角色名" --type basic --characters "角色名"
# 编辑：背景设定 → 角色设定 → 开场白
# 编译：build-card.js config.yaml
# 验证：validate-card.js + DoubleCheck
# 完成
```

### 场景 B：创建带 MVU 的动态卡

```bash
node init-project.js "作品名" --type mvu --characters "角色" --mvu "好感度,欲望值"
# 编辑：所有内容 + MVU 系统文件
# 编译：build-card.js config.yaml
# 验证：validate-card.js + DoubleCheck + 导入测试
# 完成
```

### 场景 C：修改已有卡片

```bash
# 方式 1：解包 → 修改源文件 → 重新编译
node unpack-card.js 原卡片.json ./unpacked/
# 修改 unpacked/* 文件
node build-card.js unpacked/config.yaml
```

---

## ⚡ 工作流优化建议

### 已实施的改进

✅ **Phase 1：强制执行铁律**
- build-card.js 自动添加 `preventRecursion/excludeRecursion`
- validate-card.js 检查这些字段
- init-project.js 生成完整模板

✅ **Phase 2：增强验证**
- 检查 personality 非模板
- 检查 keys 格式
- 检查所有必填字段

✅ **Phase 3：完善流程**
- DoubleCheck 流程文档
- 检查清单模板

### 后续优化方向

🔜 **Phase 4**（可选）
- 创建 VS Code 插件进行实时禁词检查
- 创建 Web UI 自动生成 config.yaml
- 集成 Git pre-commit 钩子验证

---

## 📞 需要帮助？

- 🤔 **任务分类不确定**？→ 查看 `scenario-router.md`
- 📝 **不知道怎么写内容**？→ 查看 `card-writing-guide.md`
- ⚙️ **config.yaml 配置疑问**？→ 查看 `config-guide.md`
- ✅ **验证失败找不到原因**？→ 查看 `validation.md`
- 🧪 **DoubleCheck 怎么做**？→ 查看 `doublecheck.md`
