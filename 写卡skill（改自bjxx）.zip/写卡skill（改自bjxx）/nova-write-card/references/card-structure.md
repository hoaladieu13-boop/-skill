# SillyTavern chara_card_v3 JSON 结构详解

## 顶层结构

```json
{
  "chara_card_v3": "1.0.0",        // 角色卡版本标识
  "spec": {
    "name": "角色卡名称",           // 显示名称
    "description": "描述",          // 简短描述
    "version": "1.0.0"            // 版本号
  },
  "data": {
    "name": "角色名",
    "description": "",
    "personality": "",
    "scenario": "",
    "first_mes": "开场白...",
    "mes_example": "对话示例...",
    "avatar": "角色头像昵称",
    "system_prompt": "",
    "post_history_instructions": "",
    "tags": ["角色扮演", "现代"],
    "creator": "作者",
    "character_version": "1.0.0",
    "extensions": {
      "depth_prompt": {
        "depth": 4,
        "prompt": "深度提示...",
        "role": "system"
      }
    },
    "character_book": {
      "entries": [
        // 世界书条目数组
      ]
    }
  }
}
```

## 字段详细说明

### spec 字段

| 字段 | 必需 | 类型 | 说明 |
|------|------|------|------|
| `name` | 是 | string | 角色卡名称，也是输出文件名 |
| `description` | 推荐 | string | 角色卡简要描述 |
| `version` | 推荐 | string | 版本号（语义化版本） |

### data 字段

| 字段 | 必需 | 类型 | 说明 |
|------|------|------|------|
| `name` | 是 | string | 角色显示名称 |
| `description` | 否 | string | 多角色合集卡中留空，通过世界书设定 |
| `personality` | 否 | string | 通常留空，通过世界书设定 |
| `scenario` | 否 | string | 场景设定，通常留空 |
| `first_mes` | 推荐 | string | 开场白，角色首条消息 |
| `mes_example` | 推荐 | string | 对话示例，格式为 `{{char}}: 消息` |
| `avatar` | 推荐 | string | 角色头像指示 |
| `system_prompt` | 否 | string | 自定义系统提示词 |
| `post_history_instructions` | 否 | string | 历史记录后的指令 |
| `tags` | 推荐 | string[] | 分类标签 |
| `creator` | 推荐 | string | 作者信息 |
| `character_version` | 推荐 | string | 角色版本号 |

### extensions 字段

| 字段 | 说明 |
|------|------|
| `depth_prompt` | 深度提示，在指定深度插入系统提示 |
| `nova_presets` | Nova 预设系统配置（如果有） |

### character_book.entries 条目

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `keys` | string[] | 是 | 触发关键词 |
| `content` | string | 是 | 条目内容 |
| `position` | string | 是 | `before_char`/`after_char`/`at_depth` |
| `depth` | number | 是 | 深度值 |
| `order` | number | 是 | 排序权重 |
| `role` | number | 是 | 0=系统 1=用户 2=助手 4=角色 |
| `enabled` | boolean | 否 | 默认启用状态 |
| `selective` | boolean | 否 | 是否选择性触发 |
| `secondary_keys` | string[] | 否 | 次要关键词 |
| `constant` | boolean | 否 | 是否始终触发 |
| `probability` | number | 否 | 触发概率百分比 |

## 编译脚本生成的附加内容

### 正则脚本（regex_scripts）

编译时在 `data.extensions.sillytavern_scripts` 下生成三个正则脚本：

1. **remove_update_variable**：匹配并移除 `<UpdateVariable>...</UpdateVariable>` 标签块
   - 正则：`<UpdateVariable>[\s\S]*?<\/UpdateVariable>`
   - 替换为：空字符串
   - 作用时机：生成后（替换标签为空）

2. **inject_status_bar**：将 `[变量名]` 占位符替换为 HTML 状态栏
   - 替换规则：将 `[好感度]` 替换为状态栏 HTML
   - 作用时机：生成后

3. **hide_update_from_ai**：隐藏 AI 可见的更新标签
   - 作用时机：生成后

### TavernHelper 脚本

如配置了 `user_scripts`，编译时生成 TavernHelper Beta 格式的脚本：

1. **MVU Beta/Zod 变量管理脚本**：注册变量 Schema，处理变量更新
2. **变量初始化脚本**（如配置）：在对话开始时初始化变量值
3. **用户自定义脚本**（如 `config.yaml` 中配置）：如变量结构 Schema 脚本

**JSON 结构**（扁平格式，无 `value` 包装器）：

```json
// data.extensions.tavern_helper.scripts 路径（非 tavern_helper_scripts）
{
  "type": "script",
  "enabled": true,
  "name": "MVU Zod 脚本",
  "id": "uuid",
  "content": "import '...bundle.js'",
  "info": "",
  "button": {
    "enabled": true,
    "buttons": [
      { "name": "重新处理变量", "visible": false },
      { "name": "重新读取初始变量", "visible": false }
    ]
  },
  "data": { "是否显示变量更新错误": "是" },
  "export_with": { "data": true, "button": true }
}
```

**重要**：
- 脚本条目必须使用**扁平格式**，所有属性（`id`, `name`, `content`, `enabled`, `button`, `data` 等）在顶层，不能使用 `value` 包装器
- `button` 是对象（含 `enabled` + `buttons` 数组），不是直接数组
- `export_with` 是必需的导出配置
- 路径必须是 `data.extensions.tavern_helper.scripts`，不是 `tavern_helper_scripts`
