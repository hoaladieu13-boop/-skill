# 场景路由器

本文档帮助模型在开始任何工作前，自行判断任务类型，然后读取对应的 reference 文件。**必须在读取本文件后，再根据任务类型读取相应的参考文件，不可跳过。**

---

## 第零步：任务判断逻辑（最优先）

### 核心规则

**先判断用户要的是什么：**

| 用户表达 | 输出内容 | 触发条件 |
|----------|----------|----------|
| 写卡/角色卡/人物设定/生成角色 | 完整的角色卡 | 自动 |
| 世界书/世界观/设定集 | 世界书条目 | 自动 |
| 完整的卡/全套/整套 | 角色卡+世界书 | 用户明确要求 |
| MVU/ZOD/变量 | 启用MVU | **仅用户明确要求时** |
| 美化/HTML/前端/状态栏 | 启用HTML | **仅用户明确要求时** |
| 动态世界书/阶段切换/ESJ/EJS | 启用ESJ阶段控制器 | **仅用户明确要求时（且必须先启用MVU）** |
| 有人味/内在矛盾/性格锚点/演绎法 | 启用角色演绎法 | **仅用户明确要求时（可选增强）** |

### 铁律

**如果用户没说 MVU 或 HTML，绝对不要主动建议或添加。**

### 确认流程（角色卡任务）

角色卡任务必须执行 DoubleCheck：

1. 输出完整草稿
2. 等待用户确认（说"可以""满意""继续""生成"等）
3. 用户确认后 → 用 `build-card.js` 编译生成 JSON
4. 运行 `validate-card.js` 验证 + 禁词扫描

世界书任务按原有总纲先行流程执行。

---

## 第一步：澄清式问询

不确定任务类型时，**先提问，再动手**。对照以下维度向用户确认：

| 维度 | 问什么 |
|------|--------|
| 任务类型 | 是写角色卡还是世界书？（第一步必须确认） |
| 任务规模 | 几个核心角色？是否多角色卡？条目数预估？ |
| 世界观复杂度 | 真实背景 / 套路世界 / 完全原创？ |
| 素材来源 | 原创构思 / 轻小说原文 / 游戏文本 / 其他？ |
| 输出格式 | 单角色卡还是多角色卡？独立世界书还是嵌入角色卡？ |
| 风格偏好 | 严肃文学 / 轻松日常 / 二次元 / 网络小说 / 白描 / 心理流？ |
| 特殊需求 | 是否需要 NSFW 设定？是否需要文风提取？ |

**多层任务判定原则：** 如果用户输入同时匹配多种类型（如"把这个轻小说转成角色卡"），按**类型 2（转化）**处理，它已包含所有子类型需要的 reference。

如果用户输入不明确，**先询问用户意图**，不猜测。

---

## 任务类型识别

根据用户的输入，判断属于以下哪种任务类型：

### 类型 0：角色卡创建

**触发关键词：** 写卡、角色卡、人物设定、生成角色、创建角色、设计角色

**需要读取的 reference：**
- `references/card-writing-guide.md`（角色卡编写规范）
- `references/character-guide.md`（角色条目结构）
- `references/world-book.md`（世界观编写）
- `references/config-guide.md`（配置规范）
- `references/position-guide.md`（位置参考）

**如果用户要求 MVU：** 额外读取 `references/mvu-system.md`
**如果用户要求 HTML/状态栏：** 额外读取 `templates/MVU组件包/5.html状态栏.md`
**如果用户要求角色更有「人味」/演绎一致：** 额外读取 `references/character-deduction.md`（内在矛盾 + 0–6 行动分级协议）

**必须执行 DoubleCheck 确认流程。**

编写完成后，按 `references/forbidden-words.md` 禁词清单逐条扫描所有内容，确保无禁词渗入。

---

### 类型 1：原创世界书

**触发关键词：** 世界书、生成世界书、创建世界书、世界观设定

**需要读取的 reference：**
- `references/character-guide.md`
- `references/world-book.md`
- `references/config-guide.md`
- `references/position-guide.md`

编写完成后，按 `references/forbidden-words.md` 禁词清单逐条扫描所有条目内容。

---

### 类型 2：轻小说/游戏/小说 → 转化世界书/角色卡

**触发关键词：** 轻小说、小说、转角色卡、根据原文、根据小说、转化、提取、原作、游戏、文本转化、原文

**需要读取的 reference：**
- `references/conversion-guide.md`（转化工作流总览）
- `references/character-guide.md`
- `references/world-book.md`
- `references/config-guide.md`
- `references/position-guide.md`

**不读** 文风提取相关文档（除非用户明确要求提取文风）。

提取完成后，按 `references/forbidden-words.md` 禁词清单逐条扫描所有条目内容。

**转化→角色卡时**：转化流程产出的世界书条目嵌入角色卡，角色卡 description + 开场白按 `card-writing-guide.md` 额外撰写。

---

### 类型 3：纯世界观/规则设定

**触发关键词：** 世界观、设定集、规则书、魔法体系、修炼体系、势力设定、地理设定、世界规则

**需要读取的 reference：**
- `references/world-book.md`
- `references/config-guide.md`
- `references/position-guide.md`

编写完成后，按 `references/forbidden-words.md` 禁词清单逐条扫描内容。

**如果世界观庞大（条目数 ≥ 约 20，或涉及大量地点/人物/区域）：** 额外读取 `references/world-book-layering.md`（蓝灯放规则/骨架、绿灯放详情的分层省 Token 方案）。

---

### 类型 4：物品/能力/装备设定

**触发关键词：** 武器、道具、装备、技能、能力、功法、魔法、物品、神器、防具、消耗品

**需要读取的 reference：**
- `references/config-guide.md`
- `references/position-guide.md`

---

### 类型 5：文风提取/文风设定

**触发关键词：** 文风、写作风格、文笔、笔风、语言风格、模仿写作

**需要读取的 reference：**
- `references/config-guide.md`
- `references/position-guide.md`

文风条目需遵循零度写作原则，不含禁词。

---

### 类型 6：MVU ZOD 变量系统

**触发关键词：** MVU、ZOD、变量、变量系统、数值系统、好感度系统

**需要读取的 reference：**
- `references/mvu-system.md`
- `references/config-guide.md`
- `references/position-guide.md`

**铁律：仅用户明确要求时才启用。绝不主动建议。**

---

### 类型 7：HTML 前端美化/状态栏

**触发关键词：** 美化、HTML、前端、状态栏、界面、UI

**需要读取的 reference：**
- `templates/MVU组件包/5.html状态栏.md`
- `references/config-guide.md`
- `references/position-guide.md`

**铁律：仅用户明确要求时才启用。绝不主动建议。**

---

### 类型 8：ESJ 阶段控制器（动态世界书）

**触发关键词：** 动态世界书、阶段切换、阶段控制器、ESJ、EJS、按变量注入、好感度阶段、关系阶段

**前置条件：** 必须先启用 MVU（类型 6）。ESJ 读取的 `stat_data` 由 MVU 维护，无 MVU 则退化成静态卡。

**需要读取的 reference：**
- `references/esj-stage-controller.md`
- `references/mvu-system.md`（变量层）
- `references/config-guide.md`
- `references/position-guide.md`

**做法：** 写一条 `constant=true` 的「Xxx_阶段控制器」条目，其 `content` 用 EJS（`<%_ %>` / `<%- %>`）读 `getvar('stat_data.xxx')`，按值 `getwi(null,'子条目名')` 注入对应阶段子条目；每个子条目都必须是真实存在的世界书条目。

**铁律：仅用户明确要求时才启用。绝不主动建议。控制器引用的每个 `getwi` 目标必须存在，否则报错。**

---

### 类型 9：角色演绎法（有人味增强，可选）

**触发关键词：** 有人味、内在矛盾、性格锚点、演绎法、行为一致、角色不八股、先打分再演绎

**需要读取的 reference：**
- `references/character-deduction.md`（内在矛盾 + 0–6 行动可能性分级协议）
- `references/character-guide.md`
- `references/config-guide.md`

**做法：** 为角色定义「内核（驱动力+恐惧）+ 内在矛盾（两股拉扯的力）+ 锚点（矛盾的物理显形）」三件套，并写一条 `constant=true` 的「性格演绎规则」蓝灯条目，内含「枚举分支 → 0–6 打分 → 剪枝 0–2 不可能分支 → 在 3–6 中可变选择」的协议。协议写成**指令+少样本**，勿只当事实陈述。

**与动态系统联动：** 把「矛盾张力」做成 MVU 变量（`stat_data.角色.依赖恐惧`），让 0–6 评分随状态漂移；ESJ 按张力切换不同阶段的世界书条目，形成「性格→变量→表现」完整链路。

**铁律：可选增强，仅用户明确要求时采用。不主动建议，但一旦采用须保证锚点具体、矛盾从「恐惧」而非「萌点」出发定义。**

---

## 输出前 DoubleCheck

无论哪种任务类型，输出前必须执行：

1. [ ] 禁词扫描（`references/forbidden-words.md` 逐条检查）
2. [ ] 单角色卡 → 所有世界书条目 constant=true
3. [ ] 多角色卡 → 速览 constant=true，详情 constant=false + keys
4. [ ] 所有条目 `preventRecursion=true` 且 `excludeRecursion=true`
5. [ ] 关键词使用英文逗号分隔
6. [ ] 开场白末尾含 `<StatusPlaceHolderImpl/>`（仅当启用 MVU 时）
