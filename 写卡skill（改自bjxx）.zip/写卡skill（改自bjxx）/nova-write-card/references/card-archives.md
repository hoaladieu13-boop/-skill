# 角色卡档案库

> ⚠️ **档案已拆分到独立目录**，请访问 [`card-archives/index.md`](card-archives/index.md) 查看。

## 目录结构

```
card-archives/
├── index.md          # 入口索引 + 分类统计
├── components.md     # 可复用组件库（SB/RS/MVU/OPT/CONF）
├── _template.md      # 新建卡片模板
├── card-001.md       # 林家秘事_v43
├── card-002.md       # 宝贝，妈妈只是在写小说啊
├── card-003.md       # 教师母亲的柔情
├── card-004.md       # [MUV]背德系统v3-0805
└── card-005.md       # 恶堕、洗白、调教大师
```

**说明**：每张卡片独立为文件，避免单文件过大。可复用组件提取到 `components.md`，创建新卡时在 `_template.md` 上修改。
