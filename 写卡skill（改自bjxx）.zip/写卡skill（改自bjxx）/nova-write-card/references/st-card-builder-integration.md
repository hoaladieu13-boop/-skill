# st-card-builder → nova-write-card 整合方案

## 概述

将 st-card-builder 的核心能力以模块化方式整合到 nova-write-card 的 CLI 工作流中，分 4 个阶段实施。

---

## Phase 1: validate-card.js 增强（高影响，低难度）

### 从 st-card-builder 提取的新检查项

```javascript
// === 新增检查项（整合自 st-card-builder PreviewPanel 的 validateFullJSON）===

// 1. 角色卡四部分结构完整性
const STRUCTURE_CHECKS = [
  {
    id: 'personality_not_empty',
    check: (json) => {
      const p = json.data?.personality || json.personality || '';
      return p.length > 20 && !p.includes('在此填写') && !p.includes('placeholder');
    },
    message: 'personality 字段为空或为模板占位符，角色将缺乏性格设定',
    level: 'error'
  },
  {
    id: 'description_content_quality',
    check: (json) => {
      const d = json.data?.description || json.description || '';
      return d.length > 100;  // description 至少要有一定长度
    },
    message: 'description 内容不足 100 字符，角色背景描述过于简略',
    level: 'warning'
  }
];

// 2. 所有世界书条目的递归防止字段
const ENTRY_CHECKS = {
  all_entries_have_recursion_guard: (json) => {
    const entries = json.data?.character_book?.entries || [];
    return entries.every(e => e.preventRecursion === true && e.excludeRecursion === true);
  },
  all_entries_have_ids: (json) => {
    const entries = json.data?.character_book?.entries || [];
    return entries.every(e => e.id !== undefined && e.id !== null);
  },
  keys_format_array: (json) => {
    const entries = json.data?.character_book?.entries || [];
    return entries.every(e => !e.keys || Array.isArray(e.keys));
  }
};

// 3. MVU 完整性检查
const MVU_CHECKS = {
  has_mvu_runtime: (json) => {
    const scripts = json.data?.extensions?.tavern_helper?.scripts || [];
    return scripts.some(s => (s.name || s.scriptName || '').includes('MVU'));
  },
  has_zod_schema: (json) => {
    return true;  // 可选，不强制
  },
  has_update_entries: (json) => {
    const entries = json.data?.character_book?.entries || [];
    return entries.some(e => (e.comment || '').includes('[mvu_update]'));
  }
};
```

### 当前 validate-card.js 已覆盖 vs 需新增

| 检查项 | 当前状态 | 动作 |
|--------|---------|------|
| JSON 语法 | ✅ 已有 | 保留 |
| chara_card_v3 标识 | ✅ 已有 | 保留 |
| 必填顶层字段 | ✅ 已有 | 保留 |
| regex_scripts 完整性 | ✅ 已有 | 保留 |
| tavern_helper 完整性 | ✅ 已有 | 保留 |
| 世界书条目配置 | ✅ 已有 | 保留 |
| 开场白占位符 | ✅ 已有 | 保留 |
| 八股化扫描 | ✅ 已有 | 保留 |
| 关键词冲突 | ✅ 已有 | 保留 |
| Token 占用 | ✅ 已有 | 保留 |
| **personality 非空模板** | ❌ 缺失 | **新增** |
| **description 长度质量** | ❌ 缺失 | **新增** |
| **所有条目递归保护** | ⚠️ 部分有 | **强化** |
| **条目 id 完整性** | ❌ 缺失 | **新增** |
| **MVU 运行时检查** | ❌ 缺失 | **新增** |
| **变量更新规则存在性** | ⚠️ 部分有 | **强化** |
| **变量预览报告生成** | ❌ 缺失 | **新增** |

---

## Phase 2: 新增 test-card.js（中等影响）

### 核心设计

```javascript
// test-card.js — 角色卡对话质量自动测试
// 
// 用法: node test-card.js <card.json> --api-url <url> --api-key <key> --model <model>
//
// 流程:
// 1. 读取编译后的 JSON 角色卡
// 2. 用 AI API 模拟 3-5 轮对话
// 3. 检查每轮回复是否包含关键要素
// 4. 生成质量报告

class CardTester {
  constructor(cardPath, apiConfig) {
    this.card = JSON.parse(fs.readFileSync(cardPath));
    this.api = apiConfig;
    this.results = [];
  }

  // 测试 1: 开场白质量
  async testFirstMes() {
    // 检查开场白长度 > 200 字符
    // 检查开场白包含场景描写、角色状态、互动邀请
  }

  // 测试 2: 角色一致性
  async testRoleConsistency() {
    // 用预设问题测试角色是否保持设定
    // 例: "你是谁？" → 确认角色介绍自己
    // 例: "介绍一下你自己" → 确认角色引用 personality 设定
  }

  // 测试 3: 世界书触发
  async testWorldbookTriggering() {
    // 用包含关键词的输入测试世界书条目是否被触发
    // 检查回复中是否包含相关世界书内容
  }

  // 测试 4: MVU 变量更新
  async testMvuUpdates() {
    // 检查回复中是否包含 <UpdateVariable> 标签
    // 检查 JSONPatch 格式是否正确
    // 检查变量是否按规则更新
  }

  // 测试 5: 状态栏渲染
  async testStatusBar() {
    // 检查回复末尾是否包含状态栏
    // 检查状态栏字段是否更新
  }

  async run() {
    await this.testFirstMes();
    await this.testRoleConsistency();
    await this.testWorldbookTriggering();
    await this.testMvuUpdates();
    await this.testStatusBar();
    return this.generateReport();
  }
}
```

---

## Phase 3: 新增 ai-assist.js（低影响，高体验）

### 命令设计

```bash
# 1. 生成角色设定草案（基于 config.yaml 中的背景设定）
node scripts/ai-assist.js generate-personality <project-dir>

# 2. 生成世界书条目
node scripts/ai-assist.js generate-wb-entry <project-dir> \
  --name "秘密书房" \
  --keys "书房,密室,古书" \
  --content "描述条目内容方向"

# 3. 补全世界书触发词
node scripts/ai-assist.js suggest-keys <project-dir>

# 4. 优化开场白
node scripts/ai-assist.js polish-first-mes <project-dir>

# 5. 生成 MVU 变量系统
node scripts/ai-assist.js generate-mvu <project-dir> \
  --requirements "追踪好感度、关系阶段、线索收集进度"
```

---

## Phase 4: 新增 png-export.js（低影响，高交付体验）

### 设计

```javascript
// png-export.js — 输出酒馆原生 PNG 卡片
// 依赖: 'png-chunk-text' (npm) 或内置纯 JS PNG 写入
//
// 用法: node png-export.js <card.json> [--avatar <avatar.png>] [--output <output.png>]

class PngExporter {
  async export(cardJson, avatarPath) {
    // 1. 读取头像或使用默认生成的 SVG 头像
    // 2. 将 JSON 序列化后 base64 编码
    // 3. 写入 PNG tEXt chunk (keyword='chara')
    // 4. 输出标准 PNG 文件
  }
}
```

---

## 优先级矩阵

| 功能 | 影响 | 难度 | 依赖 | 优先级 |
|------|------|------|------|--------|
| validate-card.js 增强 | ⭐⭐⭐⭐⭐ | ⭐ | 无 | **P0 立即** |
| test-card.js | ⭐⭐⭐⭐ | ⭐⭐⭐ | AI API | **P1 本周** |
| ai-assist.js | ⭐⭐⭐ | ⭐⭐ | AI API | **P2 本月** |
| png-export.js | ⭐⭐⭐ | ⭐⭐ | npm 包 | **P3 后续** |

---

## 开始实施

已选择 **Phase 1** 作为第一步，直接从最快带来质量提升的地方开始。
