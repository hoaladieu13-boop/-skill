# 可复用组件库

> 从已创建的卡片中提取的独立组件，可直接在新卡中复用。
> 每个组件标注来源和适用场景。

---

## 1. 状态栏组件

### SB-001：林家秘事 HTML 状态栏

| 属性 | 值 |
|------|----|
| **来源** | [card-001 林家秘事](card-001.md) |
| **适用场景** | 含 MVU 变量系统的卡片，需要实时数值显示+进度条 |
| **实现方式** | HTML + `<script type="module">` |
| **关键特性** | `getMvuData()` 三级降级函数、`eventOn` 事件监听、`setInterval` 轮询保底、`clearInterval` 清理旧轮询、`Math.min`/`Math.max` 值域限制、`document.getElementById` 存在性检查 |
| **三级降级** | `window.stat_data` → `window.TavernHelper.MVU.getAllVariables()` → 兜底默认值 |
| **变量显示** | 威严值、顺从值、抵抗值、欲望值、禁忌值、暴露值、调教进度(进度条)、犬化值、SP值、淫乱值、好感度_林晨、好感度_林晓曦、好感度_林婉清 |

### SB-002：背德系统 底部状态栏

| 属性 | 值 |
|------|----|
| **来源** | [card-004 背德系统v3-0805](card-004.md) |
| **适用场景** | 系统流卡片，简洁底部状态栏 |
| **实现方式** | 正则替换 `<StatusPlaceHolderImpl/>` → 文字版状态栏 |
| **特点** | 仅文本显示，无 HTML 渲染，兼容性最好 |

### SB-003：恶堕大师 美化状态栏

| 属性 | 值 |
|------|----|
| **来源** | [card-005 恶堕、洗白、调教大师](card-005.md) |
| **适用场景** | 带学生档案/笔记等特殊功能的卡片 |
| **实现方式** | 正则替换 `<StatusPlaceHolderImpl/>` + 额外 `<Student_Profile>` 和 `<LinXiaoYu_Notes>` 标签正则 |
| **特点** | 状态栏与特殊功能标签分离，各自独立正则 |

---

## 2. 正则脚本组件

### RS-001：基础三件套（标准）

| 脚本 | promptOnly | markdownOnly | 正则 | 作用 |
|------|-----------|-------------|------|------|
| 对AI隐藏状态栏 | true | false | `<StatusPlaceHolderImpl/>` | 发送给 AI 前移除占位符 |
| 去除更新变量 | true | true | `/<UpdateVariable>[\s\S]*?</UpdateVariable>/gm` | 发送给 AI 前移除变量更新标签 |
| 状态栏 | false | true | `<StatusPlaceHolderImpl/>` | 用户视角替换占位符为实际内容 |

**来源**：[card-001 林家秘事](card-001.md)、[card-004 背德系统](card-004.md)  
**说明**：最标准的三件套，`对AI隐藏状态栏` 使用字符串正则（非正则对象），`去除更新变量` 使用正则对象模式。

### RS-002：带 Analysis/JSONPatch 的去除更新变量

| 脚本 | promptOnly | markdownOnly | 正则 | 作用 |
|------|-----------|-------------|------|------|
| 去除更新变量 | true | true | `/<(UpdateVariable\|Analysis\|JSONPatch)>[\s\S]*?</\1>/gm` | 同时移除 UpdateVariable、Analysis、JSONPatch 三种标签 |

**来源**：[card-001 林家秘事](card-001.md)（build-card.js 自动生成）  
**说明**：比 RS-001 更全面，MVU Zod 系统需要同时处理三种标签。

### RS-003：选项卡片对 AI 隐藏 + 用户可见（双脚本）

| 脚本 | promptOnly | markdownOnly | 正则 | 作用 |
|------|-----------|-------------|------|------|
| 对AI隐藏选项卡片 | true | true | `/<w2g>[\s\S]*?<\/w2g>/g` | 发送给 AI 前移除选项卡片 |
| 选项卡片 | false | true | `/<w2g>([\s\S]*?)<\/w2g>/g` | 用户视角显示选项卡片 |

**来源**：[card-001 林家秘事](card-001.md)  
**说明**：使用 `<w2g>...</w2g>` 标签包裹选项内容。

### RS-004：思维链/档案/笔记类正则

| 脚本 | 正则 | 来源 | 用途 |
|------|------|------|------|
| 仅格式思维链 | `/<Analysis>[\s\S]+?<\/Analysis>/gm` | [card-005](card-005.md) | 对 AI 隐藏 Analysis 思维链 |
| 档案 | `<Student_Profile>...` | [card-005](card-005.md) | 用户视角显示学生档案卡片 |
| 林小雨的笔记 | `/<LinXiaoYu_Notes>...` | [card-005](card-005.md) | 用户视角显示笔记内容 |
| 一体式美化状态栏 | `<maintext>...</Status_block>` | [card-003](card-003.md) | 正文+状态栏整体美化 |
| 美化状态栏(只美化) | `...<Status_block>...</Status_block>` | [card-003](card-003.md) | 仅对状态栏区域做美化 |
| 剧情推进-正则 | `\[剧情推进\]` | [card-003](card-003.md) | 匹配剧情推进标记 |

---

## 3. MVU 变量系统组件

### MVU-001：标准 Zod Schema 结构

| 属性 | 值 |
|------|----|
| **来源** | [card-001 林家秘事](card-001.md) |
| **结构** | `const VariableSchema = z.object({...})` + `export const variables = [...]` |
| **变量定义** | 名称、类型、初始值、描述、可见性、显示名称、单位 |
| **内容长度** | 2741 字符（含 13 个变量定义） |

### MVU-002：变量初始化条目格式

| 属性 | 值 |
|------|----|
| **来源** | [card-001 林家秘事](card-001.md) |
| **配置** | `enabled: false`（启动后禁用），`constant: false` |
| **启用方式** | build-card.js 自动从 [initvar] 条目读取并生成 TavernHelper 初始化脚本 |

### MVU-003：变量更新规则模板

| 属性 | 值 |
|------|----|
| **来源** | [card-001 林家秘事](card-001.md) |
| **配置** | `position: at_depth`（深度提示位置），`constant: true`（蓝灯常驻） |
| **内容** | 定义每种变量在什么情境下增加/减少，格式优先使用 `<UpdateVariable>` 标签 |

### MVU-004：变量输出格式模板

| 属性 | 值 |
|------|----|
| **来源** | [card-001 林家秘事](card-001.md) |
| **配置** | `position: at_depth`，`constant: true` |
| **内容** | 定义 `<JSONPatch>` 和 `<UpdateVariable>` 的具体输出格式 |

---

## 4. 开场白/选项系统组件

### OPT-001：w2g 选项卡片

| 属性 | 值 |
|------|----|
| **来源** | [card-001 林家秘事](card-001.md) |
| **标签** | `<w2g>选项内容</w2g>` |
| **正则** | RS-003（对 AI 隐藏 + 用户可见双脚本） |
| **内容** | 使用 `<options>` 标签实现的选择式玩法，包裹在 `<w2g>` 中 |

### OPT-002：备选开场白

| 属性 | 值 |
|------|----|
| **来源** | [card-002 小说妈](card-002.md)（6条备选）、[card-005 恶堕大师](card-005.md)（2条备选） |
| **分隔符** | `===== SEPARATOR =====`（注意：**不要用 `---`**） |
| **说明** | 在开场白源文件中用分隔符分隔多个开场，编译时自动分为主开场和备选 |

---

## 5. 配置模式模板

### CONF-001：单角色卡 config.yaml

```yaml
name: "作品名称"
tags: ["标签1", "标签2"]
fields:
  description: "背景设定.md"
  personality: "角色设定_角色名.xyaml"
  scenario: ""
  first_mes: "开场白.md"
  mes_example: ""
extensions:
  talkativeness: "0.5"
  depth_prompt:
    depth: 4
    role: system
    prompt: "深度提示.txt"
character_book:
  entries:
    - comment: "条目描述"
      content: "entries/条目文件.yaml"
      constant: true      # 所有条目蓝灯
      position: before_char
```

**来源**：[card-003 教师母亲](card-003.md)、[card-004 背德系统](card-004.md)  
**说明**：单角色卡 = 所有世界书条目 `constant: true`，无需 keys。

### CONF-002：多角色卡 config.yaml

```yaml
name: "作品名称"
# ... fields 同单角色 ...
character_book:
  # 蓝灯常驻（2-3条）：全局设定
  - comment: "世界观速览"
    content: "entries/世界观速览.yaml"
    constant: true
    position: before_char
  - comment: "[mvu_update]变量更新规则"
    content: "entries/变量更新规则.yaml"
    constant: true
    position: at_depth
  # 绿灯触发：各角色详情
  - comment: "角色A"
    content: "entries/角色A.yaml"
    constant: false
    selective: true
    keys: "角色A,角色A昵称"
    scanDepth: 2
  - comment: "角色B"
    content: "entries/角色B.yaml"
    constant: false
    selective: true
    keys: "角色B,角色B昵称"
    scanDepth: 2
```

**来源**：[card-005 恶堕大师](card-005.md)  
**说明**：多角色 = 分层策略。

### CONF-003：混合卡 config.yaml

```yaml
name: "作品名称"
# ... fields 同单角色 ...
character_book:
  # 蓝灯常驻（≤5条）：核心人设+行为模式+MVU+背景
  - comment: "[mvu_update]变量更新规则"
    content: "entries/变量更新规则.yaml"
    constant: true
    position: at_depth
    prevent_recursion: true
    exclude_recursion: true
  - comment: "[mvu_update]变量输出格式"
    content: "entries/变量输出格式.yaml"
    constant: true
    position: at_depth
    prevent_recursion: true
    exclude_recursion: true
  # 绿灯触发的子系统模块
  - comment: "[重口]某模块"
    content: "entries/模块文件.yaml"
    constant: false
    selective: true
    keys: "关键词1,关键词2,关键词3"
    scanDepth: 2
    prevent_recursion: true
    exclude_recursion: true
```

**来源**：[card-001 林家秘事](card-001.md)  
**说明**：混合卡 = 主角人设和行为模式也设为蓝灯（不超过5条），子系统全绿灯。
